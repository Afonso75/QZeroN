import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Clock, Euro, Calendar as CalendarIcon, CheckCircle2, Search } from "lucide-react";
import { format } from "date-fns";
import { pt } from "date-fns/locale";
import { createPageUrl } from '@/utils';
import { toast } from "sonner";

export default function AppointmentBooking({ business, user, onComplete }) {
  const queryClient = useQueryClient();
  const [selectedService, setSelectedService] = useState(null);
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);
  const [notes, setNotes] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const { data: services } = useQuery({
    queryKey: ['services', business.id],
    queryFn: () => base44.entities.Service.filter({ 
      business_id: business.id,
      is_active: true 
    }),
    initialData: [],
  });

  const { data: appointments } = useQuery({
    queryKey: ['appointments', business.id, selectedDate],
    queryFn: async () => {
      if (!selectedDate || !selectedService) return [];
      const dateStr = format(selectedDate, 'yyyy-MM-dd');
      return await base44.entities.Appointment.filter({
        business_id: business.id,
        service_id: selectedService.id,
        appointment_date: dateStr,
        status: { $in: ['agendado', 'confirmado'] }
      });
    },
    enabled: !!selectedDate && !!selectedService,
    initialData: [],
  });

  const { data: userAppointments } = useQuery({
    queryKey: ['user-appointments', user?.email],
    queryFn: () => base44.entities.Appointment.filter({
      user_email: user.email,
      status: { $in: ['agendado', 'confirmado', 'em_atendimento'] }
    }),
    initialData: [],
    enabled: !!user?.email,
  });

  const sendSMS = async (phone, message) => {
    if (!business?.sms_gateway || business.sms_gateway === 'none') {
      return;
    }

    await base44.integrations.Core.SendEmail({
      to: business.email,
      subject: 'SMS Enviado',
      body: `[SMS] Para: ${phone}\nMensagem: ${message}\nGateway: ${business.sms_gateway}`
    });
  };

  const bookMutation = useMutation({
    mutationFn: async (data) => {
      const now = new Date();
      const twentyMinutesAgo = new Date(now.getTime() - 20 * 60 * 1000);

      const hasRecentAppointment = userAppointments.some(apt => {
        const createdAt = new Date(apt.created_date);
        return createdAt >= twentyMinutesAgo && ['agendado', 'confirmado', 'em_atendimento'].includes(apt.status);
      });

      if (hasRecentAppointment) {
        toast.error('Já tem uma marcação ativa. Aguarde alguns minutos.');
        throw new Error('Já tem uma marcação ativa');
      }

      const token = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
      const appointment = await base44.entities.Appointment.create({
        ...data,
        management_token: token
      });

      const managementUrl = `${window.location.origin}${createPageUrl(`AppointmentManage?token=${token}`)}`;
      
      const emailBody = business.confirmation_email_template || 
        `Olá! A sua marcação foi confirmada.\n\nDetalhes:\nServiço: ${selectedService.name}\nData: ${format(selectedDate, 'dd/MM/yyyy', { locale: pt })}\nHora: ${selectedTime}\n\nGerir marcação: ${managementUrl}`;

      await base44.integrations.Core.SendEmail({
        to: user.email,
        subject: `Confirmação de Marcação - ${business.name}`,
        body: emailBody
      });

      if (business.sms_gateway !== 'none') {
        const smsBody = business.confirmation_sms_template || 
          `Marcação confirmada: ${selectedService.name} em ${format(selectedDate, 'dd/MM/yyyy')} às ${selectedTime} - ${business.name}`;
        
        await sendSMS(user.email, smsBody); 
      }

      return appointment;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['appointments'] });
      queryClient.invalidateQueries({ queryKey: ['user-appointments'] });
      toast.success('Marcação confirmada com sucesso!');
      onComplete?.();
    },
    onError: () => {}
  });

  const getScheduleForDate = (date) => {
    if (!selectedService) return null;
    
    const dayOfWeek = date.getDay();
    const customSchedule = selectedService.custom_schedules?.[dayOfWeek];
    
    if (customSchedule) {
      return customSchedule;
    }
    
    return {
      start: selectedService.start_time,
      end: selectedService.end_time,
      breaks: []
    };
  };

  const isTimeInBreak = (timeStr, breaks) => {
    if (!breaks || breaks.length === 0) return false;
    
    const [hour, min] = timeStr.split(':').map(Number);
    const timeMinutes = hour * 60 + min;
    
    return breaks.some(brk => {
      const [startHour, startMin] = brk.start.split(':').map(Number);
      const [endHour, endMin] = brk.end.split(':').map(Number);
      const breakStart = startHour * 60 + startMin;
      const breakEnd = endHour * 60 + endMin;
      
      return timeMinutes >= breakStart && timeMinutes < breakEnd;
    });
  };

  const generateTimeSlots = () => {
    if (!selectedService || !selectedDate) return [];

    const schedule = getScheduleForDate(selectedDate);
    if (!schedule) return [];

    const slots = [];
    const [startHour, startMin] = schedule.start.split(':').map(Number);
    const [endHour, endMin] = schedule.end.split(':').map(Number);
    
    const startTime = startHour * 60 + startMin;
    const endTime = endHour * 60 + endMin;
    const duration = selectedService.duration;
    const bufferTime = selectedService.buffer_time || 0;
    const slotInterval = duration + bufferTime;

    for (let time = startTime; time < endTime; time += slotInterval) {
      const hour = Math.floor(time / 60);
      const min = time % 60;
      const timeStr = `${String(hour).padStart(2, '0')}:${String(min).padStart(2, '0')}`;
      
      if (isTimeInBreak(timeStr, schedule.breaks)) {
        continue;
      }
      
      const isBooked = appointments.some(apt => {
        const aptTime = apt.appointment_time;
        const [aptHour, aptMin] = aptTime.split(':').map(Number);
        const aptMinutes = aptHour * 60 + aptMin;
        
        const aptSlotInterval = apt.duration + (apt.buffer_time || 0);

        const overlaps = (time < (aptMinutes + aptSlotInterval) && aptMinutes < (time + slotInterval));
        return overlaps;
      });
      
      slots.push({
        time: timeStr,
        available: !isBooked
      });
    }

    return slots;
  };

  const handleBook = () => {
    if (!selectedService || !selectedDate || !selectedTime) return;

    bookMutation.mutate({
      business_id: business.id,
      service_id: selectedService.id,
      user_email: user.email,
      appointment_date: format(selectedDate, 'yyyy-MM-dd'),
      appointment_time: selectedTime,
      status: 'agendado',
      notes: notes,
      duration: selectedService.duration,
      buffer_time: selectedService.buffer_time || 0
    });
  };

  const isDayAvailable = (date) => {
    if (!selectedService) return false;
    
    const dateStr = format(date, 'yyyy-MM-dd');
    if (selectedService.blocked_dates?.includes(dateStr)) {
      return false;
    }
    
    const dayOfWeek = date.getDay();
    return selectedService.available_days?.includes(dayOfWeek) ?? true;
  };

  const timeSlots = generateTimeSlots();
  
  const filteredServices = services.filter(service =>
    service.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    service.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    service.category?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CalendarIcon className="w-5 h-5" />
            Selecione o Serviço
          </CardTitle>
        </CardHeader>
        <CardContent>
          {services.length === 0 ? (
            <p className="text-center text-slate-500 py-8">
              Sem serviços disponíveis para agendamento
            </p>
          ) : (
            <>
              <div className="relative mb-4">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                <Input
                  placeholder="Pesquisar serviço..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 h-10 text-sm"
                />
              </div>
              
              {filteredServices.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-slate-500 mb-3">Nenhum serviço encontrado</p>
                  <Button size="sm" variant="outline" onClick={() => setSearchTerm('')}>
                    Limpar pesquisa
                  </Button>
                </div>
              ) : (
                <div className="grid md:grid-cols-2 gap-4">
                  {filteredServices.map(service => (
                    <Card
                      key={service.id}
                      className={`cursor-pointer transition-all ${
                        selectedService?.id === service.id
                          ? 'border-2 border-sky-500 shadow-lg'
                          : 'border hover:border-slate-300'
                      }`}
                      onClick={() => {
                        setSelectedService(service);
                        setSelectedDate(null);
                        setSelectedTime(null);
                      }}
                    >
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start mb-2">
                          <h4 className="font-bold text-slate-900">{service.name}</h4>
                          {selectedService?.id === service.id && (
                            <CheckCircle2 className="w-5 h-5 text-sky-500" />
                          )}
                        </div>
                        <p className="text-sm text-slate-600 mb-3">{service.description}</p>
                        <div className="flex gap-3 text-xs">
                          <Badge variant="secondary" className="gap-1">
                            <Clock className="w-3 h-3" />
                            {service.duration} min
                          </Badge>
                          {service.buffer_time > 0 && (
                            <Badge variant="outline" className="gap-1">
                              +{service.buffer_time} min buffer
                            </Badge>
                          )}
                          {service.price > 0 && (
                            <Badge variant="secondary" className="gap-1">
                              <Euro className="w-3 h-3" />
                              {service.price.toFixed(2)}
                            </Badge>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {selectedService && (
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle>Escolha a Data</CardTitle>
          </CardHeader>
          <CardContent className="flex justify-center">
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={(date) => {
                setSelectedDate(date);
                setSelectedTime(null);
              }}
              disabled={(date) => {
                const today = new Date();
                today.setHours(0, 0, 0, 0);
                return date < today || !isDayAvailable(date);
              }}
              locale={pt}
              className="rounded-md border"
            />
          </CardContent>
        </Card>
      )}

      {selectedDate && (
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle>
              Horários Disponíveis - {format(selectedDate, "dd 'de' MMMM", { locale: pt })}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {timeSlots.length === 0 ? (
              <p className="text-center text-slate-500 py-8">
                Sem horários disponíveis para esta data
              </p>
            ) : (
              <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
                {timeSlots.map(slot => (
                  <Button
                    key={slot.time}
                    variant={selectedTime === slot.time ? "default" : "outline"}
                    disabled={!slot.available}
                    onClick={() => setSelectedTime(slot.time)}
                    className={`${
                      !slot.available && 'opacity-50 cursor-not-allowed'
                    }`}
                  >
                    {slot.time}
                  </Button>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {selectedTime && (
        <Card className="border-0 shadow-lg bg-gradient-to-br from-sky-50 to-blue-50">
          <CardHeader>
            <CardTitle>Confirmar Marcação</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 bg-white rounded-xl">
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-600">Serviço:</span>
                  <span className="font-semibold text-slate-900">{selectedService.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Data:</span>
                  <span className="font-semibold text-slate-900">
                    {format(selectedDate, "dd/MM/yyyy", { locale: pt })}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Hora:</span>
                  <span className="font-semibold text-slate-900">{selectedTime}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Duração:</span>
                  <span className="font-semibold text-slate-900">{selectedService.duration} min</span>
                </div>
                {selectedService.buffer_time > 0 && (
                  <div className="flex justify-between">
                    <span className="text-slate-600">Buffer:</span>
                    <span className="font-semibold text-slate-900">{selectedService.buffer_time} min</span>
                  </div>
                )}
                {selectedService.price > 0 && (
                  <div className="flex justify-between pt-2 border-t">
                    <span className="text-slate-600">Preço:</span>
                    <span className="font-bold text-slate-900">€{selectedService.price.toFixed(2)}</span>
                  </div>
                )}
              </div>
            </div>

            <div>
              <Label htmlFor="notes">Observações (opcional)</Label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Informações adicionais..."
                rows={3}
              />
            </div>

            <Button
              className="w-full bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 py-6 text-lg"
              onClick={handleBook}
              disabled={bookMutation.isPending}
            >
              {bookMutation.isPending ? 'A processar...' : 'Confirmar Marcação'}
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}