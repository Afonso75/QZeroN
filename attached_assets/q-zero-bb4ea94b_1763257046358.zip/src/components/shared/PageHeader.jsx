import React from "react";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function PageHeader({ title, subtitle, backTo, actions }) {
  const navigate = useNavigate();

  return (
    <div className="mb-8 animate-slide-in-down">
      {backTo && (
        <Button
          variant="outline"
          className="mb-4 smooth-transition hover-lift"
          onClick={() => navigate(createPageUrl(backTo))}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar
        </Button>
      )}
      
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-2 gradient-text">
            {title}
          </h1>
          {subtitle && (
            <p className="text-xl text-slate-600 animate-fade-in">{subtitle}</p>
          )}
        </div>
        
        {actions && (
          <div className="flex gap-3 animate-scale-in">
            {actions}
          </div>
        )}
      </div>
    </div>
  );
}