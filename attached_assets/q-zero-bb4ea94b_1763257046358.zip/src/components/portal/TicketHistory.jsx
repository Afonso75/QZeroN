import React, { useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Clock, MapPin, Star, Eye, Loader2 } from "lucide-react";
import { format } from "date-fns";
import { pt } from "date-fns/locale";
import { Skeleton } from "@/components/ui/skeleton";

const statusConfig = {
  aguardando: { icon: Clock, color: "bg-blue-100 text-blue-700 border-blue-200", label: "Aguardando" },
  chamado: { icon: Clock, color: "bg-amber-100 text-amber-700 border-amber-200", label: "Chamado" },
  atendendo: { icon: Loader2, color: "bg-purple-100 text-purple-700 border-purple-200", label: "Atendendo" },
  concluido: { icon: Star, color: "bg-green-100 text-green-700 border-green-200", label: "Concluído" },
  cancelado: { icon: Clock, color: "bg-red-100 text-red-700 border-red-200", label: "Cancelado" }
};

export default function TicketHistory({ user }) {
  const queryClient = useQueryClient();

  const { data: tickets, isLoading } = useQuery({
    queryKey: ['customer-tickets', user?.email],
    queryFn: () => base44.entities.Ticket.filter({ user_email: user.email }, '-created_date'),
    initialData: [],
    refetchInterval: 5000,
    enabled: !!user?.email,
  });

  const { data: businesses } = useQuery({
    queryKey: ['businesses-list'],
    queryFn: () => base44.entities.Business.list(),
    initialData: [],
  });

  const { data: queues } = useQuery({
    queryKey: ['queues-list'],
    queryFn: () => base44.entities.Queue.list(),
    initialData: [],
  });

  const expireTicketsMutation = useMutation({
    mutationFn: async (ticketIds) => {
      for (const ticketId of ticketIds) {
        await base44.entities.Ticket.update(ticketId, {
          status: 'concluido',
          completed_at: new Date().toISOString()
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['customer-tickets'] });
    }
  });

  useEffect(() => {
    if (!tickets?.length || !queues?.length) return;

    const checkExpiredTickets = async () => {
      const now = new Date();
      const expiredTicketIds = [];

      for (const ticket of tickets) {
        if (!ticket || !['aguardando', 'chamado', 'atendendo'].includes(ticket.status)) continue;

        const queue = queues.find(q => q && q.id === ticket.queue_id);
        if (!queue) continue;

        if (ticket.status === 'chamado' && ticket.called_at) {
          const calledAt = new Date(ticket.called_at);
          const toleranceMs = (queue.tolerance_time || 15) * 60 * 1000;
          if (now - calledAt > toleranceMs) {
            expiredTicketIds.push(ticket.id);
          }
        }

        if (ticket.status === 'aguardando' && ticket.ticket_number < queue.current_number) {
          expiredTicketIds.push(ticket.id);
        }

        if (ticket.status === 'atendendo' && ticket.called_at) {
          const startedAt = new Date(ticket.called_at);
          const serviceTimeMs = (queue.average_service_time || 10) * 60 * 1000;
          const toleranceMs = (queue.tolerance_time || 15) * 60 * 1000;
          const totalAllowedMs = serviceTimeMs + toleranceMs;
          
          if (now - startedAt > totalAllowedMs) {
            expiredTicketIds.push(ticket.id);
          }
        }
      }

      if (expiredTicketIds.length > 0) {
        expireTicketsMutation.mutate(expiredTicketIds);
      }
    };

    checkExpiredTickets();
    const interval = setInterval(checkExpiredTickets, 5000);

    return () => clearInterval(interval);
  }, [tickets, queues, expireTicketsMutation]);

  const activeTickets = tickets.filter(t => t && ['aguardando', 'chamado', 'atendendo'].includes(t.status));
  const historyTickets = tickets.filter(t => t && ['concluido', 'cancelado'].includes(t.status));

  const getBusinessName = (businessId) => {
    return businesses.find(b => b && b.id === businessId)?.name || 'Empresa';
  };

  const getQueueName = (queueId) => {
    return queues.find(q => q && q.id === queueId)?.name || 'Fila';
  };

  const TicketCard = ({ ticket }) => {
    if (!ticket) return null;
    
    const status = statusConfig[ticket.status];
    const StatusIcon = status.icon;

    return (
      <Card className="border-0 shadow-lg hover:shadow-xl transition-all">
        <CardContent className="p-6">
          <div className="flex justify-between items-start mb-4">
            <div>
              <div className="text-4xl font-bold text-sky-600 mb-1">
                #{ticket.ticket_number}
              </div>
              <div className="flex items-center gap-2 text-slate-600">
                <MapPin className="w-4 h-4" />
                <span className="font-semibold">{getBusinessName(ticket.business_id)}</span>
              </div>
              <p className="text-sm text-slate-500">{getQueueName(ticket.queue_id)}</p>
            </div>
            <Badge className={status.color}>
              <StatusIcon className="w-3 h-3 mr-1" />
              {status.label}
            </Badge>
          </div>

          {ticket.status === 'aguardando' && (
            <div className="mb-4 p-3 bg-blue-50 rounded-lg">
              <p className="text-sm text-blue-800">
                <span className="font-semibold">Posição:</span> {ticket.position || '...'}
              </p>
              <p className="text-sm text-blue-800">
                <span className="font-semibold">Tempo estimado:</span> ~{ticket.estimated_time || '...'} min
              </p>
            </div>
          )}

          {ticket.rating && (
            <div className="mb-4 flex items-center gap-2">
              <div className="flex">
                {[1, 2, 3, 4, 5].map(star => (
                  <Star
                    key={star}
                    className={`w-4 h-4 ${star <= ticket.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-300'}`}
                  />
                ))}
              </div>
              <span className="text-sm text-slate-600">Sua avaliação</span>
            </div>
          )}

          <div className="flex justify-between items-center pt-4 border-t">
            <span className="text-xs text-slate-500">
              {format(new Date(ticket.created_date), "dd 'de' MMMM 'às' HH:mm", { locale: pt })}
            </span>
            <Link to={createPageUrl(`TicketView?id=${ticket.id}`)}>
              <Button size="sm" variant="outline">
                <Eye className="w-4 h-4 mr-2" />
                Ver Detalhes
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    );
  };

  if (isLoading) {
    return (
      <div className="grid md:grid-cols-2 gap-6">
        {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-64" />)}
      </div>
    );
  }

  return (
    <Tabs defaultValue="active">
      <TabsList className="bg-white border border-slate-200 mb-6">
        <TabsTrigger value="active">
          Ativas ({activeTickets.length})
        </TabsTrigger>
        <TabsTrigger value="history">
          Histórico ({historyTickets.length})
        </TabsTrigger>
      </TabsList>

      <TabsContent value="active">
        {activeTickets.length === 0 ? (
          <Card className="border-0 shadow-lg">
            <CardContent className="py-16 text-center">
              <Clock className="w-16 h-16 text-slate-400 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-slate-900 mb-2">
                Nenhuma senha ativa
              </h3>
              <p className="text-slate-600">
                Retire uma senha digital numa empresa para começar
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 gap-6">
            {activeTickets.map(ticket => (
              <TicketCard key={ticket.id} ticket={ticket} />
            ))}
          </div>
        )}
      </TabsContent>

      <TabsContent value="history">
        {historyTickets.length === 0 ? (
          <Card className="border-0 shadow-lg">
            <CardContent className="py-16 text-center">
              <Clock className="w-16 h-16 text-slate-400 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-slate-900 mb-2">
                Sem histórico
              </h3>
              <p className="text-slate-600">
                Suas senhas concluídas aparecerão aqui
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 gap-6">
            {historyTickets.map(ticket => (
              <TicketCard key={ticket.id} ticket={ticket} />
            ))}
          </div>
        )}
      </TabsContent>
    </Tabs>
  );
}