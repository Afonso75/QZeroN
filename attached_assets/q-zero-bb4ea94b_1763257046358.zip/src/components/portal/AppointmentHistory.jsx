import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Calendar, MapPin, Clock, X, Star } from "lucide-react";
import { format } from "date-fns";
import { pt } from "date-fns/locale";
import { Skeleton } from "@/components/ui/skeleton";

const statusConfig = {
  agendado: { color: "bg-blue-100 text-blue-700 border-blue-200", label: "Agendado" },
  confirmado: { color: "bg-green-100 text-green-700 border-green-200", label: "Confirmado" },
  em_atendimento: { color: "bg-purple-100 text-purple-700 border-purple-200", label: "Em Atendimento" },
  concluido: { color: "bg-slate-100 text-slate-700 border-slate-200", label: "Concluído" },
  cancelado: { color: "bg-red-100 text-red-700 border-red-200", label: "Cancelado" },
  falta: { color: "bg-orange-100 text-orange-700 border-orange-200", label: "Falta" }
};

export default function AppointmentHistory({ user }) {
  const queryClient = useQueryClient();

  const { data: appointments, isLoading } = useQuery({
    queryKey: ['customer-appointments', user.email],
    queryFn: () => base44.entities.Appointment.filter({ user_email: user.email }, '-appointment_date'),
    initialData: [],
  });

  const { data: businesses } = useQuery({
    queryKey: ['businesses-list'],
    queryFn: () => base44.entities.Business.list(),
    initialData: [],
  });

  const { data: services } = useQuery({
    queryKey: ['services-list'],
    queryFn: () => base44.entities.Service.list(),
    initialData: [],
  });

  const cancelMutation = useMutation({
    mutationFn: async (appointmentId) => {
      await base44.entities.Appointment.update(appointmentId, { status: 'cancelado' });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['customer-appointments'] });
    },
  });

  const upcomingAppointments = appointments.filter(a => 
    ['agendado', 'confirmado'].includes(a.status) &&
    new Date(a.appointment_date) >= new Date()
  );
  
  const pastAppointments = appointments.filter(a => 
    ['concluido', 'cancelado', 'falta'].includes(a.status) ||
    (new Date(a.appointment_date) < new Date() && a.status !== 'em_atendimento')
  );

  const getBusinessName = (businessId) => {
    return businesses.find(b => b.id === businessId)?.name || 'Empresa';
  };

  const getServiceName = (serviceId) => {
    return services.find(s => s.id === serviceId)?.name || 'Serviço';
  };

  const AppointmentCard = ({ appointment }) => {
    const status = statusConfig[appointment.status];
    const canCancel = ['agendado', 'confirmado'].includes(appointment.status) && 
                     new Date(appointment.appointment_date) > new Date();

    return (
      <Card className="border-0 shadow-lg hover:shadow-xl transition-all">
        <CardContent className="p-6">
          <div className="flex justify-between items-start mb-4">
            <div>
              <div className="flex items-center gap-2 text-slate-900 mb-2">
                <Calendar className="w-5 h-5 text-sky-600" />
                <span className="font-bold text-lg">
                  {format(new Date(appointment.appointment_date), "dd 'de' MMMM", { locale: pt })}
                </span>
                <span className="text-slate-600">às {appointment.appointment_time}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-600 mb-1">
                <MapPin className="w-4 h-4" />
                <span className="font-semibold">{getBusinessName(appointment.business_id)}</span>
              </div>
              <p className="text-sm text-slate-500">{getServiceName(appointment.service_id)}</p>
            </div>
            <Badge className={status.color}>
              {status.label}
            </Badge>
          </div>

          {appointment.notes && (
            <div className="mb-4 p-3 bg-slate-50 rounded-lg">
              <p className="text-sm text-slate-600">{appointment.notes}</p>
            </div>
          )}

          {appointment.rating && (
            <div className="mb-4 flex items-center gap-2">
              <div className="flex">
                {[1, 2, 3, 4, 5].map(star => (
                  <Star
                    key={star}
                    className={`w-4 h-4 ${star <= appointment.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-300'}`}
                  />
                ))}
              </div>
              {appointment.feedback && (
                <span className="text-sm text-slate-600">"{appointment.feedback}"</span>
              )}
            </div>
          )}

          <div className="flex justify-between items-center pt-4 border-t">
            <span className="text-xs text-slate-500">
              Criada em {format(new Date(appointment.created_date), "dd/MM/yyyy", { locale: pt })}
            </span>
            {canCancel && (
              <Button
                size="sm"
                variant="outline"
                className="border-red-200 text-red-600 hover:bg-red-50"
                onClick={() => {
                  if (confirm('Tem certeza que deseja cancelar esta marcação?')) {
                    cancelMutation.mutate(appointment.id);
                  }
                }}
                disabled={cancelMutation.isPending}
              >
                <X className="w-4 h-4 mr-2" />
                Cancelar
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    );
  };

  if (isLoading) {
    return (
      <div className="grid md:grid-cols-2 gap-6">
        {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-64" />)}
      </div>
    );
  }

  return (
    <Tabs defaultValue="upcoming">
      <TabsList className="bg-white border border-slate-200 mb-6">
        <TabsTrigger value="upcoming">
          Próximas ({upcomingAppointments.length})
        </TabsTrigger>
        <TabsTrigger value="past">
          Histórico ({pastAppointments.length})
        </TabsTrigger>
      </TabsList>

      <TabsContent value="upcoming">
        {upcomingAppointments.length === 0 ? (
          <Card className="border-0 shadow-lg">
            <CardContent className="py-16 text-center">
              <Calendar className="w-16 h-16 text-slate-400 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-slate-900 mb-2">
                Nenhuma marcação agendada
              </h3>
              <p className="text-slate-600">
                Agende um serviço numa empresa para começar
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 gap-6">
            {upcomingAppointments.map(appointment => (
              <AppointmentCard key={appointment.id} appointment={appointment} />
            ))}
          </div>
        )}
      </TabsContent>

      <TabsContent value="past">
        {pastAppointments.length === 0 ? (
          <Card className="border-0 shadow-lg">
            <CardContent className="py-16 text-center">
              <Clock className="w-16 h-16 text-slate-400 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-slate-900 mb-2">
                Sem histórico
              </h3>
              <p className="text-slate-600">
                Suas marcações concluídas aparecerão aqui
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 gap-6">
            {pastAppointments.map(appointment => (
              <AppointmentCard key={appointment.id} appointment={appointment} />
            ))}
          </div>
        )}
      </TabsContent>
    </Tabs>
  );
}