import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { User, Mail, Crown, Save, Phone, FileText, MapPin, Navigation } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

const countries = [
  { code: 'PT', name: 'Portugal', flag: '🇵🇹' },
  { code: 'ES', name: 'Espanha', flag: '🇪🇸' },
  { code: 'FR', name: 'França', flag: '🇫🇷' },
  { code: 'UK', name: 'Reino Unido', flag: '🇬🇧' },
  { code: 'DE', name: 'Alemanha', flag: '🇩🇪' },
  { code: 'IT', name: 'Itália', flag: '🇮🇹' },
  { code: 'NL', name: 'Holanda', flag: '🇳🇱' },
  { code: 'BE', name: 'Bélgica', flag: '🇧🇪' },
  { code: 'BR', name: 'Brasil', flag: '🇧🇷' },
  { code: 'US', name: 'Estados Unidos', flag: '🇺🇸' },
  { code: 'CA', name: 'Canadá', flag: '🇨🇦' },
  { code: 'CH', name: 'Suíça', flag: '🇨🇭' },
  { code: 'AT', name: 'Áustria', flag: '🇦🇹' },
  { code: 'LU', name: 'Luxemburgo', flag: '🇱🇺' },
  { code: 'IE', name: 'Irlanda', flag: '🇮🇪' },
  { code: 'SE', name: 'Suécia', flag: '🇸🇪' },
  { code: 'NO', name: 'Noruega', flag: '🇳🇴' },
  { code: 'DK', name: 'Dinamarca', flag: '🇩🇰' },
  { code: 'FI', name: 'Finlândia', flag: '🇫🇮' },
  { code: 'PL', name: 'Polónia', flag: '🇵🇱' },
  { code: 'CZ', name: 'República Checa', flag: '🇨🇿' },
  { code: 'GR', name: 'Grécia', flag: '🇬🇷' },
  { code: 'RO', name: 'Roménia', flag: '🇷🇴' },
  { code: 'HU', name: 'Hungria', flag: '🇭🇺' },
  { code: 'BG', name: 'Bulgária', flag: '🇧🇬' },
  { code: 'HR', name: 'Croácia', flag: '🇭🇷' }
];

export default function ProfileManager({ user, onUpdate }) {
  const displayName = user.nome_completo || user.full_name || '';
  
  const [formData, setFormData] = useState({
    nome_completo: displayName,
    phone: user.phone || '',
    nif: user.nif || '',
    data_nascimento: user.data_nascimento || '',
    country: user.country || '',
    city: user.city || ''
  });

  useEffect(() => {
    const newDisplayName = user.nome_completo || user.full_name || '';
    setFormData({
      nome_completo: newDisplayName,
      phone: user.phone || '',
      nif: user.nif || '',
      data_nascimento: user.data_nascimento || '',
      country: user.country || '',
      city: user.city || ''
    });
  }, [user.id, user.nome_completo, user.full_name, user.phone, user.nif, user.data_nascimento, user.country, user.city]);

  const { data: subscription } = useQuery({
    queryKey: ['user-subscription', user.email],
    queryFn: async () => {
      const subs = await base44.entities.Subscription.filter({ 
        user_email: user.email,
        status: "active"
      });
      return subs[0] || null;
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (updates) => {
      return await base44.auth.updateMe(updates);
    },
    onSuccess: async () => {
      toast.success('Perfil atualizado com sucesso!');
      if (onUpdate) {
        await onUpdate();
      }
    },
    onError: (error) => {
      console.error('Erro ao atualizar:', error);
      toast.error('Erro ao atualizar perfil');
    }
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.nome_completo.trim()) {
      toast.error('Nome completo é obrigatório');
      return;
    }
    
    updateMutation.mutate({
      nome_completo: formData.nome_completo.trim(),
      phone: formData.phone.trim(),
      nif: formData.nif.trim(),
      data_nascimento: formData.data_nascimento,
      country: formData.country,
      city: formData.city.trim()
    });
  };

  const isPremium = subscription?.plan === "premium";

  return (
    <div className="space-y-4 w-full max-w-full overflow-hidden">
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <User className="w-4 h-4" />
            Informações da Conta
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col gap-2 p-3 bg-slate-50 rounded-lg">
            <div className="flex flex-wrap items-center gap-2">
              <Mail className="w-4 h-4 text-slate-600 flex-shrink-0" />
              <span className="font-semibold text-sm text-slate-900 break-all">{user.email}</span>
              {isPremium && (
                <Badge className="bg-gradient-to-r from-purple-500 to-pink-600 text-white border-0 text-xs">
                  <Crown className="w-3 h-3 mr-1" />
                  Premium
                </Badge>
              )}
            </div>
            <p className="text-xs text-slate-600">
              Membro desde {new Date(user.created_date).toLocaleDateString('pt-PT', { 
                month: 'long', 
                year: 'numeric' 
              })}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <Label htmlFor="nome_completo" className="text-sm">Nome Completo *</Label>
              <Input
                id="nome_completo"
                value={formData.nome_completo}
                onChange={(e) => setFormData(prev => ({ ...prev, nome_completo: e.target.value }))}
                placeholder="Seu nome"
                className="mt-1"
                required
              />
            </div>

            <div>
              <Label htmlFor="nif" className="text-sm">NIF *</Label>
              <div className="flex gap-2">
                <FileText className="w-4 h-4 text-slate-400 mt-2.5 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <Input
                    id="nif"
                    value={formData.nif}
                    onChange={(e) => setFormData(prev => ({ ...prev, nif: e.target.value }))}
                    placeholder="123456789"
                    className="w-full"
                    required
                  />
                </div>
              </div>
            </div>

            <div>
              <Label htmlFor="data_nascimento" className="text-sm">Data de Nascimento *</Label>
              <Input
                id="data_nascimento"
                type="date"
                value={formData.data_nascimento}
                onChange={(e) => setFormData(prev => ({ ...prev, data_nascimento: e.target.value }))}
                className="mt-1"
                required
              />
            </div>

            <div>
              <Label htmlFor="phone" className="text-sm">Telefone *</Label>
              <div className="flex gap-2">
                <Phone className="w-4 h-4 text-slate-400 mt-2.5 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <Input
                    id="phone"
                    value={formData.phone}
                    onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                    placeholder="+351 912 345 678"
                    className="w-full"
                    required
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <Label htmlFor="country" className="text-sm">País *</Label>
                <div className="flex gap-2">
                  <MapPin className="w-4 h-4 text-slate-400 mt-2.5 flex-shrink-0" />
                  <Select 
                    value={formData.country} 
                    onValueChange={(value) => setFormData(prev => ({ ...prev, country: value }))}
                  >
                    <SelectTrigger className="flex-1">
                      <SelectValue placeholder="Selecione o país" />
                    </SelectTrigger>
                    <SelectContent>
                      {countries.map(c => (
                        <SelectItem key={c.code} value={c.code}>
                          {c.flag} {c.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="city" className="text-sm">Cidade</Label>
                <div className="flex gap-2">
                  <Navigation className="w-4 h-4 text-slate-400 mt-2.5 flex-shrink-0" />
                  <Input
                    id="city"
                    value={formData.city}
                    onChange={(e) => setFormData(prev => ({ ...prev, city: e.target.value }))}
                    placeholder="Lisboa, Porto, Madrid..."
                    className="flex-1"
                  />
                </div>
              </div>
            </div>

            <Button
              type="submit"
              disabled={updateMutation.isPending}
              className="w-full bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700"
            >
              <Save className="w-4 h-4 mr-2" />
              {updateMutation.isPending ? 'A guardar...' : 'Guardar Alterações'}
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="text-base">Suas Estatísticas</CardTitle>
        </CardHeader>
        <CardContent>
          <Statistics user={user} />
        </CardContent>
      </Card>
    </div>
  );
}

function Statistics({ user }) {
  const { data: tickets, isLoading: loadingTickets } = useQuery({
    queryKey: ['user-tickets-stats', user.email],
    queryFn: () => base44.entities.Ticket.filter({ user_email: user.email }),
    initialData: [],
  });

  const { data: appointments, isLoading: loadingAppointments } = useQuery({
    queryKey: ['user-appointments-stats', user.email],
    queryFn: () => base44.entities.Appointment.filter({ user_email: user.email }),
    initialData: [],
  });

  if (loadingTickets || loadingAppointments) {
    return <Skeleton className="h-32" />;
  }

  const completedTickets = tickets.filter(t => t.status === 'concluido');
  const completedAppointments = appointments.filter(a => a.status === 'concluido');
  const avgTicketRating = completedTickets.reduce((sum, t) => sum + (t.rating || 0), 0) / (completedTickets.filter(t => t.rating).length || 1);

  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
      <div className="p-3 bg-gradient-to-br from-blue-50 to-sky-50 rounded-lg">
        <div className="text-2xl font-bold text-blue-600 mb-1">{tickets.length}</div>
        <p className="text-xs text-slate-600">Senhas Retiradas</p>
      </div>

      <div className="p-3 bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg">
        <div className="text-2xl font-bold text-purple-600 mb-1">{appointments.length}</div>
        <p className="text-xs text-slate-600">Marcações Feitas</p>
      </div>

      <div className="p-3 bg-gradient-to-br from-amber-50 to-orange-50 rounded-lg">
        <div className="text-2xl font-bold text-amber-600 mb-1">{avgTicketRating.toFixed(1)}</div>
        <p className="text-xs text-slate-600">Avaliação Média</p>
      </div>
    </div>
  );
}