import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Plus, X, Clock, CalendarX } from "lucide-react";
import { format } from "date-fns";
import { pt } from "date-fns/locale";

const daysOfWeek = [
  { value: 0, label: 'Domingo' },
  { value: 1, label: 'Segunda' },
  { value: 2, label: 'Terça' },
  { value: 3, label: 'Quarta' },
  { value: 4, label: 'Quinta' },
  { value: 5, label: 'Sexta' },
  { value: 6, label: 'Sábado' }
];

export default function ServiceScheduleConfig({ formData, setFormData }) {
  const [selectedDay, setSelectedDay] = useState(null);
  const [blockDate, setBlockDate] = useState(null);

  const addCustomSchedule = (day) => {
    const customSchedules = formData.custom_schedules || {};
    customSchedules[day] = {
      start: '09:00',
      end: '18:00',
      breaks: []
    };
    setFormData({ ...formData, custom_schedules: customSchedules });
    setSelectedDay(day);
  };

  const removeCustomSchedule = (day) => {
    const customSchedules = { ...formData.custom_schedules };
    delete customSchedules[day];
    setFormData({ ...formData, custom_schedules: customSchedules });
    if (selectedDay === day) setSelectedDay(null);
  };

  const updateCustomSchedule = (day, field, value) => {
    const customSchedules = { ...formData.custom_schedules };
    customSchedules[day] = { ...customSchedules[day], [field]: value };
    setFormData({ ...formData, custom_schedules: customSchedules });
  };

  const addBreak = (day) => {
    const customSchedules = { ...formData.custom_schedules };
    const breaks = customSchedules[day].breaks || [];
    breaks.push({ start: '12:00', end: '13:00' });
    customSchedules[day].breaks = breaks;
    setFormData({ ...formData, custom_schedules: customSchedules });
  };

  const removeBreak = (day, index) => {
    const customSchedules = { ...formData.custom_schedules };
    customSchedules[day].breaks.splice(index, 1);
    setFormData({ ...formData, custom_schedules: customSchedules });
  };

  const updateBreak = (day, index, field, value) => {
    const customSchedules = { ...formData.custom_schedules };
    customSchedules[day].breaks[index][field] = value;
    setFormData({ ...formData, custom_schedules: customSchedules });
  };

  const addBlockedDate = () => {
    if (!blockDate) return;
    const blocked = formData.blocked_dates || [];
    const dateStr = format(blockDate, 'yyyy-MM-dd');
    if (!blocked.includes(dateStr)) {
      setFormData({ ...formData, blocked_dates: [...blocked, dateStr] });
    }
    setBlockDate(null);
  };

  const removeBlockedDate = (date) => {
    const blocked = formData.blocked_dates.filter(d => d !== date);
    setFormData({ ...formData, blocked_dates: blocked });
  };

  const customSchedules = formData.custom_schedules || {};

  return (
    <div className="space-y-6">
      {/* Default Schedule */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Clock className="w-4 h-4" />
            Horário Padrão
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="start_time">Início</Label>
              <Input
                id="start_time"
                type="time"
                value={formData.start_time}
                onChange={(e) => setFormData({ ...formData, start_time: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="end_time">Fim</Label>
              <Input
                id="end_time"
                type="time"
                value={formData.end_time}
                onChange={(e) => setFormData({ ...formData, end_time: e.target.value })}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Custom Schedules per Day */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Horários Personalizados por Dia</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap gap-2">
            {daysOfWeek.map(day => {
              const hasCustom = customSchedules[day.value];
              return (
                <Button
                  key={day.value}
                  type="button"
                  size="sm"
                  variant={hasCustom ? "default" : "outline"}
                  onClick={() => hasCustom ? setSelectedDay(day.value) : addCustomSchedule(day.value)}
                >
                  {day.label}
                  {hasCustom && <Badge className="ml-2 bg-white text-sky-600">!</Badge>}
                </Button>
              );
            })}
          </div>

          {selectedDay !== null && customSchedules[selectedDay] && (
            <Card className="border-2 border-sky-200">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-sm">
                    {daysOfWeek.find(d => d.value === selectedDay)?.label}
                  </CardTitle>
                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    onClick={() => removeCustomSchedule(selectedDay)}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-xs">Início</Label>
                    <Input
                      type="time"
                      value={customSchedules[selectedDay].start}
                      onChange={(e) => updateCustomSchedule(selectedDay, 'start', e.target.value)}
                    />
                  </div>
                  <div>
                    <Label className="text-xs">Fim</Label>
                    <Input
                      type="time"
                      value={customSchedules[selectedDay].end}
                      onChange={(e) => updateCustomSchedule(selectedDay, 'end', e.target.value)}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-2">
                    <Label className="text-xs">Pausas/Intervalos</Label>
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      onClick={() => addBreak(selectedDay)}
                    >
                      <Plus className="w-3 h-3 mr-1" />
                      Adicionar
                    </Button>
                  </div>
                  {customSchedules[selectedDay].breaks?.map((brk, idx) => (
                    <div key={idx} className="flex gap-2 mb-2">
                      <Input
                        type="time"
                        value={brk.start}
                        onChange={(e) => updateBreak(selectedDay, idx, 'start', e.target.value)}
                        className="flex-1"
                      />
                      <Input
                        type="time"
                        value={brk.end}
                        onChange={(e) => updateBreak(selectedDay, idx, 'end', e.target.value)}
                        className="flex-1"
                      />
                      <Button
                        type="button"
                        size="sm"
                        variant="ghost"
                        onClick={() => removeBreak(selectedDay, idx)}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </CardContent>
      </Card>

      {/* Blocked Dates */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <CalendarX className="w-4 h-4" />
            Datas Bloqueadas (Férias/Feriados)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Popover>
              <PopoverTrigger asChild>
                <Button type="button" variant="outline" className="flex-1">
                  {blockDate ? format(blockDate, 'PPP', { locale: pt }) : 'Selecionar data'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={blockDate}
                  onSelect={setBlockDate}
                  locale={pt}
                />
              </PopoverContent>
            </Popover>
            <Button type="button" onClick={addBlockedDate} disabled={!blockDate}>
              <Plus className="w-4 h-4" />
            </Button>
          </div>

          {formData.blocked_dates && formData.blocked_dates.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {formData.blocked_dates.map(date => (
                <Badge key={date} variant="secondary" className="gap-2">
                  {format(new Date(date + 'T00:00:00'), 'dd/MM/yyyy')}
                  <button
                    type="button"
                    onClick={() => removeBlockedDate(date)}
                    className="hover:text-red-600"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </Badge>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}