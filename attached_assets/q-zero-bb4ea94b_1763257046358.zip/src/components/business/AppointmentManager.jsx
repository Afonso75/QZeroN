
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { 
  Calendar, 
  Clock, 
  User, 
  CheckCircle2, 
  XCircle, 
  AlertCircle,
  UserPlus
} from "lucide-react";
import { format } from "date-fns";

const statusConfig = {
  agendado: { icon: Calendar, color: "bg-blue-100 text-blue-700", label: "Agendado" },
  confirmado: { icon: CheckCircle2, color: "bg-green-100 text-green-700", label: "Confirmado" },
  em_atendimento: { icon: Clock, color: "bg-purple-100 text-purple-700", label: "Em Atendimento" },
  concluido: { icon: CheckCircle2, color: "bg-green-100 text-green-700", label: "Concluído" },
  cancelado: { icon: XCircle, color: "bg-red-100 text-red-700", label: "Cancelado" },
  falta: { icon: AlertCircle, color: "bg-orange-100 text-orange-700", label: "Faltou" }
};

export default function AppointmentManager({ businessId }) {
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("hoje");
  const [showManualForm, setShowManualForm] = useState(false);
  const [manualData, setManualData] = useState({
    user_email: "",
    service_id: "",
    appointment_date: "",
    appointment_time: "",
    notes: "",
    user_name: ""
  });

  const { data: appointments, isLoading } = useQuery({
    queryKey: ['business-appointments', businessId],
    queryFn: () => base44.entities.Appointment.filter({ business_id: businessId }, '-appointment_date'),
    initialData: [],
    refetchInterval: 30000,
  });

  const { data: services } = useQuery({
    queryKey: ['services', businessId],
    queryFn: () => base44.entities.Service.filter({ business_id: businessId }),
    initialData: [],
  });

  const updateStatusMutation = useMutation({
    mutationFn: ({ id, status }) => base44.entities.Appointment.update(id, { status }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['business-appointments'] });
    },
  });

  const createManualAppointmentMutation = useMutation({
    mutationFn: async () => {
      await base44.entities.Appointment.create({
        business_id: businessId,
        service_id: manualData.service_id,
        user_email: manualData.user_email || `presencial_${Date.now()}@temp.local`,
        appointment_date: manualData.appointment_date,
        appointment_time: manualData.appointment_time,
        status: "agendado",
        notes: manualData.notes || `Cliente: ${manualData.user_name || 'Presencial'}`,
        is_manual: true,
        manual_name: manualData.user_name || 'Cliente Presencial'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['business-appointments'] });
      setManualData({
        user_email: "",
        service_id: "",
        appointment_date: "",
        appointment_time: "",
        notes: "",
        user_name: ""
      });
      setShowManualForm(false);
    },
  });

  const getServiceName = (serviceId) => {
    return services.find(s => s.id === serviceId)?.name || 'Serviço';
  };

  const upcomingAppointments = appointments.filter(apt => {
    const aptDate = new Date(`${apt.appointment_date}T${apt.appointment_time}`);
    return ['agendado', 'confirmado'].includes(apt.status) && aptDate >= new Date();
  });

  const todayAppointments = appointments.filter(apt => {
    const today = format(new Date(), 'yyyy-MM-dd');
    return apt.appointment_date === today && ['agendado', 'confirmado', 'em_atendimento'].includes(apt.status);
  });

  const pastAppointments = appointments.filter(apt => {
    const aptDate = new Date(`${apt.appointment_date}T${apt.appointment_time}`);
    return ['concluido', 'cancelado', 'falta'].includes(apt.status) || 
           (aptDate < new Date() && !['concluido', 'cancelado', 'falta'].includes(apt.status));
  });

  const renderAppointment = (appointment) => {
    const status = statusConfig[appointment.status];
    const StatusIcon = status.icon;

    return (
      <Card key={appointment.id} className="hover:shadow-md transition-shadow">
        <CardContent className="p-3">
          <div className="flex justify-between items-start mb-2">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5 mb-1 flex-wrap">
                <h4 className="font-bold text-slate-900 text-xs truncate">{getServiceName(appointment.service_id)}</h4>
                <Badge className={`${status.color} text-xs h-4 px-1`}>
                  <StatusIcon className="w-2.5 h-2.5 mr-0.5" />
                  {status.label}
                </Badge>
                {appointment.is_manual && (
                  <Badge variant="outline" className="bg-blue-50 text-blue-700 text-xs h-4 px-1">
                    Presencial
                  </Badge>
                )}
              </div>
              <div className="space-y-0.5 text-xs text-slate-600">
                <div className="flex items-center gap-1">
                  <User className="w-3 h-3" />
                  <span className="truncate">{appointment.manual_name || appointment.user_email}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  {format(new Date(appointment.appointment_date + 'T00:00:00'), 'dd/MM/yyyy')}
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {appointment.appointment_time}
                </div>
              </div>
            </div>
          </div>

          {appointment.notes && (
            <div className="mb-2 p-1.5 bg-slate-50 rounded text-xs text-slate-600 line-clamp-2">
              <strong>Notas:</strong> {appointment.notes}
            </div>
          )}

          <div className="flex flex-wrap gap-1">
            {appointment.status === 'agendado' && (
              <>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => updateStatusMutation.mutate({ id: appointment.id, status: 'confirmado' })}
                  className="h-7 text-xs flex-1"
                >
                  <CheckCircle2 className="w-3 h-3 mr-1" />
                  Confirmar
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-red-200 text-red-600 hover:bg-red-50 h-7 text-xs flex-1"
                  onClick={() => updateStatusMutation.mutate({ id: appointment.id, status: 'cancelado' })}
                >
                  <XCircle className="w-3 h-3 mr-1" />
                  Cancelar
                </Button>
              </>
            )}

            {appointment.status === 'confirmado' && (
              <>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => updateStatusMutation.mutate({ id: appointment.id, status: 'em_atendimento' })}
                  className="h-7 text-xs flex-1"
                >
                  <Clock className="w-3 h-3 mr-1" />
                  Iniciar
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-orange-200 text-orange-600 hover:bg-orange-50 h-7 text-xs"
                  onClick={() => updateStatusMutation.mutate({ id: appointment.id, status: 'falta' })}
                >
                  Faltou
                </Button>
              </>
            )}

            {appointment.status === 'em_atendimento' && (
              <Button
                size="sm"
                variant="outline"
                className="border-green-200 text-green-600 hover:bg-green-50 h-7 text-xs w-full"
                onClick={() => updateStatusMutation.mutate({ id: appointment.id, status: 'concluido' })}
              >
                <CheckCircle2 className="w-3 h-3 mr-1" />
                Concluir
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    );
  };

  if (isLoading) {
    return <div className="text-center py-6 text-xs">A carregar...</div>;
  }

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-3 gap-2">
        <Card>
          <CardContent className="p-2">
            <div className="text-lg font-bold text-slate-900">{todayAppointments.length}</div>
            <div className="text-xs text-slate-600">Hoje</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-2">
            <div className="text-lg font-bold text-slate-900">{upcomingAppointments.length}</div>
            <div className="text-xs text-slate-600">Próximas</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-2">
            <div className="text-lg font-bold text-slate-900">{pastAppointments.length}</div>
            <div className="text-xs text-slate-600">Histórico</div>
          </CardContent>
        </Card>
      </div>

      <Button
        onClick={() => setShowManualForm(!showManualForm)}
        className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 h-9 text-xs"
      >
        <UserPlus className="w-3 h-3 mr-1" />
        Marcação Manual
      </Button>

      {showManualForm && (
        <Card className="border-blue-200 bg-blue-50">
          <CardHeader className="p-3 pb-2">
            <CardTitle className="flex items-center gap-2 text-sm">
              <UserPlus className="w-4 h-4" />
              Nova Marcação
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 p-3">
            <div>
              <Label htmlFor="userName" className="text-xs">Nome (opcional)</Label>
              <Input
                id="userName"
                value={manualData.user_name}
                onChange={(e) => setManualData({...manualData, user_name: e.target.value})}
                placeholder="Nome"
                className="h-8 text-xs"
              />
            </div>

            <div>
              <Label htmlFor="userEmail" className="text-xs">Email/Tel (opcional)</Label>
              <Input
                id="userEmail"
                value={manualData.user_email}
                onChange={(e) => setManualData({...manualData, user_email: e.target.value})}
                placeholder="Contacto"
                className="h-8 text-xs"
              />
            </div>

            <div>
              <Label htmlFor="service" className="text-xs">Serviço *</Label>
              <Select
                value={manualData.service_id}
                onValueChange={(value) => setManualData({...manualData, service_id: value})}
              >
                <SelectTrigger className="h-8 text-xs">
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  {services.map(service => (
                    <SelectItem key={service.id} value={service.id} className="text-xs">
                      {service.name} ({service.duration} min)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label htmlFor="date" className="text-xs">Data *</Label>
                <Input
                  id="date"
                  type="date"
                  value={manualData.appointment_date}
                  onChange={(e) => setManualData({...manualData, appointment_date: e.target.value})}
                  className="h-8 text-xs"
                />
              </div>

              <div>
                <Label htmlFor="time" className="text-xs">Hora *</Label>
                <Input
                  id="time"
                  type="time"
                  value={manualData.appointment_time}
                  onChange={(e) => setManualData({...manualData, appointment_time: e.target.value})}
                  className="h-8 text-xs"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="notes" className="text-xs">Notas</Label>
              <Textarea
                id="notes"
                value={manualData.notes}
                onChange={(e) => setManualData({...manualData, notes: e.target.value})}
                placeholder="Observações..."
                rows={2}
                className="resize-none text-xs"
              />
            </div>

            <div className="flex gap-2">
              <Button
                onClick={() => createManualAppointmentMutation.mutate()}
                disabled={!manualData.service_id || !manualData.appointment_date || !manualData.appointment_time || createManualAppointmentMutation.isPending}
                className="flex-1 h-8 text-xs"
              >
                {createManualAppointmentMutation.isPending ? 'Criando...' : 'Criar'}
              </Button>
              <Button
                variant="outline"
                onClick={() => setShowManualForm(false)}
                className="h-8 text-xs"
              >
                Cancelar
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-white border border-slate-200 w-full">
          <TabsTrigger value="hoje" className="text-xs">Hoje ({todayAppointments.length})</TabsTrigger>
          <TabsTrigger value="proximas" className="text-xs">Próx ({upcomingAppointments.length})</TabsTrigger>
          <TabsTrigger value="historico" className="text-xs">Hist ({pastAppointments.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="hoje">
          {todayAppointments.length === 0 ? (
            <Card>
              <CardContent className="py-6 text-center text-slate-500 text-xs">
                Sem marcações hoje
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-2">
              {todayAppointments.map(renderAppointment)}
            </div>
          )}
        </TabsContent>

        <TabsContent value="proximas">
          {upcomingAppointments.length === 0 ? (
            <Card>
              <CardContent className="py-6 text-center text-slate-500 text-xs">
                Sem marcações futuras
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-2">
              {upcomingAppointments.map(renderAppointment)}
            </div>
          )}
        </TabsContent>

        <TabsContent value="historico">
          {pastAppointments.length === 0 ? (
            <Card>
              <CardContent className="py-6 text-center text-slate-500 text-xs">
                Sem histórico
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-2">
              {pastAppointments.map(renderAppointment)}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
