import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Bell, Save, Mail, MessageSquare } from "lucide-react";

export default function NotificationSettings({ queue }) {
  const queryClient = useQueryClient();
  const [enabled, setEnabled] = useState(queue.notifications_enabled ?? true);
  const [settings, setSettings] = useState(queue.notification_settings || {
    email: true,
    sms: false,
    advance_notice: 2
  });

  const updateMutation = useMutation({
    mutationFn: (data) => base44.entities.Queue.update(queue.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['business-queues'] });
    },
  });

  const handleSave = () => {
    updateMutation.mutate({
      notifications_enabled: enabled,
      notification_settings: settings
    });
  };

  return (
    <Card className="border-0 shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="w-5 h-5" />
          Notificações Automáticas
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
          <Label className="font-semibold">Ativar Notificações</Label>
          <Switch checked={enabled} onCheckedChange={setEnabled} />
        </div>

        {enabled && (
          <>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-slate-600" />
                  <Label>Email</Label>
                </div>
                <Switch 
                  checked={settings.email} 
                  onCheckedChange={(checked) => setSettings({...settings, email: checked})} 
                />
              </div>

              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                <div className="flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-slate-600" />
                  <Label>SMS</Label>
                </div>
                <Switch 
                  checked={settings.sms} 
                  onCheckedChange={(checked) => setSettings({...settings, sms: checked})} 
                />
              </div>
            </div>

            <div>
              <Label>Avisar quando faltarem (senhas)</Label>
              <Input
                type="number"
                min="1"
                max="10"
                value={settings.advance_notice}
                onChange={(e) => setSettings({...settings, advance_notice: parseInt(e.target.value)})}
                className="mt-2"
              />
              <p className="text-xs text-slate-500 mt-1">
                O cliente será notificado quando faltarem esta quantidade de senhas
              </p>
            </div>
          </>
        )}

        <Button 
          onClick={handleSave}
          disabled={updateMutation.isPending}
          className="w-full gap-2"
        >
          <Save className="w-4 h-4" />
          {updateMutation.isPending ? 'Salvando...' : 'Salvar Configurações'}
        </Button>
      </CardContent>
    </Card>
  );
}