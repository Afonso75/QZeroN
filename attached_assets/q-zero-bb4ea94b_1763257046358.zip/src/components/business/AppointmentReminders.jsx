import { useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";

export default function AppointmentReminders({ businessId }) {
  const { data: appointments } = useQuery({
    queryKey: ['upcoming-appointments', businessId],
    queryFn: () => base44.entities.Appointment.filter({
      business_id: businessId,
      status: { $in: ['agendado', 'confirmado'] }
    }),
    initialData: [],
    refetchInterval: 60000, // Check every minute
  });

  const { data: business } = useQuery({
    queryKey: ['business', businessId],
    queryFn: async () => {
      const businesses = await base44.entities.Business.filter({ id: businessId });
      return businesses[0];
    },
    enabled: !!businessId,
  });

  const sendSMS = async (phone, message) => {
    if (!business?.sms_gateway || business.sms_gateway === 'none') {
      return; // SMS not configured
    }

    // In production, this would make actual API calls to Twilio/Vonage
    // For now, we simulate it via email notification
    await base44.integrations.Core.SendEmail({
      to: business.email,
      subject: 'SMS Enviado',
      body: `[SMS] Para: ${phone}\nMensagem: ${message}\nGateway: ${business.sms_gateway}`
    });
  };

  useEffect(() => {
    if (!appointments || !business) return;

    appointments.forEach(async (appointment) => {
      const appointmentDate = new Date(appointment.appointment_date);
      const now = new Date();
      const hoursUntil = (appointmentDate - now) / (1000 * 60 * 60);

      // Send reminder 24 hours before
      if (hoursUntil <= 24 && hoursUntil > 23.5 && !appointment.reminder_sent) {
        // Send email reminder
        const emailBody = business.reminder_email_template || 
          `Lembrete: Tem uma marcação amanhã às ${appointment.appointment_time} - ${business.name}`;

        await base44.integrations.Core.SendEmail({
          to: appointment.user_email,
          subject: `Lembrete de Marcação - ${business.name}`,
          body: emailBody
        });

        // Send SMS reminder if configured
        if (business.sms_gateway !== 'none') {
          const smsBody = business.reminder_sms_template || 
            `Lembrete: Marcação amanhã às ${appointment.appointment_time} em ${business.name}`;
          
          await sendSMS(appointment.user_email, smsBody);
        }

        // Mark as sent
        await base44.entities.Appointment.update(appointment.id, {
          reminder_sent: true
        });
      }
    });
  }, [appointments, business]);

  return null; // This is a background component
}