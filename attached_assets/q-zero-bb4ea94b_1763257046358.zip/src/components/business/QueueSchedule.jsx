import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Clock, Save } from "lucide-react";

const daysOfWeek = [
  { value: 0, label: "Domingo" },
  { value: 1, label: "Segunda" },
  { value: 2, label: "Terça" },
  { value: 3, label: "Quarta" },
  { value: 4, label: "Quinta" },
  { value: 5, label: "Sexta" },
  { value: 6, label: "Sábado" }
];

export default function QueueSchedule({ queue }) {
  const queryClient = useQueryClient();
  const [schedule, setSchedule] = useState(queue.working_hours || {});

  const updateMutation = useMutation({
    mutationFn: (data) => base44.entities.Queue.update(queue.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['business-queues'] });
    },
  });

  const toggleDay = (day) => {
    const newSchedule = { ...schedule };
    if (newSchedule[day]) {
      delete newSchedule[day];
    } else {
      newSchedule[day] = {
        start: "09:00",
        end: "18:00",
        break: { start: "12:00", end: "13:00" }
      };
    }
    setSchedule(newSchedule);
  };

  const updateDaySchedule = (day, field, value) => {
    setSchedule({
      ...schedule,
      [day]: {
        ...schedule[day],
        [field]: value
      }
    });
  };

  const updateBreak = (day, field, value) => {
    setSchedule({
      ...schedule,
      [day]: {
        ...schedule[day],
        break: {
          ...schedule[day].break,
          [field]: value
        }
      }
    });
  };

  const handleSave = () => {
    updateMutation.mutate({ working_hours: schedule });
  };

  return (
    <Card className="border-0 shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="w-5 h-5" />
          Horários de Funcionamento
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {daysOfWeek.map(({ value, label }) => (
          <div key={value} className="p-4 bg-slate-50 rounded-lg">
            <div className="flex items-center justify-between mb-3">
              <Label className="font-semibold">{label}</Label>
              <Switch
                checked={!!schedule[value]}
                onCheckedChange={() => toggleDay(value)}
              />
            </div>
            
            {schedule[value] && (
              <div className="space-y-3 ml-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-xs">Abertura</Label>
                    <Input
                      type="time"
                      value={schedule[value].start}
                      onChange={(e) => updateDaySchedule(value, 'start', e.target.value)}
                      className="h-9"
                    />
                  </div>
                  <div>
                    <Label className="text-xs">Fecho</Label>
                    <Input
                      type="time"
                      value={schedule[value].end}
                      onChange={(e) => updateDaySchedule(value, 'end', e.target.value)}
                      className="h-9"
                    />
                  </div>
                </div>
                
                {schedule[value].break && (
                  <div className="grid grid-cols-2 gap-3 pt-2 border-t">
                    <div>
                      <Label className="text-xs text-slate-600">Pausa Início</Label>
                      <Input
                        type="time"
                        value={schedule[value].break.start}
                        onChange={(e) => updateBreak(value, 'start', e.target.value)}
                        className="h-9"
                      />
                    </div>
                    <div>
                      <Label className="text-xs text-slate-600">Pausa Fim</Label>
                      <Input
                        type="time"
                        value={schedule[value].break.end}
                        onChange={(e) => updateBreak(value, 'end', e.target.value)}
                        className="h-9"
                      />
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
        
        <Button 
          onClick={handleSave}
          disabled={updateMutation.isPending}
          className="w-full gap-2"
        >
          <Save className="w-4 h-4" />
          {updateMutation.isPending ? 'Salvando...' : 'Salvar Horários'}
        </Button>
      </CardContent>
    </Card>
  );
}