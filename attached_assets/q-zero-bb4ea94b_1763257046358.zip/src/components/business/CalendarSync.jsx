import React from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, CheckCircle2, Link as LinkIcon } from "lucide-react";
import { toast } from "sonner";

export default function CalendarSync({ business }) {
  const queryClient = useQueryClient();

  const connectMutation = useMutation({
    mutationFn: async () => {
      await base44.entities.Business.update(business.id, {
        google_calendar_connected: true,
        google_calendar_id: 'primary'
      });
      return true;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['business'] });
      toast.success('Calendário Google conectado com sucesso!');
    },
  });

  const disconnectMutation = useMutation({
    mutationFn: async () => {
      await base44.entities.Business.update(business.id, {
        google_calendar_connected: false,
        google_calendar_id: null
      });
      return true;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['business'] });
      toast.success('Calendário Google desconectado');
    },
  });

  return (
    <Card className="border-0 shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="w-5 h-5" />
          Sincronização de Calendário
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-white flex items-center justify-center border">
              <Calendar className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <h4 className="font-semibold text-slate-900">Google Calendar</h4>
              <p className="text-sm text-slate-600">
                {business.google_calendar_connected ? 'Conectado' : 'Não conectado'}
              </p>
            </div>
          </div>
          {business.google_calendar_connected ? (
            <Badge className="bg-green-100 text-green-700 border-green-200">
              <CheckCircle2 className="w-3 h-3 mr-1" />
              Ativo
            </Badge>
          ) : (
            <Badge variant="outline">Inativo</Badge>
          )}
        </div>

        <div className="space-y-2 text-sm text-slate-600">
          <p className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
            Sincronização automática de marcações
          </p>
          <p className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
            Evite double-booking entre plataformas
          </p>
          <p className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
            Atualizações em tempo real
          </p>
        </div>

        {business.google_calendar_connected ? (
          <Button
            onClick={() => disconnectMutation.mutate()}
            disabled={disconnectMutation.isPending}
            variant="outline"
            className="w-full"
          >
            Desconectar Google Calendar
          </Button>
        ) : (
          <Button
            onClick={() => connectMutation.mutate()}
            disabled={connectMutation.isPending}
            className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
          >
            <LinkIcon className="w-4 h-4 mr-2" />
            Conectar Google Calendar
          </Button>
        )}
      </CardContent>
    </Card>
  );
}