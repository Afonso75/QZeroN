import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MapPin, Phone, Mail, Clock, Navigation } from "lucide-react";
import { Button } from "@/components/ui/button";

const DAYS = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];

export default function BusinessInfo({ business }) {
  const openMaps = () => {
    if (business.latitude && business.longitude) {
      window.open(`https://www.google.com/maps?q=${business.latitude},${business.longitude}`, '_blank');
    } else if (business.address) {
      window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(business.address)}`, '_blank');
    }
  };

  const callPhone = () => {
    if (business.phone) {
      window.location.href = `tel:${business.phone}`;
    }
  };

  const sendEmail = () => {
    if (business.email) {
      window.location.href = `mailto:${business.email}`;
    }
  };

  const today = new Date().getDay();
  const todayHours = business.working_hours?.[today];

  return (
    <div className="space-y-2">
      <Card className="border-0 shadow-md">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-1">
            <MapPin className="w-4 h-4 text-sky-600" />
            Localização
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-xs text-slate-700 mb-2">{business.address || 'Morada não disponível'}</p>
          {business.latitude && business.longitude && (
            <div className="w-full h-32 bg-slate-100 rounded-lg overflow-hidden mb-2">
              <iframe
                width="100%"
                height="100%"
                frameBorder="0"
                style={{ border: 0 }}
                src={`https://www.google.com/maps/embed/v1/place?key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8&q=${business.latitude},${business.longitude}&zoom=15`}
                allowFullScreen
              />
            </div>
          )}
          <Button size="sm" variant="outline" className="w-full h-7 text-xs" onClick={openMaps}>
            <Navigation className="w-3 h-3 mr-1" />
            Ver no Mapa
          </Button>
        </CardContent>
      </Card>

      <Card className="border-0 shadow-md">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-1">
            <Phone className="w-4 h-4 text-sky-600" />
            Contactos
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-1.5">
          {business.phone && (
            <Button 
              size="sm" 
              variant="outline" 
              className="w-full h-7 text-xs justify-start"
              onClick={callPhone}
            >
              <Phone className="w-3 h-3 mr-1.5" />
              {business.phone}
            </Button>
          )}
          {business.email && (
            <Button 
              size="sm" 
              variant="outline" 
              className="w-full h-7 text-xs justify-start"
              onClick={sendEmail}
            >
              <Mail className="w-3 h-3 mr-1.5" />
              {business.email}
            </Button>
          )}
        </CardContent>
      </Card>

      {business.working_hours && (
        <Card className="border-0 shadow-md">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-1">
              <Clock className="w-4 h-4 text-sky-600" />
              Horário de Funcionamento
            </CardTitle>
          </CardHeader>
          <CardContent>
            {todayHours && (
              <div className="mb-2 p-2 bg-sky-50 rounded-lg">
                <p className="text-xs font-semibold text-sky-900">Hoje</p>
                <p className="text-xs text-sky-700">
                  {todayHours.closed ? 'Fechado' : `${todayHours.open} - ${todayHours.close}`}
                </p>
              </div>
            )}
            <div className="space-y-1">
              {DAYS.map((day, index) => {
                const hours = business.working_hours[index];
                if (!hours) return null;
                return (
                  <div key={index} className="flex justify-between text-xs">
                    <span className={`text-slate-700 ${index === today ? 'font-semibold' : ''}`}>
                      {day}
                    </span>
                    <span className={`text-slate-600 ${index === today ? 'font-semibold text-sky-700' : ''}`}>
                      {hours.closed ? 'Fechado' : `${hours.open} - ${hours.close}`}
                    </span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}