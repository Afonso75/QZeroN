import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { 
  PlayCircle, 
  PauseCircle, 
  StopCircle,
  PhoneCall,
  CheckCircle2,
  Users,
  Clock,
  Settings,
  TrendingUp,
  UserPlus,
  Copy,
  ExternalLink
} from "lucide-react";
import TicketPanel from "./TicketPanel";
import QueueSchedule from "./QueueSchedule";
import QueueStaffAssignment from "./QueueStaffAssignment";
import NotificationSettings from "./NotificationSettings";
import { toast } from "sonner";
import { createPageUrl } from "@/utils";

export default function QueueManager({ queue, tickets }) {
  const queryClient = useQueryClient();
  const [showSettings, setShowSettings] = useState(false);
  const [avgTime, setAvgTime] = useState(queue.average_service_time);
  const [toleranceTime, setToleranceTime] = useState(queue.tolerance_time || 15);
  const [showManualTicket, setShowManualTicket] = useState(false);
  const [manualEmail, setManualEmail] = useState("");
  const [manualName, setManualName] = useState("");
  const [manualPhone, setManualPhone] = useState("");
  const [createdTicketId, setCreatedTicketId] = useState(null);

  const activeTickets = tickets.filter(t => ['aguardando', 'chamado'].includes(t.status));
  const attendingTickets = tickets.filter(t => t.status === 'atendendo');

  const { data: business } = useQuery({
    queryKey: ['business', queue?.business_id],
    queryFn: async () => {
      const businesses = await base44.entities.Business.filter({ id: queue.business_id });
      return businesses[0];
    },
    enabled: !!queue?.business_id,
  });

  const sendSMS = async (phone, message) => {
    if (!business?.sms_gateway || business.sms_gateway === 'none' || !phone) {
      return;
    }

    try {
      await base44.functions.invoke('sendSMS', {
        phone,
        message,
        businessId: business.id
      });
    } catch (error) {
      console.error('SMS error:', error);
    }
  };

  useEffect(() => {
    if (!queue || !tickets?.length) return;

    const expireOldTickets = async () => {
      const now = new Date();
      const currentToleranceTime = queue.tolerance_time || 15;
      const expirationTimeMs = currentToleranceTime * 60 * 1000;
      
      const oldTickets = tickets.filter(t => {
        if (!t || t.status !== 'chamado' || !t.called_at) return false;
        
        const calledAt = new Date(t.called_at);
        const ageMs = now - calledAt;
        
        return ageMs > expirationTimeMs;
      });

      for (const ticket of oldTickets) {
        await base44.entities.Ticket.update(ticket.id, {
          status: 'cancelado',
          completed_at: new Date().toISOString()
        });
      }

      if (oldTickets.length > 0) {
        queryClient.invalidateQueries({ queryKey: ['business-tickets'] });
      }
    };

    expireOldTickets();
    const interval = setInterval(expireOldTickets, 2 * 60 * 1000);

    return () => clearInterval(interval);
  }, [tickets, queryClient, queue]);

  useEffect(() => {
    if (!queue?.notifications_enabled || !queue?.notification_settings || !activeTickets?.length) return;
    
    const advanceNotice = queue.notification_settings.advance_notice || 2;
    const nextNumber = queue.current_number + 1;
    
    activeTickets.forEach(async (ticket) => {
      if (!ticket || !ticket.ticket_number) return;
      
      const ticketsAhead = ticket.ticket_number - nextNumber;
      
      if (ticketsAhead === advanceNotice && ticket.status === 'aguardando') {
        const message = `Quase sua vez! Faltam ${advanceNotice} senhas. Senha #${ticket.ticket_number} - ${queue.name}`;
        
        if (queue.notification_settings.email && !ticket.is_manual && ticket.user_email) {
          try {
            await base44.integrations.Core.SendEmail({
              to: ticket.user_email,
              subject: `Quase sua vez - ${queue.name}`,
              body: message
            });
          } catch (error) {
            console.error('Email error:', error);
          }
        }
        
        if (queue.notification_settings.sms && ticket.user_phone) {
          await sendSMS(ticket.user_phone, message);
        }
        
        if (!ticket.is_manual && ticket.user_email) {
          try {
            await base44.entities.Notification.create({
              user_email: ticket.user_email,
              ticket_id: ticket.id,
              type: 'quase_sua_vez',
              message: `Faltam apenas ${advanceNotice} senhas para a sua vez!`
            });
          } catch (error) {
            console.error('Notification error:', error);
          }
        }
      }
    });
  }, [queue?.current_number, activeTickets, queue?.notifications_enabled, queue?.notification_settings, business]);

  const updateQueueMutation = useMutation({
    mutationFn: async (updates) => {
      await base44.entities.Queue.update(queue.id, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['business-queues'] });
    },
  });

  const updateTicketMutation = useMutation({
    mutationFn: async ({ ticketId, updates }) => {
      await base44.entities.Ticket.update(ticketId, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['business-tickets'] });
    },
  });

  const createManualTicketMutation = useMutation({
    mutationFn: async () => {
      const nextNumber = queue.last_issued_number + 1;
      const position = activeTickets.length + 1;
      const estimatedTime = position * queue.average_service_time;

      const ticket = await base44.entities.Ticket.create({
        queue_id: queue.id,
        business_id: queue.business_id,
        user_email: manualEmail || `presencial_${Date.now()}@temp.local`,
        user_phone: manualPhone || null,
        ticket_number: nextNumber,
        status: 'aguardando',
        estimated_time: estimatedTime,
        position: position,
        is_manual: true,
        manual_name: manualName || 'Cliente Presencial'
      });

      await base44.entities.Queue.update(queue.id, {
        last_issued_number: nextNumber
      });

      return ticket;
    },
    onSuccess: (ticket) => {
      queryClient.invalidateQueries({ queryKey: ['business-tickets'] });
      queryClient.invalidateQueries({ queryKey: ['business-queues'] });
      setManualEmail("");
      setManualName("");
      setManualPhone("");
      setCreatedTicketId(ticket.id);
      toast.success(`Senha #${ticket.ticket_number} criada`);
    },
  });

  const callNextMutation = useMutation({
    mutationFn: async () => {
      const nextNumber = queue.current_number + 1;
      
      const skippedTickets = tickets.filter(t => 
        t && t.ticket_number < nextNumber && 
        ['aguardando', 'chamado'].includes(t.status)
      );

      for (const ticket of skippedTickets) {
        await base44.entities.Ticket.update(ticket.id, {
          status: 'cancelado',
          completed_at: new Date().toISOString()
        });
      }
      
      const nextTicket = tickets.find(t => 
        t && t.ticket_number === nextNumber && 
        t.status === 'aguardando'
      );

      if (nextTicket) {
        await base44.entities.Ticket.update(nextTicket.id, {
          status: 'chamado',
          called_at: new Date().toISOString()
        });

        const message = `É sua vez! Senha #${nextNumber} chamada. Dirija-se ao ${queue.name}.`;

        if (queue.notifications_enabled && !nextTicket.is_manual) {
          if (queue.notification_settings?.email && nextTicket.user_email) {
            try {
              await base44.integrations.Core.SendEmail({
                to: nextTicket.user_email,
                subject: 'É a sua vez!',
                body: `Senha #${nextNumber} foi chamada! Dirija-se ao atendimento em ${queue.name}.`
              });
            } catch (error) {
              console.error('Email error:', error);
            }
          }
          
          if (queue.notification_settings?.sms && nextTicket.user_phone) {
            await sendSMS(nextTicket.user_phone, message);
          }
        }

        if (!nextTicket.is_manual && nextTicket.user_email) {
          try {
            await base44.entities.Notification.create({
              user_email: nextTicket.user_email,
              ticket_id: nextTicket.id,
              type: 'sua_vez',
              message: `Senha #${nextNumber} foi chamada! Dirija-se ao atendimento.`
            });
          } catch (error) {
            console.error('Notification error:', error);
          }
        }
      }

      await base44.entities.Queue.update(queue.id, {
        current_number: nextNumber
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['business-tickets'] });
      queryClient.invalidateQueries({ queryKey: ['business-queues'] });
    },
  });

  const toggleQueueStatus = () => {
    const newStatus = queue.status === "aberta" ? "pausada" : "aberta";
    updateQueueMutation.mutate({ status: newStatus });
  };

  const updateSettings = () => {
    updateQueueMutation.mutate({ 
      average_service_time: parseInt(avgTime),
      tolerance_time: parseInt(toleranceTime)
    });
    setShowSettings(false);
  };

  const copyTicketLink = (ticketId) => {
    const link = `${window.location.origin}${createPageUrl('TicketPublic')}?id=${ticketId}`;
    navigator.clipboard.writeText(link);
    toast.success('Link copiado!');
  };

  const statusConfig = {
    aberta: { 
      color: "bg-green-100 text-green-700 border-green-200", 
      icon: PlayCircle,
      label: "Aberta" 
    },
    pausada: { 
      color: "bg-amber-100 text-amber-700 border-amber-200", 
      icon: PauseCircle,
      label: "Pausada" 
    },
    fechada: { 
      color: "bg-red-100 text-red-700 border-red-200", 
      icon: StopCircle,
      label: "Fechada" 
    }
  };

  const status = statusConfig[queue.status];
  const StatusIcon = status.icon;

  return (
    <Card className="border-0 shadow-sm w-full overflow-hidden">
      <CardHeader className="pb-1 border-b p-1.5">
        <div className="flex justify-between items-start gap-1 w-full">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1 mb-0.5 flex-wrap">
              <CardTitle className="text-xs truncate">{queue.name}</CardTitle>
              <Badge className={`${status.color} text-xs h-4 px-1 py-0 flex-shrink-0`}>
                <StatusIcon className="w-2 h-2 mr-0.5" />
                {status.label}
              </Badge>
            </div>
          </div>
          
          <div className="flex gap-0.5 flex-shrink-0">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowSettings(!showSettings)}
              className="h-5 w-5 p-0"
            >
              <Settings className="w-2.5 h-2.5" />
            </Button>
            <Button
              variant={queue.status === "aberta" ? "outline" : "default"}
              size="sm"
              onClick={toggleQueueStatus}
              disabled={updateQueueMutation.isPending}
              className={`h-5 w-5 p-0 ${queue.status === "aberta" ? "border-amber-300 text-amber-700" : ""}`}
            >
              {queue.status === "aberta" ? (
                <PauseCircle className="w-2.5 h-2.5" />
              ) : (
                <PlayCircle className="w-2.5 h-2.5" />
              )}
            </Button>
          </div>
        </div>
      </CardHeader>

      {showSettings && (
        <div className="p-1.5 bg-slate-50 border-b space-y-1">
          <div>
            <Label htmlFor="avgTime" className="mb-0.5 block text-xs">Tempo Médio (min)</Label>
            <Input
              id="avgTime"
              type="number"
              min="1"
              value={avgTime}
              onChange={(e) => setAvgTime(e.target.value)}
              className="h-6 text-xs"
            />
          </div>
          <div>
            <Label htmlFor="toleranceTime" className="mb-0.5 block text-xs">Tolerância (min)</Label>
            <Input
              id="toleranceTime"
              type="number"
              min="5"
              value={toleranceTime}
              onChange={(e) => setToleranceTime(e.target.value)}
              className="h-6 text-xs"
            />
          </div>
          <Button onClick={updateSettings} size="sm" className="w-full h-6 text-xs">
            <CheckCircle2 className="w-3 h-3 mr-1" />
            Guardar
          </Button>
        </div>
      )}

      <CardContent className="p-0 w-full">
        <Tabs defaultValue="main" className="w-full">
          <TabsList className="w-full justify-start rounded-none border-b px-1 h-6 bg-transparent">
            <TabsTrigger value="main" className="text-xs px-1 h-5">Gestão</TabsTrigger>
            <TabsTrigger value="schedule" className="text-xs px-1 h-5">Horár</TabsTrigger>
            <TabsTrigger value="staff" className="text-xs px-1 h-5">Equip</TabsTrigger>
            <TabsTrigger value="notifications" className="text-xs px-1 h-5">Notif</TabsTrigger>
          </TabsList>

          <TabsContent value="main" className="p-1.5 w-full">
            <div className="grid grid-cols-2 gap-1 mb-1.5">
              <div className="p-1 bg-gradient-to-br from-blue-50 to-sky-50 rounded">
                <div className="flex items-center gap-0.5 mb-0.5">
                  <Users className="w-2 h-2 text-blue-600" />
                  <div className="text-sm font-bold text-blue-600">{activeTickets.length}</div>
                </div>
                <div className="text-xs text-slate-600 leading-none">Aguardando</div>
              </div>

              <div className="p-1 bg-gradient-to-br from-purple-50 to-pink-50 rounded">
                <div className="flex items-center gap-0.5 mb-0.5">
                  <Clock className="w-2 h-2 text-purple-600" />
                  <div className="text-sm font-bold text-purple-600">{attendingTickets.length}</div>
                </div>
                <div className="text-xs text-slate-600 leading-none">Atendendo</div>
              </div>

              <div className="p-1 bg-gradient-to-br from-green-50 to-emerald-50 rounded">
                <div className="flex items-center gap-0.5 mb-0.5">
                  <TrendingUp className="w-2 h-2 text-green-600" />
                  <div className="text-sm font-bold text-green-600">#{queue.current_number}</div>
                </div>
                <div className="text-xs text-slate-600 leading-none">Atual</div>
              </div>

              <div className="p-1 bg-gradient-to-br from-amber-50 to-orange-50 rounded">
                <div className="flex items-center gap-0.5 mb-0.5">
                  <Clock className="w-2 h-2 text-amber-600" />
                  <div className="text-sm font-bold text-amber-600">#{queue.last_issued_number}</div>
                </div>
                <div className="text-xs text-slate-600 leading-none">Última</div>
              </div>
            </div>

            <div className="space-y-1 mb-1.5">
              <Button
                className="w-full h-7 text-xs bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 px-1"
                onClick={() => callNextMutation.mutate()}
                disabled={callNextMutation.isPending || activeTickets.length === 0 || queue.status !== "aberta"}
              >
                <PhoneCall className="w-2.5 h-2.5 mr-1" />
                {callNextMutation.isPending ? 'A chamar...' : `Chamar #${queue.current_number + 1}`}
              </Button>

              <Button
                variant="outline"
                className="w-full h-7 text-xs border-blue-300 text-blue-700 hover:bg-blue-50 px-1"
                onClick={() => setShowManualTicket(!showManualTicket)}
              >
                <UserPlus className="w-2.5 h-2.5 mr-1" />
                Senha Manual
              </Button>
            </div>

            {showManualTicket && (
              <Card className="mb-1.5 border-blue-200 bg-blue-50">
                <CardContent className="p-1.5">
                  <div className="space-y-1">
                    <Input
                      value={manualName}
                      onChange={(e) => setManualName(e.target.value)}
                      placeholder="Nome"
                      className="h-6 text-xs"
                    />
                    <Input
                      value={manualPhone}
                      onChange={(e) => setManualPhone(e.target.value)}
                      placeholder="Telefone (+351...)"
                      className="h-6 text-xs"
                    />
                    <Input
                      value={manualEmail}
                      onChange={(e) => setManualEmail(e.target.value)}
                      placeholder="Email (opcional)"
                      className="h-6 text-xs"
                    />
                    <div className="flex gap-1">
                      <Button
                        onClick={() => createManualTicketMutation.mutate()}
                        disabled={createManualTicketMutation.isPending}
                        className="flex-1 h-6 text-xs px-1"
                      >
                        {createManualTicketMutation.isPending ? 'Criando...' : 'Criar'}
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => {
                          setShowManualTicket(false);
                          setCreatedTicketId(null);
                        }}
                        className="h-6 text-xs px-2"
                      >
                        X
                      </Button>
                    </div>
                    {createdTicketId && (
                      <div className="pt-1 border-t border-blue-200">
                        <p className="text-xs text-slate-700 mb-1">Link:</p>
                        <div className="flex gap-1">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => copyTicketLink(createdTicketId)}
                            className="flex-1 h-6 text-xs"
                          >
                            <Copy className="w-2.5 h-2.5 mr-1" />
                            Copiar
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => window.open(`${createPageUrl('TicketPublic')}?id=${createdTicketId}`, '_blank')}
                            className="h-6 w-6 p-0"
                          >
                            <ExternalLink className="w-2.5 h-2.5" />
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {activeTickets.length > 0 ? (
              <div>
                <h4 className="font-bold text-slate-900 mb-1 text-xs">Fila</h4>
                <div className="space-y-1 max-h-40 overflow-y-auto">
                  {activeTickets.slice(0, 5).map(ticket => (
                    <TicketPanel 
                      key={ticket.id} 
                      ticket={ticket} 
                      onUpdateTicket={updateTicketMutation.mutate}
                    />
                  ))}
                </div>
                {activeTickets.length > 5 && (
                  <p className="text-xs text-slate-500 mt-1 text-center">
                    +{activeTickets.length - 5}
                  </p>
                )}
              </div>
            ) : (
              <div className="text-center py-3 text-slate-500">
                <Users className="w-6 h-6 mx-auto mb-1 opacity-50" />
                <p className="text-xs">Sem senhas</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="schedule" className="p-1.5">
            <QueueSchedule queue={queue} />
          </TabsContent>

          <TabsContent value="staff" className="p-1.5">
            <QueueStaffAssignment queue={queue} businessId={queue.business_id} />
          </TabsContent>

          <TabsContent value="notifications" className="p-1.5">
            <NotificationSettings queue={queue} />
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}