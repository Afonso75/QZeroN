import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { X, Save } from "lucide-react";

export default function QueueForm({ queue, businessId, onClose }) {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState(queue || {
    name: '',
    description: '',
    average_service_time: 10,
    max_capacity: 100,
    current_number: 0,
    last_issued_number: 0,
    status: 'aberta',
    is_active: true
  });

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      if (queue) {
        await base44.entities.Queue.update(queue.id, data);
      } else {
        await base44.entities.Queue.create({
          ...data,
          business_id: businessId
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['business-queues'] });
      onClose();
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    saveMutation.mutate(formData);
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 bg-white p-6 rounded-xl border border-slate-200">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-bold text-slate-900">
          {queue ? 'Editar Fila' : 'Nova Fila'}
        </h3>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={onClose}
        >
          <X className="w-4 h-4" />
        </Button>
      </div>

      <div>
        <Label htmlFor="queue-name">Nome da Fila *</Label>
        <Input
          id="queue-name"
          value={formData.name}
          onChange={(e) => handleChange('name', e.target.value)}
          placeholder="Ex: Atendimento Geral"
          required
        />
      </div>

      <div>
        <Label htmlFor="queue-description">Descrição</Label>
        <Textarea
          id="queue-description"
          value={formData.description}
          onChange={(e) => handleChange('description', e.target.value)}
          placeholder="Descreva o tipo de atendimento..."
          rows={2}
        />
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <Label htmlFor="avg-time">Tempo Médio de Atendimento (min) *</Label>
          <Input
            id="avg-time"
            type="number"
            min="1"
            value={formData.average_service_time}
            onChange={(e) => handleChange('average_service_time', parseInt(e.target.value))}
            required
          />
        </div>

        <div>
          <Label htmlFor="max-capacity">Capacidade Máxima *</Label>
          <Input
            id="max-capacity"
            type="number"
            min="1"
            value={formData.max_capacity}
            onChange={(e) => handleChange('max_capacity', parseInt(e.target.value))}
            required
          />
        </div>
      </div>

      <div className="flex gap-3">
        <Button
          type="button"
          variant="outline"
          onClick={onClose}
          className="flex-1"
        >
          Cancelar
        </Button>
        <Button
          type="submit"
          disabled={saveMutation.isPending}
          className="flex-1 gap-2 bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700"
        >
          <Save className="w-4 h-4" />
          {saveMutation.isPending ? 'Salvando...' : 'Salvar'}
        </Button>
      </div>
    </form>
  );
}