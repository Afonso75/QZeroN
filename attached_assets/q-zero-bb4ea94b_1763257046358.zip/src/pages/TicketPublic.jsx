import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, Users, AlertCircle, CheckCircle2, Phone } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function TicketPublicPage() {
  const urlParams = new URLSearchParams(window.location.search);
  const ticketId = urlParams.get('id');

  const { data: ticket, isLoading: loadingTicket } = useQuery({
    queryKey: ['public-ticket', ticketId],
    queryFn: async () => {
      const tickets = await base44.entities.Ticket.filter({ id: ticketId });
      return tickets[0];
    },
    enabled: !!ticketId,
    refetchInterval: 3000,
  });

  const { data: queue } = useQuery({
    queryKey: ['queue', ticket?.queue_id],
    queryFn: async () => {
      const queues = await base44.entities.Queue.filter({ id: ticket.queue_id });
      return queues[0];
    },
    enabled: !!ticket?.queue_id,
    refetchInterval: 3000,
  });

  const { data: business } = useQuery({
    queryKey: ['business', ticket?.business_id],
    queryFn: async () => {
      const businesses = await base44.entities.Business.filter({ id: ticket.business_id });
      return businesses[0];
    },
    enabled: !!ticket?.business_id,
  });

  if (loadingTicket) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 p-3">
        <div className="max-w-md mx-auto">
          <Skeleton className="h-40 w-full mb-3 rounded-xl" />
          <Skeleton className="h-32 w-full rounded-xl" />
        </div>
      </div>
    );
  }

  if (!ticket) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 flex items-center justify-center p-3">
        <Card className="border-0 shadow-lg max-w-md w-full">
          <CardContent className="py-12 text-center">
            <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-slate-900 mb-2">Senha não encontrada</h2>
            <p className="text-slate-600">Verifique o link ou contacte o estabelecimento</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const statusConfig = {
    aguardando: { 
      icon: Clock, 
      color: 'from-amber-500 to-orange-500',
      bg: 'bg-amber-100',
      text: 'text-amber-700',
      label: 'Aguardando' 
    },
    chamado: { 
      icon: Phone, 
      color: 'from-green-500 to-emerald-500',
      bg: 'bg-green-100',
      text: 'text-green-700',
      label: 'É a sua vez!' 
    },
    atendendo: { 
      icon: Users, 
      color: 'from-blue-500 to-cyan-500',
      bg: 'bg-blue-100',
      text: 'text-blue-700',
      label: 'Em atendimento' 
    },
    concluido: { 
      icon: CheckCircle2, 
      color: 'from-green-500 to-emerald-500',
      bg: 'bg-green-100',
      text: 'text-green-700',
      label: 'Concluído' 
    },
    cancelado: { 
      icon: AlertCircle, 
      color: 'from-red-500 to-pink-500',
      bg: 'bg-red-100',
      text: 'text-red-700',
      label: 'Cancelado' 
    }
  };

  const status = statusConfig[ticket.status] || statusConfig.aguardando;
  const StatusIcon = status.icon;
  const position = queue ? (ticket.ticket_number - queue.current_number) : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 w-full overflow-x-hidden">
      <div className="w-full max-w-md mx-auto px-3 py-6">
        {business && (
          <div className="text-center mb-4">
            {business.logo_url && (
              <img 
                src={business.logo_url} 
                alt={business.name}
                className="w-16 h-16 mx-auto mb-2 rounded-xl object-contain"
              />
            )}
            <h1 className="text-xl font-bold text-slate-900">{business.name}</h1>
            {queue && (
              <p className="text-sm text-slate-600">{queue.name}</p>
            )}
          </div>
        )}

        <Card className="border-0 shadow-2xl mb-4 overflow-hidden">
          <div className={`h-2 bg-gradient-to-r ${status.color}`} />
          <CardContent className="py-8 text-center">
            <div className={`w-20 h-20 rounded-full bg-gradient-to-br ${status.color} flex items-center justify-center mx-auto mb-4 shadow-xl`}>
              <StatusIcon className="w-10 h-10 text-white" />
            </div>
            
            <div className="mb-4">
              <div className="text-6xl font-bold text-slate-900 mb-2">
                #{ticket.ticket_number}
              </div>
              <Badge className={`${status.bg} ${status.text} border-0 text-base px-4 py-1`}>
                {status.label}
              </Badge>
            </div>

            {ticket.manual_name && (
              <p className="text-slate-700 mb-2">{ticket.manual_name}</p>
            )}
          </CardContent>
        </Card>

        {ticket.status === 'aguardando' && queue && (
          <div className="space-y-3">
            <Card className="border-0 shadow-lg">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-slate-600">Posição na fila</span>
                  <span className="text-2xl font-bold text-blue-600">{position}</span>
                </div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-slate-600">Senha atual</span>
                  <span className="text-xl font-bold text-slate-900">#{queue.current_number}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-600">Tempo estimado</span>
                  <span className="text-lg font-semibold text-purple-600">~{ticket.estimated_time} min</span>
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-50 to-sky-50">
              <CardContent className="p-4 text-center">
                <Clock className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                <p className="text-sm text-slate-700 font-medium">
                  Aguarde ser chamado
                </p>
                <p className="text-xs text-slate-600 mt-1">
                  Mantenha esta página aberta
                </p>
              </CardContent>
            </Card>
          </div>
        )}

        {ticket.status === 'chamado' && (
          <Card className="border-0 shadow-lg bg-gradient-to-br from-green-50 to-emerald-50 animate-pulse">
            <CardContent className="p-6 text-center">
              <Phone className="w-12 h-12 text-green-600 mx-auto mb-3" />
              <h3 className="text-xl font-bold text-green-700 mb-2">
                É a sua vez!
              </h3>
              <p className="text-slate-700">
                Dirija-se ao atendimento agora
              </p>
            </CardContent>
          </Card>
        )}

        {ticket.status === 'concluido' && (
          <Card className="border-0 shadow-lg bg-gradient-to-br from-green-50 to-emerald-50">
            <CardContent className="p-6 text-center">
              <CheckCircle2 className="w-12 h-12 text-green-600 mx-auto mb-3" />
              <h3 className="text-xl font-bold text-green-700 mb-2">
                Atendimento Concluído
              </h3>
              <p className="text-slate-700">
                Obrigado pela visita!
              </p>
            </CardContent>
          </Card>
        )}

        {ticket.status === 'cancelado' && (
          <Card className="border-0 shadow-lg bg-gradient-to-br from-red-50 to-pink-50">
            <CardContent className="p-6 text-center">
              <AlertCircle className="w-12 h-12 text-red-600 mx-auto mb-3" />
              <h3 className="text-xl font-bold text-red-700 mb-2">
                Senha Cancelada
              </h3>
              <p className="text-slate-700">
                Contacte o estabelecimento
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}