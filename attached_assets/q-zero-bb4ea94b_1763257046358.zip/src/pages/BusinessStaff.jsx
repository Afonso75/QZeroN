import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Users, Mail, Trash2, CheckCircle2, Clock, X } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import PageHeader from "../components/shared/PageHeader";

export default function BusinessStaffPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [showInviteForm, setShowInviteForm] = useState(false);
  const [inviteEmail, setInviteEmail] = useState("");
  const [permissions, setPermissions] = useState({
    manage_queues: false,
    manage_appointments: false,
    manage_services: false
  });

  useEffect(() => {
    base44.auth.me().then(userData => {
      setUser(userData);
      if (!userData.is_business_user || !userData.business_id) {
        navigate(createPageUrl("Home"));
      }
    }).catch(() => base44.auth.redirectToLogin());
  }, [navigate]);

  const { data: business } = useQuery({
    queryKey: ['business', user?.business_id],
    queryFn: async () => {
      const businesses = await base44.entities.Business.filter({ id: user.business_id });
      return businesses[0];
    },
    enabled: !!user?.business_id,
  });

  const { data: staffMembers, isLoading } = useQuery({
    queryKey: ['staff-members', user?.business_id],
    queryFn: async () => {
      const users = await base44.entities.User.filter({
        business_id: user.business_id,
        is_staff_member: true
      });
      return users;
    },
    initialData: [],
    enabled: !!user?.business_id,
  });

  const { data: invites } = useQuery({
    queryKey: ['staff-invites', user?.business_id],
    queryFn: () => base44.entities.StaffInvite.filter({
      business_id: user.business_id,
      status: "pendente"
    }),
    initialData: [],
    enabled: !!user?.business_id,
  });

  const inviteStaffMutation = useMutation({
    mutationFn: async () => {
      const token = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 7);

      const invite = await base44.entities.StaffInvite.create({
        business_id: user.business_id,
        email: inviteEmail,
        permissions: permissions,
        token: token,
        status: "pendente",
        expires_at: expiresAt.toISOString(),
        invited_by: user.email
      });

      const inviteUrl = `${window.location.origin}${createPageUrl(`StaffInviteAccept?token=${token}`)}`;

      await base44.integrations.Core.SendEmail({
        to: inviteEmail,
        subject: `Convite para Equipa - ${business.name}`,
        body: `Olá!\n\nFoi convidado para fazer parte da equipa de ${business.name}.\n\nPermissões atribuídas:\n${
          permissions.manage_queues ? '✓ Gerir Senhas\n' : ''
        }${
          permissions.manage_appointments ? '✓ Gerir Marcações\n' : ''
        }${
          permissions.manage_services ? '✓ Gerir Serviços\n' : ''
        }\nClique para aceitar: ${inviteUrl}\n\nO convite expira em 7 dias.`
      });

      return invite;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['staff-invites'] });
      setShowInviteForm(false);
      setInviteEmail("");
      setPermissions({
        manage_queues: false,
        manage_appointments: false,
        manage_services: false
      });
      toast.success('Convite enviado com sucesso!');
    },
  });

  const deleteInviteMutation = useMutation({
    mutationFn: (inviteId) => base44.entities.StaffInvite.delete(inviteId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['staff-invites'] });
      toast.success('Convite cancelado');
    },
  });

  const removeStaffMutation = useMutation({
    mutationFn: async (staffId) => {
      await base44.entities.User.update(staffId, {
        is_staff_member: false,
        business_id: null,
        staff_permissions: null
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['staff-members'] });
      toast.success('Funcionário removido');
    },
  });

  const handleInvite = () => {
    if (!inviteEmail || !inviteEmail.includes('@')) {
      toast.error('Email inválido');
      return;
    }

    const hasPermission = Object.values(permissions).some(p => p);
    if (!hasPermission) {
      toast.error('Selecione pelo menos uma permissão');
      return;
    }

    inviteStaffMutation.mutate();
  };

  const permissionLabels = {
    manage_queues: "Gerir Senhas",
    manage_appointments: "Gerir Marcações",
    manage_services: "Gerir Serviços"
  };

  if (!user || isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 p-6">
        <div className="max-w-6xl mx-auto">
          <Skeleton className="h-16 w-64 mb-8" />
          <Skeleton className="h-96 w-full" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50">
      <div className="max-w-6xl mx-auto px-6 py-8">
        <PageHeader
          title="Gestão de Equipa"
          subtitle="Convide funcionários e atribua permissões"
          backTo="BusinessSettings"
          actions={
            <Button onClick={() => setShowInviteForm(!showInviteForm)} className="gap-2">
              <Mail className="w-4 h-4" />
              Convidar Funcionário
            </Button>
          }
        />

        {showInviteForm && (
          <Card className="border-0 shadow-xl mb-8">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Novo Convite</CardTitle>
                <Button variant="ghost" size="icon" onClick={() => setShowInviteForm(false)}>
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label htmlFor="email">Email do Funcionário</Label>
                <Input
                  id="email"
                  type="email"
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e.target.value)}
                  placeholder="funcionario@exemplo.com"
                />
              </div>

              <div>
                <Label className="text-base font-semibold mb-4 block">Permissões</Label>
                <div className="space-y-3">
                  {Object.entries(permissionLabels).map(([key, label]) => (
                    <div key={key} className="flex items-center space-x-2">
                      <Checkbox
                        id={key}
                        checked={permissions[key]}
                        onCheckedChange={(checked) => 
                          setPermissions({ ...permissions, [key]: checked })
                        }
                      />
                      <label htmlFor={key} className="text-sm font-medium cursor-pointer">
                        {label}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex gap-3 justify-end pt-4">
                <Button variant="outline" onClick={() => setShowInviteForm(false)}>
                  Cancelar
                </Button>
                <Button 
                  onClick={handleInvite}
                  disabled={inviteStaffMutation.isPending}
                >
                  {inviteStaffMutation.isPending ? 'A enviar...' : 'Enviar Convite'}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {invites.length > 0 && (
          <Card className="border-0 shadow-lg mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                Convites Pendentes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {invites.map(invite => (
                  <div key={invite.id} className="flex items-center justify-between p-4 bg-amber-50 rounded-lg border border-amber-200">
                    <div className="flex-1">
                      <p className="font-semibold text-slate-900">{invite.email}</p>
                      <div className="flex flex-wrap gap-2 mt-2">
                        {Object.entries(invite.permissions || {}).map(([key, value]) => 
                          value && (
                            <Badge key={key} variant="secondary" className="text-xs">
                              {permissionLabels[key]}
                            </Badge>
                          )
                        )}
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      onClick={() => deleteInviteMutation.mutate(invite.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              Funcionários Ativos ({staffMembers.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {staffMembers.length === 0 ? (
              <div className="text-center py-12">
                <Users className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-slate-900 mb-2">
                  Nenhum funcionário
                </h3>
                <p className="text-slate-600 mb-6">
                  Convide funcionários para ajudar na gestão
                </p>
                <Button onClick={() => setShowInviteForm(true)}>
                  <Mail className="w-4 h-4 mr-2" />
                  Convidar Primeiro Funcionário
                </Button>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 gap-6">
                {staffMembers.map(member => (
                  <Card key={member.id} className="border shadow-sm">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h4 className="font-bold text-slate-900 mb-1">
                            {member.full_name || 'Sem nome'}
                          </h4>
                          <p className="text-sm text-slate-600">{member.email}</p>
                        </div>
                        <Badge className="bg-green-100 text-green-700 border-green-200">
                          <CheckCircle2 className="w-3 h-3 mr-1" />
                          Ativo
                        </Badge>
                      </div>

                      <div className="mb-4">
                        <p className="text-xs text-slate-500 mb-2">Permissões:</p>
                        <div className="flex flex-wrap gap-2">
                          {Object.entries(member.staff_permissions || {}).map(([key, value]) => 
                            value && (
                              <Badge key={key} variant="outline" className="text-xs">
                                {permissionLabels[key]}
                              </Badge>
                            )
                          )}
                        </div>
                      </div>

                      <Button
                        variant="outline"
                        size="sm"
                        className="w-full border-red-200 text-red-600 hover:bg-red-50"
                        onClick={() => {
                          if (confirm(`Remover ${member.full_name || member.email} da equipa?`)) {
                            removeStaffMutation.mutate(member.id);
                          }
                        }}
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Remover da Equipa
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}