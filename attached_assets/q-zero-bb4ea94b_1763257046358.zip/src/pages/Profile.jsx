import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import ProfileManager from "../components/portal/ProfileManager";

export default function ProfilePage() {
  const queryClient = useQueryClient();
  
  const { data: user, isLoading } = useQuery({
    queryKey: ['current-user'],
    queryFn: () => base44.auth.me(),
    staleTime: 0,
    refetchOnMount: 'always',
    refetchOnWindowFocus: true
  });

  const handleUpdate = async () => {
    await queryClient.invalidateQueries({ queryKey: ['current-user'] });
    await queryClient.refetchQueries({ queryKey: ['current-user'] });
  };

  if (isLoading || !user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 p-3 md:p-6">
        <div className="max-w-4xl mx-auto">
          <Skeleton className="h-12 md:h-16 w-48 md:w-64 mb-4 md:mb-8" />
          <Skeleton className="h-96 w-full" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50">
      <div className="max-w-4xl mx-auto px-3 md:px-6 py-4 md:py-8">
        <div className="mb-4 md:mb-8">
          <h1 className="text-2xl md:text-4xl font-bold text-slate-900 mb-1 md:mb-2">
            Meu Perfil
          </h1>
          <p className="text-sm md:text-xl text-slate-600">
            Gerir as suas informações pessoais
          </p>
        </div>

        <ProfileManager user={user} onUpdate={handleUpdate} />
      </div>
    </div>
  );
}