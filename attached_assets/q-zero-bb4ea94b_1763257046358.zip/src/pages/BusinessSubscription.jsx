import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  CheckCircle2,
  Building2,
  Users,
  BarChart3,
  Calendar,
  Clock,
  Shield,
  Zap,
  ArrowRight,
  Loader2,
  ArrowLeft,
  CreditCard,
  TestTube
} from "lucide-react";
import { toast } from "sonner";

export default function BusinessSubscriptionPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {
      base44.auth.redirectToLogin();
    });
  }, []);

  const { data: subscription, isLoading } = useQuery({
    queryKey: ['business-subscription', user?.email],
    queryFn: async () => {
      if (!user) return null;
      const subs = await base44.entities.Subscription.filter({
        user_email: user.email,
        plan: "business"
      });
      const activeSub = subs.find(s => s.status === 'active' || s.status === 'trialing');
      return activeSub || null;
    },
    enabled: !!user,
    staleTime: 0,
    retry: 1
  });

  const startTestMutation = useMutation({
    mutationFn: async () => {
      const trialEndDate = new Date();
      trialEndDate.setDate(trialEndDate.getDate() + 7); // 7 dias de teste

      const subscription = await base44.entities.Subscription.create({
        user_email: user.email,
        plan: "business",
        status: "trialing",
        start_date: new Date().toISOString(),
        trial_end_date: trialEndDate.toISOString(),
        price: 49.99,
        auto_renew: false
      });

      await base44.auth.updateMe({
        has_business_subscription: true
      });

      return subscription;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['business-subscription'] });
      toast.success('Teste de 7 dias ativado!');
      navigate(createPageUrl('BusinessProfileSetup'));
    },
    onError: (error) => {
      console.error('Test activation error:', error);
      toast.error('Erro ao ativar teste');
    }
  });

  const handlePayNow = async () => {
    setIsProcessingPayment(true);
    try {
      const response = await base44.functions.invoke('createCheckoutSession', {
        priceId: 'price_1STcHKQdkGMpuEbeKwsRYM1B',
        mode: 'subscription',
        successUrl: window.location.origin + createPageUrl('PaymentSuccess'),
        cancelUrl: window.location.origin + createPageUrl('BusinessSubscription')
      });
      
      if (response.data.url) {
        window.location.href = response.data.url;
      } else {
        toast.error('Erro ao criar sessão de pagamento');
      }
    } catch (error) {
      console.error('Payment error:', error);
      toast.error('Erro ao processar pagamento');
    } finally {
      setIsProcessingPayment(false);
    }
  };

  const features = [
    {
      icon: Users,
      title: "Gestão de Filas",
      description: "Crie e gira múltiplas filas de atendimento simultaneamente"
    },
    {
      icon: Calendar,
      title: "Sistema de Marcações",
      description: "Permita aos clientes agendar serviços com horários personalizados"
    },
    {
      icon: BarChart3,
      title: "Análise Avançada",
      description: "Estatísticas detalhadas e previsões com IA para otimizar o atendimento"
    },
    {
      icon: Clock,
      title: "Tempo Real",
      description: "Atualizações instantâneas e notificações automáticas para clientes"
    },
    {
      icon: Shield,
      title: "Suporte Prioritário",
      description: "Atendimento dedicado para resolver qualquer questão rapidamente"
    },
    {
      icon: Zap,
      title: "Sem Limites",
      description: "Atendimentos, filas e marcações ilimitadas"
    }
  ];

  if (!user || isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 flex items-center justify-center p-6">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-indigo-600 mx-auto mb-4" />
          <p className="text-slate-600">A carregar...</p>
        </div>
      </div>
    );
  }

  if (subscription && user.business_profile_completed) {
    window.location.href = createPageUrl("BusinessDashboard");
    return null;
  }

  if (subscription && !user.business_profile_completed) {
    window.location.href = createPageUrl("BusinessProfileSetup");
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50">
      <div className="max-w-6xl mx-auto px-6 py-12">
        <div className="mb-6">
          <Button
            variant="ghost"
            onClick={() => navigate(createPageUrl("Home"))}
            className="gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Voltar ao Início
          </Button>
        </div>

        <div className="text-center mb-12">
          <Badge className="bg-indigo-100 text-indigo-700 border-indigo-200 mb-4">
            <Building2 className="w-3 h-3 mr-1" />
            Plano Empresarial
          </Badge>
          <h1 className="text-5xl font-bold text-slate-900 mb-4">
            Transforme o Atendimento
            <br />
            da Sua Empresa
          </h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            Elimine filas, otimize agendamentos e melhore a experiência dos seus clientes
          </p>
        </div>

        <Card className="border-0 shadow-2xl mb-12 overflow-hidden max-w-2xl mx-auto">
          <div className="h-2 bg-gradient-to-r from-indigo-600 to-purple-600" />
          <CardContent className="p-8">
            <div className="text-center mb-8">
              <div className="text-6xl font-bold text-slate-900 mb-2">
                €49,99
                <span className="text-2xl text-slate-600 font-normal">/mês</span>
              </div>
              <p className="text-slate-600">Faturação mensal • Cancele quando quiser</p>
              <Badge className="bg-green-100 text-green-700 border-green-200 mt-3">
                <Zap className="w-3 h-3 mr-1" />
                2 dias grátis ao subscrever
              </Badge>
            </div>

            <div className="space-y-4 mb-8">
              {[
                "Gestão de filas ilimitadas",
                "Sistema completo de marcações",
                "Horários personalizados e pausas",
                "Bloqueio de datas (férias/feriados)",
                "Análise e estatísticas avançadas",
                "Previsões com IA",
                "Notificações automáticas",
                "Painel de controlo completo",
                "Suporte prioritário",
                "Sem limite de atendimentos"
              ].map((feature, idx) => (
                <div key={idx} className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <span className="text-slate-700">{feature}</span>
                </div>
              ))}
            </div>

            <div className="space-y-3">
              <Button
                onClick={handlePayNow}
                disabled={isProcessingPayment}
                className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 py-6 text-lg"
              >
                {isProcessingPayment ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    A processar...
                  </>
                ) : (
                  <>
                    <CreditCard className="w-5 h-5 mr-2" />
                    Subscrever Agora
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </>
                )}
              </Button>

              <Button
                onClick={() => startTestMutation.mutate()}
                disabled={startTestMutation.isPending}
                variant="outline"
                className="w-full py-6 text-lg border-2 border-amber-300 bg-amber-50 hover:bg-amber-100 text-amber-900"
              >
                {startTestMutation.isPending ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    A ativar...
                  </>
                ) : (
                  <>
                    <TestTube className="w-5 h-5 mr-2" />
                    Modo Teste (7 dias grátis - sem cartão)
                  </>
                )}
              </Button>
            </div>

            <p className="text-center text-sm text-slate-500 mt-4">
              Pagamento seguro via Stripe • 2 dias grátis • Sem compromissos
            </p>
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {features.map((feature, idx) => (
            <Card key={idx} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center mb-4">
                  <feature.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-bold text-lg text-slate-900 mb-2">{feature.title}</h3>
                <p className="text-slate-600 text-sm">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="border-0 shadow-xl">
          <CardHeader>
            <CardTitle>Perguntas Frequentes</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h4 className="font-semibold text-slate-900 mb-2">Como funciona o Modo Teste?</h4>
              <p className="text-slate-600">
                O modo teste dá-lhe 7 dias de acesso completo sem necessidade de cartão de crédito. 
                Perfeito para explorar todas as funcionalidades sem compromisso.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-slate-900 mb-2">Como funcionam os 2 dias grátis?</h4>
              <p className="text-slate-600">
                Ao subscrever, terá acesso completo durante 2 dias sem qualquer custo. 
                Após esse período, será cobrado o valor mensal de €49,99.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-slate-900 mb-2">Preciso de cartão de crédito?</h4>
              <p className="text-slate-600">
                Para subscrição paga sim, mas pode usar o Modo Teste sem cartão. 
                Na subscrição paga só será cobrado após os 2 dias grátis.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-slate-900 mb-2">Posso cancelar a qualquer momento?</h4>
              <p className="text-slate-600">
                Sim, pode cancelar a subscrição a qualquer momento sem penalizações.
                O acesso permanece ativo até ao final do período pago.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-slate-900 mb-2">Há limite de atendimentos?</h4>
              <p className="text-slate-600">
                Não, não há qualquer limite. Pode ter quantas filas, marcações e atendimentos precisar.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}