import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Edit, Trash2, Users, Crown } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import PageHeader from "../components/shared/PageHeader";
import EmptyState from "../components/shared/EmptyState";
import QueueForm from "../components/business/QueueForm";

export default function BusinessQueuesPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [editingQueue, setEditingQueue] = useState(null);

  useEffect(() => {
    base44.auth.me().then(userData => {
      setUser(userData);
      if (!userData.is_business_user || !userData.business_id) {
        navigate(createPageUrl("Home"));
      }
    }).catch(() => base44.auth.redirectToLogin());
  }, [navigate]);

  const { data: subscription } = useQuery({
    queryKey: ['business-subscription', user?.email],
    queryFn: async () => {
      if (!user) return null;
      const subs = await base44.entities.Subscription.filter({
        user_email: user.email,
        plan: "business",
        status: "active"
      });
      return subs[0] || null;
    },
    enabled: !!user,
  });

  const { data: queues, isLoading } = useQuery({
    queryKey: ['business-queues', user?.business_id],
    queryFn: () => base44.entities.Queue.filter({ business_id: user.business_id }),
    initialData: [],
    enabled: !!user?.business_id,
  });

  const deleteQueueMutation = useMutation({
    mutationFn: (queueId) => base44.entities.Queue.delete(queueId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['business-queues'] });
    },
  });

  const handleEdit = (queue) => {
    if (!subscription) return;
    setEditingQueue(queue);
    setShowForm(true);
  };

  const handleDelete = (queueId) => {
    if (!subscription) return;
    if (confirm('Tem certeza que deseja eliminar esta senha?')) {
      deleteQueueMutation.mutate(queueId);
    }
  };

  if (!user || isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 p-6">
        <div className="max-w-6xl mx-auto">
          <Skeleton className="h-16 w-64 mb-8" />
          <Skeleton className="h-96 w-full" />
        </div>
      </div>
    );
  }

  if (!subscription) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50">
        <div className="max-w-4xl mx-auto px-6 py-12">
          <Card className="border-0 shadow-2xl">
            <CardContent className="p-12 text-center">
              <Crown className="w-16 h-16 text-amber-600 mx-auto mb-6" />
              <h2 className="text-3xl font-bold text-slate-900 mb-4">
                Subscrição Necessária
              </h2>
              <p className="text-lg text-slate-600 mb-8">
                Para criar e gerir filas de atendimento, precisa de ativar o plano empresarial.
              </p>
              <Link to={createPageUrl("BusinessSubscription")}>
                <Button size="lg" className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700">
                  <Crown className="w-5 h-5 mr-2" />
                  Ativar Plano Empresarial - €49,99/mês
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50">
      <div className="max-w-6xl mx-auto px-6 py-8">
        <PageHeader
          title="Gestão de Senhas"
          subtitle="Crie e gerir as suas senhas de atendimento"
          backTo="BusinessDashboard"
          actions={
            <Button onClick={() => { setEditingQueue(null); setShowForm(true); }} className="gap-2">
              <Plus className="w-4 h-4" />
              Nova Senha
            </Button>
          }
        />

        {showForm ? (
          <Card className="border-0 shadow-xl mb-8">
            <CardHeader>
              <CardTitle>{editingQueue ? 'Editar Senha' : 'Nova Senha'}</CardTitle>
            </CardHeader>
            <CardContent>
              <QueueForm
                queue={editingQueue}
                businessId={user.business_id}
                onClose={() => {
                  setShowForm(false);
                  setEditingQueue(null);
                }}
              />
            </CardContent>
          </Card>
        ) : queues.length === 0 ? (
          <EmptyState
            icon={Users}
            title="Nenhuma senha criada"
            description="Crie sua primeira senha para começar a gerir atendimentos"
            action={{
              label: "Criar Primeira Senha",
              onClick: () => setShowForm(true)
            }}
          />
        ) : (
          <div className="grid md:grid-cols-2 gap-6">
            {queues.map(queue => (
              <Card key={queue.id} className="border-0 shadow-lg hover:shadow-xl transition-all">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="font-bold text-xl text-slate-900 mb-1">{queue.name}</h3>
                      <p className="text-sm text-slate-600">{queue.description}</p>
                    </div>
                    <div className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      queue.status === 'aberta' ? 'bg-green-100 text-green-700' :
                      queue.status === 'pausada' ? 'bg-amber-100 text-amber-700' :
                      'bg-red-100 text-red-700'
                    }`}>
                      {queue.status}
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3 mb-4">
                    <div className="p-3 bg-blue-50 rounded-lg text-center">
                      <div className="text-2xl font-bold text-blue-600">#{queue.current_number}</div>
                      <div className="text-xs text-blue-600">Atual</div>
                    </div>
                    <div className="p-3 bg-purple-50 rounded-lg text-center">
                      <div className="text-2xl font-bold text-purple-600">#{queue.last_issued_number}</div>
                      <div className="text-xs text-purple-600">Última</div>
                    </div>
                    <div className="p-3 bg-green-50 rounded-lg text-center">
                      <div className="text-2xl font-bold text-green-600">{queue.average_service_time}</div>
                      <div className="text-xs text-green-600">Min</div>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => handleEdit(queue)}
                    >
                      <Edit className="w-4 h-4 mr-2" />
                      Editar
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-red-200 text-red-600 hover:bg-red-50"
                      onClick={() => handleDelete(queue.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}