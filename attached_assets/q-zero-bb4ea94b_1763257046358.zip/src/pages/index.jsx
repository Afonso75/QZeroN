import Layout from "./Layout.jsx";

import Home from "./Home";

import Businesses from "./Businesses";

import BusinessDetail from "./BusinessDetail";

import MyTickets from "./MyTickets";

import TicketView from "./TicketView";

import ManageSubscription from "./ManageSubscription";

import BusinessDashboard from "./BusinessDashboard";

import BusinessSettings from "./BusinessSettings";

import BusinessAccess from "./BusinessAccess";

import Settings from "./Settings";

import Dashboard from "./Dashboard";

import Onboarding from "./Onboarding";

import MyAppointments from "./MyAppointments";

import BusinessSubscription from "./BusinessSubscription";

import AppointmentManage from "./AppointmentManage";

import StripeCheckout from "./StripeCheckout";

import BusinessManageSubscription from "./BusinessManageSubscription";

import CustomerPortal from "./CustomerPortal";

import BusinessQueues from "./BusinessQueues";

import BusinessServices from "./BusinessServices";

import PaymentSuccess from "./PaymentSuccess";

import Profile from "./Profile";

import TicketPublic from "./TicketPublic";

import BusinessSupport from "./BusinessSupport";

import AdminSupport from "./AdminSupport";

import BusinessStaff from "./BusinessStaff";

import StaffInviteAccept from "./StaffInviteAccept";

import BusinessProfileSetup from "./BusinessProfileSetup";

import AdminActivate from "./AdminActivate";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Home: Home,
    
    Businesses: Businesses,
    
    BusinessDetail: BusinessDetail,
    
    MyTickets: MyTickets,
    
    TicketView: TicketView,
    
    ManageSubscription: ManageSubscription,
    
    BusinessDashboard: BusinessDashboard,
    
    BusinessSettings: BusinessSettings,
    
    BusinessAccess: BusinessAccess,
    
    Settings: Settings,
    
    Dashboard: Dashboard,
    
    Onboarding: Onboarding,
    
    MyAppointments: MyAppointments,
    
    BusinessSubscription: BusinessSubscription,
    
    AppointmentManage: AppointmentManage,
    
    StripeCheckout: StripeCheckout,
    
    BusinessManageSubscription: BusinessManageSubscription,
    
    CustomerPortal: CustomerPortal,
    
    BusinessQueues: BusinessQueues,
    
    BusinessServices: BusinessServices,
    
    PaymentSuccess: PaymentSuccess,
    
    Profile: Profile,
    
    TicketPublic: TicketPublic,
    
    BusinessSupport: BusinessSupport,
    
    AdminSupport: AdminSupport,
    
    BusinessStaff: BusinessStaff,
    
    StaffInviteAccept: StaffInviteAccept,
    
    BusinessProfileSetup: BusinessProfileSetup,
    
    AdminActivate: AdminActivate,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Home />} />
                
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/Businesses" element={<Businesses />} />
                
                <Route path="/BusinessDetail" element={<BusinessDetail />} />
                
                <Route path="/MyTickets" element={<MyTickets />} />
                
                <Route path="/TicketView" element={<TicketView />} />
                
                <Route path="/ManageSubscription" element={<ManageSubscription />} />
                
                <Route path="/BusinessDashboard" element={<BusinessDashboard />} />
                
                <Route path="/BusinessSettings" element={<BusinessSettings />} />
                
                <Route path="/BusinessAccess" element={<BusinessAccess />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Onboarding" element={<Onboarding />} />
                
                <Route path="/MyAppointments" element={<MyAppointments />} />
                
                <Route path="/BusinessSubscription" element={<BusinessSubscription />} />
                
                <Route path="/AppointmentManage" element={<AppointmentManage />} />
                
                <Route path="/StripeCheckout" element={<StripeCheckout />} />
                
                <Route path="/BusinessManageSubscription" element={<BusinessManageSubscription />} />
                
                <Route path="/CustomerPortal" element={<CustomerPortal />} />
                
                <Route path="/BusinessQueues" element={<BusinessQueues />} />
                
                <Route path="/BusinessServices" element={<BusinessServices />} />
                
                <Route path="/PaymentSuccess" element={<PaymentSuccess />} />
                
                <Route path="/Profile" element={<Profile />} />
                
                <Route path="/TicketPublic" element={<TicketPublic />} />
                
                <Route path="/BusinessSupport" element={<BusinessSupport />} />
                
                <Route path="/AdminSupport" element={<AdminSupport />} />
                
                <Route path="/BusinessStaff" element={<BusinessStaff />} />
                
                <Route path="/StaffInviteAccept" element={<StaffInviteAccept />} />
                
                <Route path="/BusinessProfileSetup" element={<BusinessProfileSetup />} />
                
                <Route path="/AdminActivate" element={<AdminActivate />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}