import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Switch } from "@/components/ui/switch";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  ArrowLeft,
  Crown,
  CreditCard,
  Calendar,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Download,
  Settings,
  Bell,
  Sparkles
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function ManageSubscriptionPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [showCancelConfirm, setShowCancelConfirm] = useState(false);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => base44.auth.redirectToLogin());
  }, []);

  const { data: subscription, isLoading } = useQuery({
    queryKey: ['subscription', user?.email],
    queryFn: async () => {
      if (!user) return null;
      const subs = await base44.entities.Subscription.filter({ 
        user_email: user.email,
        status: { $in: ['active', 'cancelled'] }
      }, '-created_date');
      return subs[0] || null;
    },
    enabled: !!user,
  });

  const toggleAutoRenewMutation = useMutation({
    mutationFn: async (autoRenew) => {
      await base44.entities.Subscription.update(subscription.id, {
        auto_renew: autoRenew
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['subscription'] });
    },
  });

  const cancelSubscriptionMutation = useMutation({
    mutationFn: async () => {
      await base44.entities.Subscription.update(subscription.id, {
        status: "cancelled",
        auto_renew: false
      });
      
      await base44.auth.updateMe({
        is_premium: false
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['subscription'] });
      setShowCancelConfirm(false);
    },
  });

  const reactivateSubscriptionMutation = useMutation({
    mutationFn: async () => {
      await base44.entities.Subscription.update(subscription.id, {
        status: "active",
        auto_renew: true
      });
      
      await base44.auth.updateMe({
        is_premium: true
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['subscription'] });
    },
  });

  if (isLoading || !user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 p-6">
        <div className="max-w-4xl mx-auto">
          <Skeleton className="h-12 w-64 mb-8" />
          <Skeleton className="h-96 w-full rounded-2xl" />
        </div>
      </div>
    );
  }

  if (!subscription) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 p-6">
        <div className="max-w-4xl mx-auto text-center py-20">
          <div className="text-6xl mb-4">👑</div>
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Sem Subscrição Ativa</h2>
          <p className="text-xl text-slate-600 mb-8">
            Faça upgrade para Premium e desfrute de benefícios exclusivos
          </p>
          <Button 
            size="lg"
            className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 px-8 py-6 text-lg"
            onClick={() => navigate(createPageUrl("Premium"))}
          >
            <Sparkles className="w-5 h-5 mr-2" />
            Ver Planos Premium
          </Button>
        </div>
      </div>
    );
  }

  const isPremium = subscription.plan === "premium";
  const isActive = subscription.status === "active";
  const isCancelled = subscription.status === "cancelled";
  const daysRemaining = Math.ceil((new Date(subscription.end_date) - new Date()) / (1000 * 60 * 60 * 24));

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50">
      <div className="max-w-4xl mx-auto px-6 py-8">
        {/* Header */}
        <Button
          variant="outline"
          className="mb-6 gap-2"
          onClick={() => navigate(createPageUrl("Home"))}
        >
          <ArrowLeft className="w-4 h-4" />
          Voltar
        </Button>

        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">
            Gerir Subscrição
          </h1>
          <p className="text-xl text-slate-600">
            Controle todos os aspetos da sua conta Premium
          </p>
        </div>

        {/* Alerts */}
        {isCancelled && (
          <Alert className="mb-6 border-amber-200 bg-amber-50">
            <AlertTriangle className="h-5 w-5 text-amber-600" />
            <AlertDescription className="text-amber-900">
              <strong>Subscrição Cancelada:</strong> Terá acesso Premium até {new Date(subscription.end_date).toLocaleDateString('pt-PT')}. 
              Após essa data, voltará ao plano gratuito.
            </AlertDescription>
          </Alert>
        )}

        {isActive && daysRemaining <= 7 && (
          <Alert className="mb-6 border-blue-200 bg-blue-50">
            <Bell className="h-5 w-5 text-blue-600" />
            <AlertDescription className="text-blue-900">
              Sua subscrição renova em <strong>{daysRemaining} {daysRemaining === 1 ? 'dia' : 'dias'}</strong>
            </AlertDescription>
          </Alert>
        )}

        {/* Subscription Card */}
        <Card className="mb-8 border-0 shadow-xl overflow-hidden">
          <div className={`h-3 ${
            isPremium 
              ? 'bg-gradient-to-r from-amber-400 via-orange-500 to-amber-400' 
              : 'bg-gradient-to-r from-slate-400 to-gray-500'
          }`} />
          
          <CardContent className="p-8">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-8">
              <div className="flex items-center gap-4">
                <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${
                  isPremium ? 'from-amber-500 to-orange-600' : 'from-slate-500 to-gray-600'
                } flex items-center justify-center shadow-xl`}>
                  <Crown className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h2 className="text-3xl font-bold text-slate-900">
                    Plano {subscription.plan === "premium" ? "Premium" : "Gratuito"}
                  </h2>
                  <Badge className={
                    isActive 
                      ? "bg-green-100 text-green-700 border-green-200 mt-2" 
                      : "bg-red-100 text-red-700 border-red-200 mt-2"
                  }>
                    {isActive ? (
                      <>
                        <CheckCircle2 className="w-3 h-3 mr-1" />
                        Ativa
                      </>
                    ) : (
                      <>
                        <XCircle className="w-3 h-3 mr-1" />
                        Cancelada
                      </>
                    )}
                  </Badge>
                </div>
              </div>

              <div className="text-right">
                <div className="text-4xl font-bold text-slate-900">
                  €{subscription.price}
                  <span className="text-lg text-slate-500">/mês</span>
                </div>
              </div>
            </div>

            {/* Subscription Details */}
            <div className="grid md:grid-cols-2 gap-6 mb-8">
              <div className="p-4 bg-slate-50 rounded-xl">
                <div className="flex items-center gap-2 text-slate-600 mb-2">
                  <Calendar className="w-4 h-4" />
                  <span className="text-sm font-medium">Data de Início</span>
                </div>
                <div className="text-lg font-bold text-slate-900">
                  {new Date(subscription.start_date).toLocaleDateString('pt-PT', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric'
                  })}
                </div>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl">
                <div className="flex items-center gap-2 text-slate-600 mb-2">
                  <Calendar className="w-4 h-4" />
                  <span className="text-sm font-medium">
                    {isCancelled ? 'Expira em' : 'Próxima Renovação'}
                  </span>
                </div>
                <div className="text-lg font-bold text-slate-900">
                  {new Date(subscription.end_date).toLocaleDateString('pt-PT', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric'
                  })}
                </div>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl">
                <div className="flex items-center gap-2 text-slate-600 mb-2">
                  <CreditCard className="w-4 h-4" />
                  <span className="text-sm font-medium">Método de Pagamento</span>
                </div>
                <div className="text-lg font-bold text-slate-900">
                  {subscription.payment_method || 'Cartão de Crédito'}
                </div>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl">
                <div className="flex items-center gap-2 text-slate-600 mb-2">
                  <Settings className="w-4 h-4" />
                  <span className="text-sm font-medium">Renovação Automática</span>
                </div>
                <div className="flex items-center gap-3">
                  <Switch
                    checked={subscription.auto_renew}
                    onCheckedChange={(checked) => toggleAutoRenewMutation.mutate(checked)}
                    disabled={isCancelled || toggleAutoRenewMutation.isPending}
                  />
                  <span className="font-semibold text-slate-900">
                    {subscription.auto_renew ? 'Ativada' : 'Desativada'}
                  </span>
                </div>
              </div>
            </div>

            {/* Features Included */}
            {subscription.features && subscription.features.length > 0 && (
              <div className="mb-8">
                <h3 className="font-bold text-lg text-slate-900 mb-4">Funcionalidades Incluídas</h3>
                <div className="grid md:grid-cols-2 gap-3">
                  {subscription.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-slate-700">
                      <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-4">
              {isActive ? (
                <>
                  <Button
                    variant="outline"
                    className="flex-1 gap-2"
                    onClick={() => {/* Update payment method */}}
                  >
                    <CreditCard className="w-4 h-4" />
                    Atualizar Pagamento
                  </Button>
                  
                  <Button
                    variant="outline"
                    className="flex-1 gap-2"
                    onClick={() => {/* Download invoice */}}
                  >
                    <Download className="w-4 h-4" />
                    Descarregar Faturas
                  </Button>

                  {!showCancelConfirm ? (
                    <Button
                      variant="outline"
                      className="flex-1 border-red-200 text-red-600 hover:bg-red-50 gap-2"
                      onClick={() => setShowCancelConfirm(true)}
                    >
                      <XCircle className="w-4 h-4" />
                      Cancelar Subscrição
                    </Button>
                  ) : (
                    <div className="flex-1 p-4 bg-red-50 border-2 border-red-200 rounded-xl">
                      <p className="text-sm text-red-900 mb-3 font-medium">
                        Tem a certeza? Perderá todos os benefícios Premium.
                      </p>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setShowCancelConfirm(false)}
                        >
                          Não
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => cancelSubscriptionMutation.mutate()}
                          disabled={cancelSubscriptionMutation.isPending}
                        >
                          {cancelSubscriptionMutation.isPending ? 'Cancelando...' : 'Sim, Cancelar'}
                        </Button>
                      </div>
                    </div>
                  )}
                </>
              ) : (
                <Button
                  className="flex-1 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 gap-2 py-6 text-lg"
                  onClick={() => reactivateSubscriptionMutation.mutate()}
                  disabled={reactivateSubscriptionMutation.isPending}
                >
                  <Sparkles className="w-5 h-5" />
                  {reactivateSubscriptionMutation.isPending ? 'Reativando...' : 'Reativar Premium'}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Upgrade CTA for Free Users */}
        {!isPremium && (
          <Card className="border-0 shadow-xl bg-gradient-to-br from-amber-50 to-orange-50">
            <CardContent className="p-8 text-center">
              <Crown className="w-16 h-16 text-amber-600 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-slate-900 mb-2">
                Upgrade para Premium
              </h3>
              <p className="text-slate-700 mb-6">
                Desbloqueie fila expressa, IA preditiva e muito mais
              </p>
              <Button
                size="lg"
                className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600"
                onClick={() => navigate(createPageUrl("Premium"))}
              >
                <Sparkles className="w-5 h-5 mr-2" />
                Ver Planos Premium
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}