
import React from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { Home, Clock, Building2, User, LogOut, RefreshCw, Calendar, Menu, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { LanguageProvider, useTranslation } from "@/components/i18n/LanguageContext";
import LanguageSelector from "@/components/i18n/LanguageSelector";

function LayoutContent({ children, currentPageName }) {
  const location = useLocation();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [user, setUser] = React.useState(null);
  const [currentMode, setCurrentMode] = React.useState('pessoal');
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  const [headerVisible, setHeaderVisible] = React.useState(true);
  const [lastScrollY, setLastScrollY] = React.useState(0);
  const [isRedirecting, setIsRedirecting] = React.useState(false);

  React.useEffect(() => {
    base44.auth.me().then(userData => {
      setUser(userData);
      
      // Verificar onboarding
      if (!userData.onboarding_completed && currentPageName !== 'Onboarding') {
        setIsRedirecting(true);
        navigate(createPageUrl('Onboarding'));
        return;
      }
      
      const accountType = userData.account_type || 'pessoal';
      
      // CONTA EMPRESARIAL PURA
      if (accountType === 'empresa') {
        setCurrentMode('empresa');
        
        // Fluxo empresarial: Subscrição -> Perfil -> Dashboard
        const businessPages = ['BusinessSubscription', 'BusinessProfileSetup', 'BusinessDashboard', 'BusinessQueues', 'BusinessServices', 'BusinessSettings', 'BusinessSupport', 'Profile'];
        
        if (!businessPages.includes(currentPageName)) {
          setIsRedirecting(true);
          
          if (!userData.has_business_subscription) {
            navigate(createPageUrl('BusinessSubscription'));
          } else if (!userData.business_profile_completed) {
            navigate(createPageUrl('BusinessProfileSetup'));
          } else {
            navigate(createPageUrl('BusinessDashboard'));
          }
          return;
        }
        
        // Se está numa página empresarial, verificar progressão
        if (currentPageName !== 'BusinessSubscription' && currentPageName !== 'Profile') {
          if (!userData.has_business_subscription) {
            setIsRedirecting(true);
            navigate(createPageUrl('BusinessSubscription'));
            return;
          }
          
          if (currentPageName !== 'BusinessProfileSetup' && !userData.business_profile_completed) {
            setIsRedirecting(true);
            navigate(createPageUrl('BusinessProfileSetup'));
            return;
          }
        }
      } 
      // CONTA MISTA
      else if (accountType === 'ambos') {
        const savedMode = localStorage.getItem('currentMode') || 'pessoal';
        setCurrentMode(savedMode);
      } 
      // CONTA PESSOAL
      else {
        setCurrentMode('pessoal');
      }
      
      setIsRedirecting(false);
    }).catch(() => {
      setIsRedirecting(false);
    });
  }, [navigate, currentPageName]);

  React.useEffect(() => {
    const controlHeader = () => {
      const currentScrollY = window.scrollY;
      
      if (currentScrollY < lastScrollY || currentScrollY < 10) {
        setHeaderVisible(true);
      } else if (currentScrollY > lastScrollY && currentScrollY > 50) {
        setHeaderVisible(false);
      }
      
      setLastScrollY(currentScrollY);
    };

    window.addEventListener('scroll', controlHeader);
    return () => window.removeEventListener('scroll', controlHeader);
  }, [lastScrollY]);

  const canSwitchMode = user?.account_type === 'ambos';
  const isBusinessMode = currentMode === 'empresa' || user?.account_type === 'empresa';

  const toggleMode = () => {
    if (user?.account_type !== 'ambos') return;
    
    const newMode = currentMode === 'pessoal' ? 'empresa' : 'pessoal';
    setCurrentMode(newMode);
    localStorage.setItem('currentMode', newMode);
    setMobileMenuOpen(false);
    
    if (newMode === 'empresa') {
      navigate(createPageUrl('BusinessDashboard'));
    } else {
      navigate(createPageUrl('Home'));
    }
  };

  // Mostrar loading se estiver a redirecionar ou ainda sem user
  if (isRedirecting || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-sky-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-600">A carregar...</p>
        </div>
      </div>
    );
  }

  // Layout especial para páginas de subscrição/setup empresarial (sem navegação)
  const isBusinessOnboarding = ['BusinessSubscription', 'BusinessProfileSetup'].includes(currentPageName);
  
  if (user?.account_type === 'empresa' && isBusinessOnboarding) {
    return (
      <div className="min-h-screen flex bg-gradient-to-br from-slate-50 to-blue-50">
        <main className="flex-1 flex flex-col animate-fade-in">
          <div className="flex-1 overflow-auto">
            {children}
          </div>
        </main>
      </div>
    );
  }

  const navigationItems = isBusinessMode ? [
    { title: t('dashboard'), url: createPageUrl("BusinessDashboard"), icon: Clock },
    { title: t('queues'), url: createPageUrl("BusinessQueues"), icon: Clock },
    { title: t('services'), url: createPageUrl("BusinessServices"), icon: Calendar },
    { title: t('settings'), url: createPageUrl("BusinessSettings"), icon: Building2 }
  ] : user ? [
    { title: t('home'), url: createPageUrl("Home"), icon: Home },
    { title: t('portal'), url: createPageUrl("CustomerPortal"), icon: User },
    { title: t('businesses'), url: createPageUrl("Businesses"), icon: Building2 }
  ] : [
    { title: t('home'), url: createPageUrl("Home"), icon: Home }
  ];

  const displayName = user?.nome_completo || user?.full_name || 'Utilizador';

  const NavContent = () => (
    <>
      <div className={`p-3 border-b animate-slide-in-down ${
        isBusinessMode 
          ? 'bg-gradient-to-br from-indigo-600 to-purple-700' 
          : 'bg-gradient-to-br from-sky-500 to-blue-600'
      }`}>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center shadow-lg hover-lift">
            <Clock className={isBusinessMode ? 'w-5 h-5 text-indigo-600' : 'w-5 h-5 text-sky-600'} />
          </div>
          <div>
            <h2 className="font-bold text-base text-white">QZero</h2>
            <p className="text-xs text-white/80">
              {isBusinessMode ? t('business') : t('noQueues')}
            </p>
          </div>
        </div>
      </div>

      {canSwitchMode && (
        <div className="p-2 animate-slide-in-left">
          <Button
            variant="outline"
            className="w-full justify-start gap-2 text-sm h-9 smooth-transition"
            onClick={toggleMode}
          >
            <RefreshCw className="w-4 h-4" />
            <span className="flex-1 text-left">
              {isBusinessMode ? t('personal') : t('business')}
            </span>
          </Button>
        </div>
      )}

      <nav className="flex-1 p-2">
        <div className="space-y-1">
          {navigationItems.map((item, idx) => (
            <Link
              key={item.title}
              to={item.url}
              onClick={() => setMobileMenuOpen(false)}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg smooth-transition text-sm stagger-item ${
                location.pathname === item.url 
                  ? 'bg-gradient-to-r from-sky-50 to-blue-50 text-sky-700 font-semibold shadow-sm' 
                  : 'hover:bg-slate-50 hover:scale-[1.02]'
              }`}
              style={{ animationDelay: `${idx * 0.05}s` }}
            >
              <item.icon className="w-4 h-4" />
              <span>{item.title}</span>
            </Link>
          ))}

          {user && (
            <>
              <Link
                to={createPageUrl("Profile")}
                onClick={() => setMobileMenuOpen(false)}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg smooth-transition text-sm ${
                  location.pathname === createPageUrl("Profile") 
                    ? 'bg-gradient-to-r from-sky-50 to-blue-50 text-sky-700 font-semibold shadow-sm' 
                    : 'hover:bg-slate-50 hover:scale-[1.02]'
                }`}
              >
                <User className="w-4 h-4" />
                <span>{t('profile')}</span>
              </Link>

              {isBusinessMode && (
                <Link
                  to={createPageUrl("BusinessSupport")}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg smooth-transition text-sm ${
                    location.pathname === createPageUrl("BusinessSupport") 
                      ? 'bg-gradient-to-r from-sky-50 to-blue-50 text-sky-700 font-semibold shadow-sm' 
                      : 'hover:bg-slate-50 hover:scale-[1.02]'
                  }`}
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>{t('support')}</span>
                </Link>
              )}
            </>
          )}
        </div>
      </nav>

      <div className="p-2 border-t">
        <LanguageSelector variant="outline" />
      </div>

      {user && (
        <div className="border-t p-3 animate-slide-in-up">
          <div className="flex items-center gap-2 mb-2">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center shadow-md relative smooth-transition hover:scale-110 ${
              isBusinessMode 
                ? 'bg-gradient-to-br from-indigo-400 to-purple-500'
                : 'bg-gradient-to-br from-sky-400 to-blue-500'
            }`}>
              <span className="text-white font-bold text-xs">{displayName[0] || user.email[0].toUpperCase()}</span>
              {isBusinessMode && (
                <div className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center border-2 border-white animate-pulse-slow">
                  <Building2 className="w-2.5 h-2.5 text-white" />
                </div>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-xs truncate">{displayName}</p>
              <p className="text-xs text-slate-500 truncate">{user.email}</p>
            </div>
          </div>
          <Button 
            variant="outline" 
            size="sm" 
            className="w-full justify-start gap-2 hover:bg-red-50 hover:text-red-600 h-8 text-sm smooth-transition hover:scale-[1.02]"
            onClick={() => base44.auth.logout()}
          >
            <LogOut className="w-3.5 h-3.5" />
            {t('logout')}
          </Button>
        </div>
      )}
    </>
  );

  return (
    <div className="min-h-screen flex bg-gradient-to-br from-slate-50 to-blue-50">
      <aside className="hidden lg:flex lg:flex-col lg:w-64 border-r border-slate-200/60 bg-white shadow-sm animate-slide-in-left">
        <NavContent />
      </aside>

      <header className={`lg:hidden fixed top-0 left-0 right-0 z-50 glass-effect border-b border-slate-200/60 px-3 py-2.5 transition-transform duration-300 ${
        headerVisible ? 'translate-y-0' : '-translate-y-full'
      }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8 smooth-transition hover:scale-110">
                  <Menu className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-64 p-0 animate-slide-in-left">
                <NavContent />
              </SheetContent>
            </Sheet>
            <div className="flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-sky-600" />
              <h1 className="text-base font-bold text-slate-900">QZero</h1>
            </div>
          </div>
          {isBusinessMode && user && (
            <Badge className="bg-gradient-to-r from-indigo-600 to-purple-700 text-white border-0 text-xs px-2 py-0.5 animate-scale-in">
              <Building2 className="w-3 h-3 mr-1" />
              B2B
            </Badge>
          )}
        </div>
      </header>

      <main className="flex-1 flex flex-col lg:pt-0 pt-12 animate-fade-in">
        <div className="flex-1 overflow-auto">
          {children}
        </div>
      </main>
    </div>
  );
}

export default function Layout({ children, currentPageName }) {
  return (
    <LanguageProvider>
      <LayoutContent children={children} currentPageName={currentPageName} />
    </LanguageProvider>
  );
}
