import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { MessageSquare, Send, Clock, CheckCircle2, AlertCircle, Paperclip, FileText, X } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { pt } from "date-fns/locale";
import { toast } from "sonner";

const statusConfig = {
  pendente: { icon: Clock, color: "bg-amber-100 text-amber-700 border-amber-200", label: "Pendente" },
  em_analise: { icon: AlertCircle, color: "bg-blue-100 text-blue-700 border-blue-200", label: "Em Análise" },
  resolvido: { icon: CheckCircle2, color: "bg-green-100 text-green-700 border-green-200", label: "Resolvido" }
};

export default function BusinessSupportPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [formData, setFormData] = useState({
    subject: '',
    message: ''
  });
  const [attachments, setAttachments] = useState([]);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    base44.auth.me().then(userData => {
      setUser(userData);
      if (!userData.is_business_user || !userData.business_id) {
        navigate(createPageUrl("Home"));
      }
    }).catch(() => base44.auth.redirectToLogin());
  }, [navigate]);

  const { data: business } = useQuery({
    queryKey: ['business', user?.business_id],
    queryFn: async () => {
      const businesses = await base44.entities.Business.filter({ id: user.business_id });
      return businesses[0];
    },
    enabled: !!user?.business_id,
  });

  const { data: messages, isLoading } = useQuery({
    queryKey: ['support-messages', user?.business_id],
    queryFn: () => base44.entities.SupportMessage.filter({ 
      business_id: user.business_id 
    }, '-created_date'),
    initialData: [],
    enabled: !!user?.business_id,
    refetchInterval: 30000,
  });

  const handleFileUpload = async (e) => {
    const files = Array.from(e.target.files);
    setUploading(true);
    
    try {
      const uploadedUrls = [];
      for (const file of files) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        uploadedUrls.push({ url: file_url, name: file.name });
      }
      setAttachments([...attachments, ...uploadedUrls]);
      toast.success('Ficheiros anexados!');
    } catch (error) {
      toast.error('Erro ao anexar ficheiros');
    } finally {
      setUploading(false);
    }
  };

  const removeAttachment = (index) => {
    setAttachments(attachments.filter((_, i) => i !== index));
  };

  const createMessageMutation = useMutation({
    mutationFn: async (data) => {
      const message = await base44.entities.SupportMessage.create({
        ...data,
        priority: 'media',
        business_id: user.business_id,
        user_email: user.email,
        user_name: user.full_name || user.email,
        attachments: attachments.map(a => a.url)
      });

      try {
        await base44.integrations.Core.SendEmail({
          from_name: 'QZero App',
          to: 'suporteqzero@gmail.com',
          subject: `[Suporte QZero] ${data.subject}`,
          body: `Nova mensagem de suporte recebida:

Empresa: ${business?.name || 'N/A'}
Utilizador: ${user.full_name || user.email}
Email: ${user.email}

Assunto: ${data.subject}

Mensagem:
${data.message}

${attachments.length > 0 ? `\nAnexos:\n${attachments.map(a => a.url).join('\n')}` : ''}

---
ID da Mensagem: ${message.id}
Data: ${new Date().toLocaleString('pt-PT')}`
        });
      } catch (emailError) {
        console.error('Erro ao enviar email:', emailError);
      }

      return message;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['support-messages'] });
      setFormData({ subject: '', message: '' });
      setAttachments([]);
      toast.success('Mensagem enviada com sucesso!');
    },
    onError: (error) => {
      toast.error('Erro ao enviar mensagem');
      console.error('Error:', error);
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.subject.trim() || !formData.message.trim()) {
      toast.error('Preencha todos os campos');
      return;
    }
    createMessageMutation.mutate(formData);
  };

  if (!user || isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 p-6">
        <div className="max-w-4xl mx-auto">
          <Skeleton className="h-16 w-64 mb-8" />
          <Skeleton className="h-96 w-full" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50">
      <div className="max-w-4xl mx-auto px-6 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Suporte QZero</h1>
          <p className="text-slate-600">Entre em contacto connosco para ajuda ou sugestões</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <Card className="border-0 shadow-lg">
            <CardHeader className="bg-gradient-to-r from-sky-500 to-blue-600 text-white">
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5" />
                Nova Mensagem
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="subject">Assunto *</Label>
                  <Input
                    id="subject"
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    placeholder="Ex: Dúvida sobre funcionalidade"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="message">Mensagem *</Label>
                  <Textarea
                    id="message"
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Descreva a sua questão ou sugestão..."
                    rows={6}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="files">Anexar Ficheiros</Label>
                  <Input
                    id="files"
                    type="file"
                    multiple
                    onChange={handleFileUpload}
                    disabled={uploading}
                    className="mt-2"
                  />
                  {attachments.length > 0 && (
                    <div className="mt-2 space-y-2">
                      {attachments.map((file, idx) => (
                        <div key={idx} className="flex items-center gap-2 p-2 bg-slate-50 rounded text-sm">
                          <Paperclip className="w-4 h-4 text-slate-500" />
                          <span className="flex-1 truncate">{file.name}</span>
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => removeAttachment(idx)}
                            className="h-6 w-6 p-0"
                          >
                            <X className="w-3 h-3" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 gap-2"
                  disabled={createMessageMutation.isPending || uploading}
                >
                  <Send className="w-4 h-4" />
                  {createMessageMutation.isPending ? 'Enviando...' : 'Enviar Mensagem'}
                </Button>
              </form>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg">
            <CardHeader className="bg-slate-50">
              <CardTitle className="text-lg">Informações de Contacto</CardTitle>
            </CardHeader>
            <CardContent className="p-6 space-y-4">
              <div>
                <h4 className="font-semibold text-slate-900 mb-2">Email</h4>
                <p className="text-sm text-slate-600">suporteqzero@gmail.com</p>
              </div>

              <div>
                <h4 className="font-semibold text-slate-900 mb-2">Horário de Suporte</h4>
                <p className="text-sm text-slate-600">Segunda a Sexta: 9h - 18h</p>
                <p className="text-sm text-slate-600">Sábado e Domingo: Fechado</p>
              </div>

              <div>
                <h4 className="font-semibold text-slate-900 mb-2">Tempo de Resposta</h4>
                <p className="text-sm text-slate-600">Normalmente respondemos em 24 horas</p>
              </div>

              <div className="pt-4 border-t">
                <h4 className="font-semibold text-slate-900 mb-2">Tipos de Suporte</h4>
                <ul className="text-sm text-slate-600 space-y-1">
                  <li>• Dúvidas técnicas</li>
                  <li>• Problemas de funcionamento</li>
                  <li>• Sugestões de melhorias</li>
                  <li>• Pedidos de funcionalidades</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="border-0 shadow-lg">
          <CardHeader className="bg-slate-50">
            <CardTitle>Histórico de Mensagens</CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            {messages.length === 0 ? (
              <div className="text-center py-12">
                <MessageSquare className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                <h3 className="text-lg font-bold text-slate-900 mb-2">Nenhuma mensagem ainda</h3>
                <p className="text-slate-600">As suas mensagens aparecerão aqui</p>
              </div>
            ) : (
              <div className="space-y-4">
                {messages.map(msg => {
                  const status = statusConfig[msg.status];
                  const StatusIcon = status.icon;

                  return (
                    <Card key={msg.id} className="border-2">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start mb-3">
                          <div className="flex-1">
                            <h4 className="font-bold text-slate-900 mb-1">{msg.subject}</h4>
                            <p className="text-xs text-slate-500">
                              {format(new Date(msg.created_date), "dd MMM yyyy 'às' HH:mm", { locale: pt })}
                            </p>
                          </div>
                          <Badge className={status.color}>
                            <StatusIcon className="w-3 h-3 mr-1" />
                            {status.label}
                          </Badge>
                        </div>

                        <div className="p-3 bg-slate-50 rounded-lg mb-3">
                          <p className="text-sm text-slate-700 whitespace-pre-wrap">{msg.message}</p>
                        </div>

                        {msg.attachments?.length > 0 && (
                          <div className="mb-3">
                            <p className="text-xs font-semibold text-slate-700 mb-2">Anexos:</p>
                            <div className="space-y-1">
                              {msg.attachments.map((url, idx) => (
                                <a
                                  key={idx}
                                  href={url}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="flex items-center gap-2 p-2 bg-slate-50 rounded hover:bg-slate-100 text-sm"
                                >
                                  <FileText className="w-4 h-4 text-slate-600" />
                                  Ficheiro {idx + 1}
                                </a>
                              ))}
                            </div>
                          </div>
                        )}

                        {msg.response && (
                          <div className="p-3 bg-gradient-to-r from-sky-50 to-blue-50 rounded-lg border-l-4 border-sky-500">
                            <div className="flex items-center gap-2 mb-2">
                              <div className="w-8 h-8 rounded-full bg-sky-500 flex items-center justify-center">
                                <span className="text-white font-bold text-xs">Q</span>
                              </div>
                              <div>
                                <p className="text-xs font-semibold text-slate-900">Equipa QZero</p>
                                {msg.response_date && (
                                  <p className="text-xs text-slate-500">
                                    {format(new Date(msg.response_date), "dd MMM 'às' HH:mm", { locale: pt })}
                                  </p>
                                )}
                              </div>
                            </div>
                            <p className="text-sm text-slate-700 whitespace-pre-wrap mb-2">{msg.response}</p>
                            
                            {msg.response_attachments?.length > 0 && (
                              <div className="mt-2">
                                <p className="text-xs font-semibold text-slate-700 mb-1">Anexos da Resposta:</p>
                                <div className="space-y-1">
                                  {msg.response_attachments.map((url, idx) => (
                                    <a
                                      key={idx}
                                      href={url}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="flex items-center gap-2 p-2 bg-white rounded hover:bg-slate-50 text-sm"
                                    >
                                      <FileText className="w-4 h-4 text-sky-600" />
                                      Ficheiro {idx + 1}
                                    </a>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}