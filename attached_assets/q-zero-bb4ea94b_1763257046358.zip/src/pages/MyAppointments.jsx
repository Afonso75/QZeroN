import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Calendar, Clock, MapPin, XCircle, CheckCircle2, AlertCircle } from "lucide-react";
import { format } from "date-fns";
import { pt } from "date-fns/locale";

const statusConfig = {
  agendado: { icon: Calendar, color: "bg-blue-100 text-blue-700", label: "Agendado" },
  confirmado: { icon: CheckCircle2, color: "bg-green-100 text-green-700", label: "Confirmado" },
  em_atendimento: { icon: Clock, color: "bg-purple-100 text-purple-700", label: "Em Atendimento" },
  concluido: { icon: CheckCircle2, color: "bg-green-100 text-green-700", label: "Concluído" },
  cancelado: { icon: XCircle, color: "bg-red-100 text-red-700", label: "Cancelado" },
  falta: { icon: AlertCircle, color: "bg-orange-100 text-orange-700", label: "Faltou" }
};

export default function MyAppointmentsPage() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => base44.auth.redirectToLogin());
  }, []);

  const { data: appointments, isLoading } = useQuery({
    queryKey: ['my-appointments', user?.email],
    queryFn: () => user ? base44.entities.Appointment.filter({ 
      user_email: user.email 
    }, '-appointment_date') : [],
    enabled: !!user,
    initialData: [],
  });

  const { data: services } = useQuery({
    queryKey: ['appointment-services'],
    queryFn: async () => {
      const serviceIds = [...new Set(appointments.map(a => a.service_id))];
      if (serviceIds.length === 0) return [];
      const services = await Promise.all(
        serviceIds.map(id => base44.entities.Service.filter({ id }).then(s => s[0]))
      );
      return services.filter(Boolean);
    },
    enabled: appointments.length > 0,
    initialData: [],
  });

  const { data: businesses } = useQuery({
    queryKey: ['appointment-businesses'],
    queryFn: async () => {
      const businessIds = [...new Set(appointments.map(a => a.business_id))];
      if (businessIds.length === 0) return [];
      const businesses = await Promise.all(
        businessIds.map(id => base44.entities.Business.filter({ id }).then(b => b[0]))
      );
      return businesses.filter(Boolean);
    },
    enabled: appointments.length > 0,
    initialData: [],
  });

  const cancelMutation = useMutation({
    mutationFn: (id) => base44.entities.Appointment.update(id, { status: 'cancelado' }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['my-appointments'] });
    },
  });

  const upcomingAppointments = appointments.filter(a => 
    ['agendado', 'confirmado'].includes(a.status) &&
    new Date(`${a.appointment_date}T${a.appointment_time}`) >= new Date()
  );

  const pastAppointments = appointments.filter(a =>
    ['concluido', 'cancelado', 'falta'].includes(a.status) ||
    new Date(`${a.appointment_date}T${a.appointment_time}`) < new Date()
  );

  const getServiceName = (serviceId) => {
    return services.find(s => s.id === serviceId)?.name || 'Serviço';
  };

  const getBusinessName = (businessId) => {
    return businesses.find(b => b.id === businessId)?.name || 'Empresa';
  };

  const renderAppointment = (appointment) => {
    const status = statusConfig[appointment.status];
    const StatusIcon = status.icon;
    const isPast = new Date(`${appointment.appointment_date}T${appointment.appointment_time}`) < new Date();
    const canCancel = ['agendado', 'confirmado'].includes(appointment.status) && !isPast;

    return (
      <Card key={appointment.id} className="hover:shadow-lg transition-shadow">
        <CardContent className="p-6">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h3 className="font-bold text-lg text-slate-900 mb-1">
                {getServiceName(appointment.service_id)}
              </h3>
              <p className="text-sm text-slate-600">{getBusinessName(appointment.business_id)}</p>
            </div>
            <Badge className={status.color}>
              <StatusIcon className="w-3 h-3 mr-1" />
              {status.label}
            </Badge>
          </div>

          <div className="space-y-2 text-sm text-slate-700 mb-4">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-slate-500" />
              {format(new Date(appointment.appointment_date), "dd 'de' MMMM 'de' yyyy", { locale: pt })}
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-slate-500" />
              {appointment.appointment_time}
            </div>
          </div>

          {appointment.notes && (
            <div className="mb-4 p-3 bg-slate-50 rounded-lg text-sm text-slate-600">
              <strong>Observações:</strong> {appointment.notes}
            </div>
          )}

          <div className="flex gap-2">
            {canCancel && (
              <Button
                variant="outline"
                size="sm"
                className="border-red-200 text-red-600 hover:bg-red-50"
                onClick={() => {
                  if (confirm('Tem certeza que deseja cancelar esta marcação?')) {
                    cancelMutation.mutate(appointment.id);
                  }
                }}
              >
                <XCircle className="w-3 h-3 mr-1" />
                Cancelar
              </Button>
            )}
            <Link to={createPageUrl(`BusinessDetail?id=${appointment.business_id}`)}>
              <Button variant="outline" size="sm">
                Ver Empresa
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    );
  };

  if (!user) {
    return <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 flex items-center justify-center">
      <div className="animate-pulse">A carregar...</div>
    </div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50">
      <div className="max-w-6xl mx-auto px-6 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">Minhas Marcações</h1>
          <p className="text-xl text-slate-600">Gerir os seus agendamentos</p>
        </div>

        <Tabs defaultValue="proximas" className="space-y-6">
          <TabsList className="bg-white border border-slate-200">
            <TabsTrigger value="proximas">
              Próximas ({upcomingAppointments.length})
            </TabsTrigger>
            <TabsTrigger value="historico">
              Histórico ({pastAppointments.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="proximas">
            {upcomingAppointments.length === 0 ? (
              <Card>
                <CardContent className="py-16 text-center">
                  <Calendar className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-slate-900 mb-2">
                    Sem marcações agendadas
                  </h3>
                  <p className="text-slate-600 mb-6">
                    Explore empresas e agende o seu próximo serviço
                  </p>
                  <Link to={createPageUrl("Businesses")}>
                    <Button>Explorar Empresas</Button>
                  </Link>
                </CardContent>
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 gap-6">
                {upcomingAppointments.map(renderAppointment)}
              </div>
            )}
          </TabsContent>

          <TabsContent value="historico">
            {pastAppointments.length === 0 ? (
              <Card>
                <CardContent className="py-16 text-center text-slate-500">
                  Sem histórico de marcações
                </CardContent>
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 gap-6">
                {pastAppointments.map(renderAppointment)}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}