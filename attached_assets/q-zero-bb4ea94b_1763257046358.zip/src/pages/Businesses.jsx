import React, { useState, useMemo, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Search, 
  MapPin, 
  Star, 
  Sparkles,
  Navigation,
  AlertCircle
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { calculateDistance } from "@/components/shared/LocationService";

const categories = [
  { value: 'todos', label: 'Todas', icon: '📍' },
  { value: 'saude', label: 'Saúde', icon: '🏥' },
  { value: 'financeiro', label: 'Financeiro', icon: '🏦' },
  { value: 'governo', label: 'Governo', icon: '🏛️' },
  { value: 'restauracao', label: 'Restauração', icon: '🍽️' },
  { value: 'beleza', label: 'Beleza', icon: '💇' },
  { value: 'retalho', label: 'Retalho', icon: '🛍️' },
  { value: 'outros', label: 'Outros', icon: '📍' }
];

const categoryColors = {
  saude: 'from-red-500 to-pink-500',
  financeiro: 'from-blue-500 to-cyan-500',
  governo: 'from-purple-500 to-indigo-500',
  restauracao: 'from-orange-500 to-amber-500',
  beleza: 'from-pink-500 to-rose-500',
  retalho: 'from-green-500 to-emerald-500',
  outros: 'from-slate-500 to-gray-500'
};

export default function BusinessesPage() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("todos");
  const [user, setUser] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: businesses = [], isLoading: businessesLoading } = useQuery({
    queryKey: ['active-businesses'],
    queryFn: () => base44.entities.Business.filter({ is_active: true }),
    initialData: [],
  });

  const { data: queues = [] } = useQuery({
    queryKey: ['all-queues'],
    queryFn: () => base44.entities.Queue.list(),
    initialData: [],
  });

  const { data: services = [] } = useQuery({
    queryKey: ['all-services'],
    queryFn: () => base44.entities.Service.list(),
    initialData: [],
  });

  const userCountry = user?.country;

  const filteredBusinesses = useMemo(() => {
    if (!businesses.length) return [];

    let filtered = businesses;

    // Filtrar por país do utilizador
    if (userCountry) {
      filtered = filtered.filter(business => {
        const addressParts = business.address?.split(',') || [];
        const businessCountry = addressParts[addressParts.length - 1]?.trim().toLowerCase();
        
        const countryMap = {
          'pt': ['portugal', 'pt'],
          'fr': ['france', 'frança', 'fr'],
          'es': ['spain', 'espanha', 'españa', 'es'],
          'uk': ['united kingdom', 'reino unido', 'uk'],
          'de': ['germany', 'alemanha', 'deutschland', 'de'],
          'it': ['italy', 'itália', 'it'],
          'nl': ['netherlands', 'holanda', 'nl'],
          'be': ['belgium', 'bélgica', 'be'],
          'br': ['brazil', 'brasil', 'br'],
          'us': ['united states', 'estados unidos', 'us']
        };

        const userCountryLower = userCountry.toLowerCase();
        const matchTerms = countryMap[userCountryLower] || [userCountryLower];
        
        return matchTerms.some(term => businessCountry?.includes(term));
      });
    }

    // Filtrar por categoria
    if (selectedCategory !== 'todos') {
      filtered = filtered.filter(b => b.category === selectedCategory);
    }

    // Filtrar por termo de pesquisa
    if (searchTerm) {
      filtered = filtered.filter(b =>
        b.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        b.description?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Ordenar por distância se houver coordenadas
    filtered = filtered.map(business => {
      const distance = business.latitude && business.longitude && user?.latitude && user?.longitude
        ? calculateDistance(user.latitude, user.longitude, business.latitude, business.longitude)
        : null;
      
      return { ...business, distance };
    }).sort((a, b) => {
      if (a.distance === null) return 1;
      if (b.distance === null) return -1;
      return a.distance - b.distance;
    });

    return filtered;
  }, [businesses, searchTerm, selectedCategory, userCountry, user]);

  const formatDistance = (distance) => {
    if (!distance) return null;
    if (distance < 1) return `${Math.round(distance * 1000)}m`;
    return `${distance.toFixed(1)}km`;
  };

  if (businessesLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6">
        <div className="max-w-6xl mx-auto">
          <Skeleton className="h-12 w-64 mb-6" />
          <div className="grid md:grid-cols-2 gap-4">
            {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-40" />)}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">
            Empresas Disponíveis
          </h1>
          {userCountry ? (
            <p className="text-slate-600 flex items-center gap-2">
              <Navigation className="w-4 h-4 text-green-600" />
              A mostrar empresas no seu país
            </p>
          ) : (
            <Alert className="mt-4 border-blue-200 bg-blue-50">
              <AlertCircle className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-blue-800">
                Configure o seu país no perfil para ver apenas empresas na sua região.
                <Button
                  variant="link"
                  className="p-0 h-auto ml-2 text-blue-700 underline"
                  onClick={() => navigate(createPageUrl("Profile"))}
                >
                  Ir para o perfil
                </Button>
              </AlertDescription>
            </Alert>
          )}
        </div>

        <div className="grid md:grid-cols-2 gap-4 mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              placeholder="Procurar empresas..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {categories.map(cat => (
                <SelectItem key={cat.value} value={cat.value}>
                  {cat.icon} {cat.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="mb-4">
          <p className="text-sm text-slate-600">
            {filteredBusinesses.length} {filteredBusinesses.length === 1 ? 'empresa encontrada' : 'empresas encontradas'}
          </p>
        </div>

        {filteredBusinesses.length === 0 ? (
          <Card className="border-0 shadow-lg">
            <CardContent className="py-16 text-center">
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="w-8 h-8 text-slate-400" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">
                Nenhuma empresa encontrada
              </h3>
              <p className="text-slate-600">
                {userCountry 
                  ? 'Não há empresas disponíveis no seu país com os filtros selecionados'
                  : 'Configure o seu país no perfil para ver empresas próximas'}
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            {filteredBusinesses.map(business => {
              const businessQueues = queues.filter(q => q.business_id === business.id);
              const businessServices = services.filter(s => s.business_id === business.id);
              const hasQueues = businessQueues.length > 0;
              const hasServices = businessServices.length > 0;

              return (
                <Card key={business.id} className="border-0 shadow-md hover:shadow-xl transition-all">
                  <CardContent className="p-4">
                    <div className="flex gap-3 mb-3">
                      {business.logo_url && (
                        <img 
                          src={business.logo_url} 
                          alt={business.name}
                          className="w-16 h-16 rounded-lg object-cover flex-shrink-0"
                        />
                      )}
                      <div className="flex-1 min-w-0">
                        <h3 className="font-bold text-lg text-slate-900 mb-1 truncate">
                          {business.name}
                        </h3>
                        {business.description && (
                          <p className="text-sm text-slate-600 mb-2 line-clamp-2">
                            {business.description}
                          </p>
                        )}
                        <div className="flex flex-wrap items-center gap-2 text-xs">
                          {business.distance !== null && business.distance !== undefined && (
                            <Badge variant="outline" className="gap-1 bg-green-50 text-green-700 border-green-200">
                              <Navigation className="w-3 h-3" />
                              {formatDistance(business.distance)}
                            </Badge>
                          )}
                          {business.address && (
                            <Badge variant="outline" className="gap-1">
                              <MapPin className="w-3 h-3" />
                              {business.address.split(',')[0]}
                            </Badge>
                          )}
                          {business.rating && (
                            <Badge variant="outline" className="gap-1">
                              <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                              {business.rating.toFixed(1)}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      {hasQueues && (
                        <Button
                          onClick={() => navigate(createPageUrl(`BusinessDetail?id=${business.id}`))}
                          size="sm"
                          className={`flex-1 bg-gradient-to-r ${categoryColors[business.category] || 'from-sky-500 to-blue-600'} hover:opacity-90 text-xs`}
                        >
                          Tirar Senha
                        </Button>
                      )}
                      {hasServices && (
                        <Button
                          onClick={() => navigate(createPageUrl(`BusinessDetail?id=${business.id}`))}
                          size="sm"
                          variant="outline"
                          className="flex-1 text-xs"
                        >
                          Fazer Marcação
                        </Button>
                      )}
                      {!hasQueues && !hasServices && (
                        <Button
                          onClick={() => navigate(createPageUrl(`BusinessDetail?id=${business.id}`))}
                          size="sm"
                          variant="outline"
                          className="flex-1 text-xs gap-1"
                        >
                          <Sparkles className="w-3 h-3" />
                          Ver Empresa
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}