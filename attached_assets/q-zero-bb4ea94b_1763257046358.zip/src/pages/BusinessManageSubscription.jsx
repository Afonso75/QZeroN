import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  CheckCircle2, 
  Building2, 
  Calendar,
  CreditCard,
  AlertCircle,
  Crown,
  ArrowLeft
} from "lucide-react";
import { format, differenceInDays } from "date-fns";
import { pt } from "date-fns/locale";

export default function BusinessManageSubscriptionPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {
      base44.auth.redirectToLogin();
    });
  }, []);

  const { data: subscription, isLoading } = useQuery({
    queryKey: ['business-subscription', user?.email],
    queryFn: async () => {
      if (!user) return null;
      const subs = await base44.entities.Subscription.filter({
        user_email: user.email,
        plan: "business",
        status: "active"
      });
      return subs[0] || null;
    },
    enabled: !!user,
  });

  const cancelMutation = useMutation({
    mutationFn: async () => {
      return await base44.entities.Subscription.update(subscription.id, {
        status: "cancelled",
        auto_renew: false
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['business-subscription'] });
    },
  });

  if (!user || isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 flex items-center justify-center p-6">
        <p>A carregar...</p>
      </div>
    );
  }

  if (!subscription) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 p-6">
        <div className="max-w-4xl mx-auto">
          <Button
            variant="outline"
            onClick={() => navigate(createPageUrl("BusinessDashboard"))}
            className="mb-6"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar
          </Button>

          <Card className="border-0 shadow-xl">
            <CardContent className="py-16 text-center">
              <AlertCircle className="w-16 h-16 text-slate-400 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-slate-900 mb-2">
                Sem Subscrição Ativa
              </h2>
              <p className="text-slate-600 mb-6">
                Não tem uma subscrição empresarial ativa
              </p>
              <Button
                onClick={() => navigate(createPageUrl("BusinessSubscription"))}
                className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
              >
                Ver Planos
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const endDate = new Date(subscription.end_date);
  const today = new Date();
  const daysRemaining = differenceInDays(endDate, today);
  const isExpiringSoon = daysRemaining <= 7;
  const nextBillingDate = format(endDate, "dd 'de' MMMM 'de' yyyy", { locale: pt });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 p-6">
      <div className="max-w-4xl mx-auto">
        <Button
          variant="outline"
          onClick={() => navigate(createPageUrl("BusinessDashboard"))}
          className="mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar ao Painel
        </Button>

        <div className="mb-6">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">
            Subscrição Empresarial
          </h1>
          <p className="text-slate-600">Gerir plano e faturação</p>
        </div>

        {/* Status Card */}
        <Card className="border-0 shadow-xl mb-6">
          <CardContent className="p-8">
            <div className="flex items-start justify-between mb-6">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center">
                  <Building2 className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-slate-900 mb-1">
                    Plano Empresarial
                  </h3>
                  <Badge className="bg-green-100 text-green-700 border-green-200">
                    <CheckCircle2 className="w-3 h-3 mr-1" />
                    Ativo
                  </Badge>
                </div>
              </div>
              <div className="text-right">
                <div className="text-3xl font-bold text-slate-900">€50</div>
                <div className="text-sm text-slate-600">por mês</div>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6 mb-6">
              <div className="p-4 bg-slate-50 rounded-xl">
                <div className="flex items-center gap-2 mb-2">
                  <Calendar className="w-5 h-5 text-slate-600" />
                  <span className="text-sm text-slate-600">Próxima Faturação</span>
                </div>
                <div className="text-lg font-semibold text-slate-900">
                  {nextBillingDate}
                </div>
                {isExpiringSoon && (
                  <div className="text-sm text-amber-600 mt-1">
                    Renova em {daysRemaining} {daysRemaining === 1 ? 'dia' : 'dias'}
                  </div>
                )}
              </div>

              <div className="p-4 bg-slate-50 rounded-xl">
                <div className="flex items-center gap-2 mb-2">
                  <CreditCard className="w-5 h-5 text-slate-600" />
                  <span className="text-sm text-slate-600">Método de Pagamento</span>
                </div>
                <div className="text-lg font-semibold text-slate-900">
                  {subscription.payment_method || 'Stripe'}
                </div>
                <div className="text-sm text-slate-500 mt-1">
                  Renovação automática {subscription.auto_renew ? 'ativa' : 'inativa'}
                </div>
              </div>
            </div>

            <div className="p-4 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl border border-indigo-100">
              <h4 className="font-semibold text-slate-900 mb-3">Funcionalidades Incluídas:</h4>
              <div className="grid md:grid-cols-2 gap-2">
                {subscription.features?.map((feature, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-sm text-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-indigo-600 flex-shrink-0" />
                    {feature}
                  </div>
                )) || [
                  "Gestão de filas ilimitadas",
                  "Sistema de marcações",
                  "Análise e estatísticas",
                  "Notificações automáticas",
                  "Suporte prioritário"
                ].map((feature, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-sm text-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-indigo-600 flex-shrink-0" />
                    {feature}
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Billing History */}
        <Card className="border-0 shadow-xl mb-6">
          <CardHeader>
            <CardTitle>Histórico de Faturação</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center p-4 bg-slate-50 rounded-lg">
                <div>
                  <div className="font-semibold text-slate-900">
                    {format(new Date(subscription.start_date), "MMMM yyyy", { locale: pt })}
                  </div>
                  <div className="text-sm text-slate-600">Plano Empresarial</div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-slate-900">€50,00</div>
                  <Badge className="bg-green-100 text-green-700 border-green-200 mt-1">
                    Pago
                  </Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Danger Zone */}
        <Card className="border-2 border-red-200">
          <CardHeader>
            <CardTitle className="text-red-900">Zona de Perigo</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-slate-600 mb-4">
              Ao cancelar a subscrição, perderá acesso a todas as funcionalidades empresariais 
              no final do período atual ({nextBillingDate}).
            </p>
            <Button
              onClick={() => {
                if (confirm('Tem a certeza que deseja cancelar a subscrição?')) {
                  cancelMutation.mutate();
                }
              }}
              disabled={cancelMutation.isPending || !subscription.auto_renew}
              variant="destructive"
            >
              {subscription.auto_renew ? 'Cancelar Subscrição' : 'Subscrição Cancelada'}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}