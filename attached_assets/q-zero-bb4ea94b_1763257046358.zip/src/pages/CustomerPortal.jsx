import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Ticket, Calendar, Bell } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import TicketHistory from "../components/portal/TicketHistory";
import AppointmentHistory from "../components/portal/AppointmentHistory";
import NotificationSettings from "../components/portal/NotificationSettings";

export default function CustomerPortalPage() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {
      base44.auth.redirectToLogin();
    });
  }, []);

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 flex items-center justify-center p-6">
        <div className="max-w-6xl mx-auto w-full">
          <Skeleton className="h-32 w-full mb-8 rounded-2xl" />
          <Skeleton className="h-96 w-full rounded-2xl" />
        </div>
      </div>
    );
  }

  const displayName = user?.nome_completo || user?.full_name || 'Utilizador';

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50">
      <div className="max-w-7xl mx-auto px-3 md:px-6 py-8 md:py-12">
        <div className="text-center mb-8 md:mb-12">
          <Badge className="bg-gradient-to-r from-sky-600 to-blue-600 text-white mb-3 md:mb-4 text-xs">
            <Ticket className="w-3 h-3 mr-1" />
            Portal do Cliente
          </Badge>
          <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold text-slate-900 mb-3 md:mb-4">
            Bem-vindo,
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-sky-600 to-blue-600">
              {displayName}
            </span>
          </h1>
          <p className="text-sm md:text-xl text-slate-600 max-w-2xl mx-auto">
            Gerir senhas, marcações e notificações
          </p>
        </div>

        <Card className="border-0 shadow-2xl">
          <div className="h-2 bg-gradient-to-r from-sky-500 to-blue-600" />
          <CardContent className="p-4 md:p-8">
            <Tabs defaultValue="tickets" className="space-y-4 md:space-y-6">
              <TabsList className="bg-slate-100 border-0 w-full grid grid-cols-3 p-1">
                <TabsTrigger value="tickets" className="gap-2 data-[state=active]:bg-white data-[state=active]:shadow-sm">
                  <Ticket className="w-4 h-4" />
                  <span className="hidden sm:inline">Senhas</span>
                </TabsTrigger>
                <TabsTrigger value="appointments" className="gap-2 data-[state=active]:bg-white data-[state=active]:shadow-sm">
                  <Calendar className="w-4 h-4" />
                  <span className="hidden sm:inline">Marcações</span>
                </TabsTrigger>
                <TabsTrigger value="settings" className="gap-2 data-[state=active]:bg-white data-[state=active]:shadow-sm">
                  <Bell className="w-4 h-4" />
                  <span className="hidden sm:inline">Notificações</span>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="tickets">
                <TicketHistory user={user} />
              </TabsContent>

              <TabsContent value="appointments">
                <AppointmentHistory user={user} />
              </TabsContent>

              <TabsContent value="settings">
                <NotificationSettings user={user} />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}