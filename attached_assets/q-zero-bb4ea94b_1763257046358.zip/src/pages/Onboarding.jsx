import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Building2, User, Check, ArrowRight, Sparkles, UserCircle } from "lucide-react";
import { useTranslation } from "@/components/i18n/LanguageContext";
import PhoneInput from "../components/shared/PhoneInput";

export default function OnboardingPage() {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [user, setUser] = useState(null);
  const [step, setStep] = useState('profile');
  const [selectedMode, setSelectedMode] = useState(null);
  const [profileData, setProfileData] = useState({
    full_name: '',
    phone: '',
    nif: '',
    data_nascimento: ''
  });

  useEffect(() => {
    base44.auth.me().then(userData => {
      setUser(userData);
      if (userData.onboarding_completed) {
        navigate(createPageUrl("Home"));
      }
      if (userData.profile_completed) {
        setStep('account_type');
      }
      setProfileData({
        full_name: userData.full_name || '',
        phone: userData.phone || '',
        nif: userData.nif || '',
        data_nascimento: userData.data_nascimento || ''
      });
    }).catch(() => {
      base44.auth.redirectToLogin();
    });
  }, [navigate]);

  const profileMutation = useMutation({
    mutationFn: async (data) => {
      await base44.auth.updateMe({
        ...data,
        profile_completed: true
      });
    },
    onSuccess: () => {
      setStep('account_type');
    },
  });

  const completeMutation = useMutation({
    mutationFn: async (mode) => {
      const updates = {
        onboarding_completed: true,
        account_type: mode
      };

      if (mode === 'empresa' || mode === 'ambos') {
        updates.is_business_user = true;
      }

      await base44.auth.updateMe(updates);
      return mode;
    },
    onSuccess: (mode) => {
      if (mode === 'empresa' || mode === 'ambos') {
        navigate(createPageUrl("BusinessSubscription"));
      } else {
        navigate(createPageUrl("Home"));
      }
    },
  });

  const handleProfileSubmit = (e) => {
    e.preventDefault();
    if (!profileData.full_name || !profileData.phone || !profileData.nif || !profileData.data_nascimento) {
      alert('Por favor preencha todos os campos');
      return;
    }
    profileMutation.mutate(profileData);
  };

  const handleContinue = () => {
    if (selectedMode) {
      completeMutation.mutate(selectedMode);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 flex items-center justify-center">
        <div className="animate-pulse text-slate-600">{t('loading')}</div>
      </div>
    );
  }

  if (step === 'profile') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50">
        <div className="max-w-2xl mx-auto px-6 py-12">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-sky-500 to-blue-600 rounded-2xl mb-6">
              <UserCircle className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4">
              Complete o Seu Perfil
            </h1>
            <p className="text-xl text-slate-600">
              Olá, <span className="font-semibold text-slate-900">{user.email}</span>! Precisamos de algumas informações para começar.
            </p>
          </div>

          <Card className="border-0 shadow-2xl">
            <CardContent className="p-8">
              <form onSubmit={handleProfileSubmit} className="space-y-6">
                <div>
                  <Label htmlFor="full_name">Nome Completo *</Label>
                  <Input
                    id="full_name"
                    value={profileData.full_name}
                    onChange={(e) => setProfileData({...profileData, full_name: e.target.value})}
                    placeholder="João Silva"
                    className="mt-2"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="nif">NIF (Número de Identificação Fiscal) *</Label>
                  <Input
                    id="nif"
                    value={profileData.nif}
                    onChange={(e) => setProfileData({...profileData, nif: e.target.value})}
                    placeholder="123456789"
                    className="mt-2"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="data_nascimento">Data de Nascimento *</Label>
                  <Input
                    id="data_nascimento"
                    type="date"
                    value={profileData.data_nascimento}
                    onChange={(e) => setProfileData({...profileData, data_nascimento: e.target.value})}
                    className="mt-2"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="phone">Número de Telemóvel *</Label>
                  <PhoneInput
                    value={profileData.phone}
                    onChange={(value) => setProfileData({...profileData, phone: value})}
                    required
                    className="mt-2"
                  />
                </div>

                <Button
                  type="submit"
                  size="lg"
                  disabled={profileMutation.isPending}
                  className="w-full bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 py-6 text-lg"
                >
                  {profileMutation.isPending ? (
                    'A guardar...'
                  ) : (
                    <>
                      Guardar e Continuar
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          <p className="text-sm text-slate-500 mt-6 text-center">
            * Campos obrigatórios
          </p>
        </div>
      </div>
    );
  }

  const modes = [
    {
      id: 'pessoal',
      title: t('personal'),
      description: 'Retire senhas digitais, acompanhe filas e evite esperas',
      icon: User,
      color: 'from-blue-500 to-cyan-500',
      features: [
        'Retirar senhas remotamente',
        'Notificações em tempo real',
        'Histórico de atendimentos',
        'Acesso a todas as empresas'
      ]
    },
    {
      id: 'empresa',
      title: t('business'),
      description: 'Gerir filas, atendimentos e estatísticas da sua empresa',
      icon: Building2,
      color: 'from-indigo-500 to-purple-500',
      features: [
        'Painel de gestão completo',
        'Estatísticas e analytics',
        'Gestão de múltiplas filas',
        'Relatórios exportáveis'
      ]
    },
    {
      id: 'ambos',
      title: 'Conta Híbrida',
      description: 'Acesso completo aos dois painéis na mesma conta',
      icon: Sparkles,
      color: 'from-amber-500 to-orange-500',
      features: [
        'Painel pessoal + empresarial',
        'Alternar entre modos',
        'Funcionalidades completas',
        'Máxima flexibilidade'
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-sky-500 to-blue-600 rounded-2xl mb-6">
            <Sparkles className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4">
            Bem-vindo ao QZero! 👋
          </h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            Como deseja utilizar a plataforma, <span className="font-semibold text-slate-900">{user.full_name || user.email}</span>?
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {modes.map((mode) => {
            const Icon = mode.icon;
            const isSelected = selectedMode === mode.id;
            
            return (
              <Card 
                key={mode.id}
                className={`cursor-pointer transition-all duration-300 border-2 ${
                  isSelected 
                    ? 'border-sky-500 shadow-2xl scale-105' 
                    : 'border-slate-200 hover:border-slate-300 hover:shadow-lg'
                }`}
                onClick={() => setSelectedMode(mode.id)}
              >
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${mode.color} flex items-center justify-center`}>
                      <Icon className="w-7 h-7 text-white" />
                    </div>
                    {isSelected && (
                      <div className="w-6 h-6 bg-sky-500 rounded-full flex items-center justify-center">
                        <Check className="w-4 h-4 text-white" />
                      </div>
                    )}
                  </div>

                  <h3 className="text-xl font-bold text-slate-900 mb-2">
                    {mode.title}
                  </h3>
                  <p className="text-sm text-slate-600 mb-4 leading-relaxed">
                    {mode.description}
                  </p>

                  <div className="space-y-2">
                    {mode.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-sm text-slate-700">
                        <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>

                  <Button
                    className={`w-full mt-6 ${
                      isSelected
                        ? 'bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                    onClick={() => setSelectedMode(mode.id)}
                  >
                    {isSelected ? 'Selecionado' : 'Selecionar'}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="text-center">
          <Button
            size="lg"
            disabled={!selectedMode || completeMutation.isPending}
            className="bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 px-12 py-6 text-lg disabled:opacity-50"
            onClick={handleContinue}
          >
            {completeMutation.isPending ? (
              'A configurar...'
            ) : (
              <>
                Continuar
                <ArrowRight className="w-5 h-5 ml-2" />
              </>
            )}
          </Button>
          <p className="text-sm text-slate-500 mt-4">
            Pode alterar esta configuração a qualquer momento nas definições
          </p>
        </div>

        {selectedMode === 'ambos' && (
          <div className="mt-8 max-w-2xl mx-auto p-6 bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-xl">
            <div className="flex items-start gap-3">
              <Sparkles className="w-6 h-6 text-amber-600 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-bold text-amber-900 mb-1">Conta Híbrida</h4>
                <p className="text-sm text-amber-800 leading-relaxed">
                  Com a conta híbrida, terá acesso ao menu lateral com opção para alternar entre o painel pessoal 
                  e o painel empresarial. Máxima flexibilidade para gerir o seu dia a dia e a sua empresa.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}