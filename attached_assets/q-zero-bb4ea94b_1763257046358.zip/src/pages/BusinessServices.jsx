import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Edit, Trash2, Calendar, X, Crown } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import PageHeader from "../components/shared/PageHeader";
import EmptyState from "../components/shared/EmptyState";

const diasSemana = [
  { id: 1, nome: 'Segunda' },
  { id: 2, nome: 'Terça' },
  { id: 3, nome: 'Quarta' },
  { id: 4, nome: 'Quinta' },
  { id: 5, nome: 'Sexta' },
  { id: 6, nome: 'Sábado' },
  { id: 0, nome: 'Domingo' }
];

export default function BusinessServicesPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [editingService, setEditingService] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    duration: 30,
    price: 0,
    category: '',
    available_days: [1, 2, 3, 4, 5],
    start_time: '09:00',
    end_time: '18:00',
  });

  useEffect(() => {
    base44.auth.me().then(userData => {
      setUser(userData);
      if (!userData.is_business_user || !userData.business_id) {
        navigate(createPageUrl("Home"));
      }
    }).catch(() => base44.auth.redirectToLogin());
  }, [navigate]);

  const { data: subscription } = useQuery({
    queryKey: ['business-subscription', user?.email],
    queryFn: async () => {
      if (!user) return null;
      const subs = await base44.entities.Subscription.filter({
        user_email: user.email,
        plan: "business"
      });
      const activeSub = subs.find(s => s.status === 'active' || s.status === 'trialing');
      return activeSub || null;
    },
    enabled: !!user,
  });

  const { data: services, isLoading } = useQuery({
    queryKey: ['business-services', user?.business_id],
    queryFn: () => base44.entities.Service.filter({ business_id: user.business_id }),
    initialData: [],
    enabled: !!user?.business_id,
  });

  const createServiceMutation = useMutation({
    mutationFn: (data) => base44.entities.Service.create({ ...data, business_id: user.business_id }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['business-services'] });
      setShowForm(false);
      setFormData({ 
        name: '', 
        description: '', 
        duration: 30, 
        price: 0, 
        category: '',
        available_days: [1, 2, 3, 4, 5],
        start_time: '09:00',
        end_time: '18:00',
      });
    },
  });

  const updateServiceMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Service.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['business-services'] });
      setShowForm(false);
      setEditingService(null);
      setFormData({ 
        name: '', 
        description: '', 
        duration: 30, 
        price: 0, 
        category: '',
        available_days: [1, 2, 3, 4, 5],
        start_time: '09:00',
        end_time: '18:00',
      });
    },
  });

  const deleteServiceMutation = useMutation({
    mutationFn: (serviceId) => base44.entities.Service.delete(serviceId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['business-services'] });
    },
  });

  const handleEdit = (service) => {
    if (!subscription) return;
    setEditingService(service);
    setFormData({
      name: service.name,
      description: service.description || '',
      duration: service.duration,
      price: service.price || 0,
      category: service.category || '',
      available_days: service.available_days || [1, 2, 3, 4, 5],
      start_time: service.start_time || '09:00',
      end_time: service.end_time || '18:00',
    });
    setShowForm(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!subscription) return;
    if (editingService) {
      updateServiceMutation.mutate({ id: editingService.id, data: formData });
    } else {
      createServiceMutation.mutate(formData);
    }
  };

  const handleCancel = () => {
    setShowForm(false);
    setEditingService(null);
    setFormData({ 
      name: '', 
      description: '', 
      duration: 30, 
      price: 0, 
      category: '',
      available_days: [1, 2, 3, 4, 5],
      start_time: '09:00',
      end_time: '18:00',
    });
  };

  const handleDelete = (serviceId) => {
    if (!subscription) return;
    if (confirm('Tem certeza que deseja eliminar este serviço?')) {
      deleteServiceMutation.mutate(serviceId);
    }
  };

  const toggleDay = (dayId) => {
    const currentDays = formData.available_days || [];
    if (currentDays.includes(dayId)) {
      setFormData({ ...formData, available_days: currentDays.filter(d => d !== dayId) });
    } else {
      setFormData({ ...formData, available_days: [...currentDays, dayId] });
    }
  };

  if (!user || isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 p-6">
        <div className="max-w-6xl mx-auto">
          <Skeleton className="h-16 w-64 mb-8" />
          <Skeleton className="h-96 w-full" />
        </div>
      </div>
    );
  }

  if (!subscription) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50">
        <div className="max-w-4xl mx-auto px-6 py-12">
          <Card className="border-0 shadow-2xl">
            <CardContent className="p-12 text-center">
              <Crown className="w-16 h-16 text-amber-600 mx-auto mb-6" />
              <h2 className="text-3xl font-bold text-slate-900 mb-4">
                Subscrição Necessária
              </h2>
              <p className="text-lg text-slate-600 mb-8">
                Para criar e gerir serviços, precisa de ativar o plano empresarial.
              </p>
              <Link to={createPageUrl("BusinessSubscription")}>
                <Button size="lg" className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700">
                  <Crown className="w-5 h-5 mr-2" />
                  Ativar Plano Empresarial - €49,99/mês
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50">
      <div className="max-w-6xl mx-auto px-6 py-8">
        <PageHeader
          title="Gestão de Serviços"
          subtitle="Crie e gerir os serviços oferecidos"
          backTo="BusinessDashboard"
          actions={
            <Button onClick={() => { setEditingService(null); setShowForm(true); }} className="gap-2">
              <Plus className="w-4 h-4" />
              Novo Serviço
            </Button>
          }
        />

        {showForm && (
          <Card className="border-0 shadow-xl mb-8">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>{editingService ? 'Editar Serviço' : 'Novo Serviço'}</CardTitle>
                <Button variant="ghost" size="icon" onClick={handleCancel}>
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Nome do Serviço *</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      required
                      placeholder="Ex: Consulta Médica"
                    />
                  </div>
                  <div>
                    <Label htmlFor="category">Categoria</Label>
                    <Input
                      id="category"
                      value={formData.category}
                      onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                      placeholder="Ex: Consultas"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="description">Descrição</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Descreva o serviço..."
                    rows={3}
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="duration">Duração (minutos) *</Label>
                    <Input
                      id="duration"
                      type="number"
                      value={formData.duration}
                      onChange={(e) => setFormData({ ...formData, duration: parseInt(e.target.value) })}
                      required
                      min="5"
                    />
                  </div>
                  <div>
                    <Label htmlFor="price">Preço (€)</Label>
                    <Input
                      id="price"
                      type="number"
                      step="0.01"
                      value={formData.price}
                      onChange={(e) => setFormData({ ...formData, price: parseFloat(e.target.value) })}
                      min="0"
                    />
                  </div>
                </div>

                <div className="border-t pt-6">
                  <Label className="text-base font-semibold mb-4 block">Dias Disponíveis</Label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {diasSemana.map((dia) => (
                      <div key={dia.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={`dia-${dia.id}`}
                          checked={(formData.available_days || []).includes(dia.id)}
                          onCheckedChange={() => toggleDay(dia.id)}
                        />
                        <label
                          htmlFor={`dia-${dia.id}`}
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                        >
                          {dia.nome}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="border-t pt-6">
                  <Label className="text-base font-semibold mb-4 block">Horário de Funcionamento</Label>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="start_time">Hora de Início</Label>
                      <Input
                        id="start_time"
                        type="time"
                        value={formData.start_time}
                        onChange={(e) => setFormData({ ...formData, start_time: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="end_time">Hora de Fim</Label>
                      <Input
                        id="end_time"
                        type="time"
                        value={formData.end_time}
                        onChange={(e) => setFormData({ ...formData, end_time: e.target.value })}
                      />
                    </div>
                  </div>
                </div>

                <div className="flex gap-3 justify-end pt-4">
                  <Button type="button" variant="outline" onClick={handleCancel}>
                    Cancelar
                  </Button>
                  <Button type="submit" disabled={createServiceMutation.isPending || updateServiceMutation.isPending}>
                    {editingService ? 'Atualizar' : 'Criar'} Serviço
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {!showForm && services.length === 0 ? (
          <EmptyState
            icon={Calendar}
            title="Nenhum serviço criado"
            description="Crie seu primeiro serviço para oferecer aos clientes"
            action={{
              label: "Criar Primeiro Serviço",
              onClick: () => setShowForm(true)
            }}
          />
        ) : !showForm && (
          <div className="grid md:grid-cols-2 gap-6">
            {services.map(service => (
              <Card key={service.id} className="border-0 shadow-lg hover:shadow-xl transition-all">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="font-bold text-xl text-slate-900 mb-1">{service.name}</h3>
                      {service.description && (
                        <p className="text-sm text-slate-600">{service.description}</p>
                      )}
                    </div>
                    {service.price && service.price > 0 && (
                      <Badge className="bg-sky-100 text-sky-700 border-sky-200 text-lg">
                        €{service.price.toFixed(2)}
                      </Badge>
                    )}
                  </div>

                  <div className="flex items-center gap-4 mb-3">
                    <div className="flex items-center gap-2 text-slate-600">
                      <Calendar className="w-4 h-4" />
                      <span className="text-sm">{service.duration} min</span>
                    </div>
                    {service.category && (
                      <Badge variant="secondary">{service.category}</Badge>
                    )}
                  </div>

                  {service.available_days && service.available_days.length > 0 && (
                    <div className="mb-4 pb-4 border-b">
                      <p className="text-xs text-slate-500 mb-2">Dias disponíveis:</p>
                      <div className="flex flex-wrap gap-1">
                        {service.available_days.map(dayId => {
                          const dia = diasSemana.find(d => d.id === dayId);
                          return dia ? (
                            <Badge key={dayId} variant="outline" className="text-xs">
                              {dia.nome}
                            </Badge>
                          ) : null;
                        })}
                      </div>
                    </div>
                  )}

                  {(service.start_time || service.end_time) && (
                    <div className="mb-4 text-sm text-slate-600">
                      <p className="text-xs text-slate-500">Horário:</p>
                      <p>{service.start_time || '—'} às {service.end_time || '—'}</p>
                    </div>
                  )}

                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => handleEdit(service)}
                    >
                      <Edit className="w-4 h-4 mr-2" />
                      Editar
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-red-200 text-red-600 hover:bg-red-50"
                      onClick={() => handleDelete(service.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}