import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Clock, CheckCircle2, XCircle, AlertCircle, Ticket as TicketIcon } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

const statusConfig = {
  aguardando: { 
    icon: Clock, 
    color: "bg-blue-100 text-blue-700 border-blue-200",
    label: "Aguardando"
  },
  chamado: { 
    icon: AlertCircle, 
    color: "bg-amber-100 text-amber-700 border-amber-200",
    label: "Chamado"
  },
  atendendo: { 
    icon: Clock, 
    color: "bg-purple-100 text-purple-700 border-purple-200",
    label: "Atendendo"
  },
  concluido: { 
    icon: CheckCircle2, 
    color: "bg-green-100 text-green-700 border-green-200",
    label: "Concluído"
  },
  cancelado: { 
    icon: XCircle, 
    color: "bg-red-100 text-red-700 border-red-200",
    label: "Cancelado"
  }
};

export default function MyTicketsPage() {
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState("ativas");
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => base44.auth.redirectToLogin());
  }, []);

  const { data: tickets, isLoading } = useQuery({
    queryKey: ['my-tickets', user?.email],
    queryFn: () => user ? base44.entities.Ticket.filter({ user_email: user.email }, '-created_date') : [],
    enabled: !!user,
    initialData: [],
    refetchInterval: 5000,
  });

  const { data: businesses } = useQuery({
    queryKey: ['businesses-for-tickets'],
    queryFn: () => base44.entities.Business.list(),
    initialData: [],
  });

  const { data: queues } = useQuery({
    queryKey: ['queues-for-tickets'],
    queryFn: () => base44.entities.Queue.list(),
    initialData: [],
  });

  const expireTicketsMutation = useMutation({
    mutationFn: async (ticketIds) => {
      for (const ticketId of ticketIds) {
        await base44.entities.Ticket.update(ticketId, {
          status: 'cancelado',
          completed_at: new Date().toISOString()
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['my-tickets'] });
    }
  });

  useEffect(() => {
    if (!tickets.length || !queues.length) return;

    const checkExpiredTickets = async () => {
      const now = new Date();
      const expiredTicketIds = [];

      for (const ticket of tickets) {
        if (!['aguardando', 'chamado'].includes(ticket.status)) continue;

        const queue = queues.find(q => q.id === ticket.queue_id);
        if (!queue) continue;

        if (ticket.status === 'chamado' && ticket.called_at) {
          const calledAt = new Date(ticket.called_at);
          const toleranceMs = (queue.tolerance_time || 15) * 60 * 1000;
          if (now - calledAt > toleranceMs) {
            expiredTicketIds.push(ticket.id);
          }
        }

        if (ticket.status === 'aguardando') {
          const currentNumber = queue.current_number;
          if (ticket.ticket_number < currentNumber) {
            expiredTicketIds.push(ticket.id);
          }
        }
      }

      if (expiredTicketIds.length > 0) {
        expireTicketsMutation.mutate(expiredTicketIds);
      }
    };

    checkExpiredTickets();
    const interval = setInterval(checkExpiredTickets, 5000);

    return () => clearInterval(interval);
  }, [tickets, queues, expireTicketsMutation]);

  const activeTickets = tickets.filter(t => ['aguardando', 'chamado', 'atendendo'].includes(t.status));
  const historicTickets = tickets.filter(t => ['concluido', 'cancelado'].includes(t.status));

  const getBusinessName = (businessId) => {
    const business = businesses.find(b => b.id === businessId);
    return business?.name || 'Empresa';
  };

  const getQueueName = (queueId) => {
    const queue = queues.find(q => q.id === queueId);
    return queue?.name || 'Fila';
  };

  const TicketCard = ({ ticket }) => {
    const status = statusConfig[ticket.status];
    const StatusIcon = status.icon;

    return (
      <Link to={createPageUrl(`TicketView?id=${ticket.id}`)}>
        <Card className="hover:shadow-xl transition-all duration-300 border-0 cursor-pointer">
          <CardContent className="p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="font-bold text-2xl text-slate-900 mb-1">
                  Senha #{ticket.ticket_number}
                </h3>
                <p className="text-slate-600 font-medium">{getBusinessName(ticket.business_id)}</p>
                <p className="text-sm text-slate-500">{getQueueName(ticket.queue_id)}</p>
              </div>
              <Badge className={status.color}>
                <StatusIcon className="w-3 h-3 mr-1" />
                {status.label}
              </Badge>
            </div>

            {ticket.status === 'aguardando' && (
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="p-3 bg-blue-50 rounded-lg">
                  <div className="text-xs text-slate-600 mb-1">Posição</div>
                  <div className="text-2xl font-bold text-blue-600">#{ticket.position || '...'}</div>
                </div>
                <div className="p-3 bg-purple-50 rounded-lg">
                  <div className="text-xs text-slate-600 mb-1">Tempo Estimado</div>
                  <div className="text-2xl font-bold text-purple-600">~{ticket.estimated_time || '...'}min</div>
                </div>
              </div>
            )}

            <div className="text-xs text-slate-500">
              Criado em {new Date(ticket.created_date).toLocaleDateString('pt-PT')} às {new Date(ticket.created_date).toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' })}
            </div>
          </CardContent>
        </Card>
      </Link>
    );
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 flex items-center justify-center">
        <Card className="p-8 text-center">
          <Skeleton className="h-12 w-48 mx-auto mb-4" />
          <Skeleton className="h-4 w-64 mx-auto" />
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50">
      <div className="max-w-6xl mx-auto px-6 py-8">
        <div className="mb-8">
          <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-3">
            Minhas Senhas
          </h1>
          <p className="text-xl text-slate-600">
            Acompanhe todas as suas senhas em tempo real
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
          <TabsList className="bg-white border border-slate-200 p-1">
            <TabsTrigger 
              value="ativas"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-sky-500 data-[state=active]:to-blue-600 data-[state=active]:text-white"
            >
              <Clock className="w-4 h-4 mr-2" />
              Ativas ({activeTickets.length})
            </TabsTrigger>
            <TabsTrigger 
              value="historico"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-sky-500 data-[state=active]:to-blue-600 data-[state=active]:text-white"
            >
              <TicketIcon className="w-4 h-4 mr-2" />
              Histórico ({historicTickets.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="ativas" className="mt-6">
            {isLoading ? (
              <div className="grid md:grid-cols-2 gap-6">
                {[1, 2].map(i => (
                  <Skeleton key={i} className="h-48 w-full rounded-xl" />
                ))}
              </div>
            ) : activeTickets.length === 0 ? (
              <Card className="border-0 shadow-lg">
                <CardContent className="py-16 text-center">
                  <div className="text-6xl mb-4">🎫</div>
                  <h3 className="text-2xl font-bold text-slate-900 mb-2">Nenhuma senha ativa</h3>
                  <p className="text-slate-600 mb-6">Você não possui senhas aguardando atendimento</p>
                  <Link to={createPageUrl("Businesses")}>
                    <button className="px-6 py-3 bg-gradient-to-r from-sky-500 to-blue-600 text-white rounded-xl hover:from-sky-600 hover:to-blue-700">
                      Retirar Nova Senha
                    </button>
                  </Link>
                </CardContent>
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 gap-6">
                {activeTickets.map(ticket => (
                  <TicketCard key={ticket.id} ticket={ticket} />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="historico" className="mt-6">
            {isLoading ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3, 4, 5, 6].map(i => (
                  <Skeleton key={i} className="h-40 w-full rounded-xl" />
                ))}
              </div>
            ) : historicTickets.length === 0 ? (
              <Card className="border-0 shadow-lg">
                <CardContent className="py-16 text-center">
                  <div className="text-6xl mb-4">📋</div>
                  <h3 className="text-2xl font-bold text-slate-900 mb-2">Sem histórico</h3>
                  <p className="text-slate-600">Você ainda não possui senhas concluídas</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {historicTickets.map(ticket => (
                  <TicketCard key={ticket.id} ticket={ticket} />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}