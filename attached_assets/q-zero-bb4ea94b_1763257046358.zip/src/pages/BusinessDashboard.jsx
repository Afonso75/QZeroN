import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  LayoutDashboard,
  Clock,
  Users,
  Settings,
  BarChart3,
  CheckCircle2,
  Crown,
  CreditCard,
  MessageSquare,
  ChevronRight
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import QueueManager from "../components/business/QueueManager";
import Statistics from "../components/business/Statistics";
import AppointmentManager from "../components/business/AppointmentManager";
import AppointmentReminders from "../components/business/AppointmentReminders";
import FeedbackManager from "../components/business/FeedbackManager";

export default function BusinessDashboardPage() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState("senhas");

  useEffect(() => {
    base44.auth.me().then(userData => {
      setUser(userData);
      console.log('User loaded:', {
        email: userData.email,
        is_business_user: userData.is_business_user,
        has_business_subscription: userData.has_business_subscription,
        business_id: userData.business_id
      });
      
      if (!userData.is_business_user || !userData.business_id) {
        navigate(createPageUrl("Home"));
      }
    }).catch(() => {
      base44.auth.redirectToLogin();
    });
  }, [navigate]);

  const { data: subscription, isLoading: loadingSubscription } = useQuery({
    queryKey: ['business-subscription', user?.email],
    queryFn: async () => {
      if (!user) return null;
      const subs = await base44.entities.Subscription.filter({
        user_email: user.email,
        plan: "business"
      });
      console.log('Subscriptions found:', subs);
      const activeSub = subs.find(s => s.status === 'active' || s.status === 'trialing');
      return activeSub || null;
    },
    enabled: !!user,
    staleTime: 0, // Sempre fazer fetch fresh
    refetchOnMount: 'always'
  });

  const { data: business, isLoading: loadingBusiness } = useQuery({
    queryKey: ['business', user?.business_id],
    queryFn: async () => {
      const businesses = await base44.entities.Business.filter({ id: user.business_id });
      return businesses[0];
    },
    enabled: !!user?.business_id,
  });

  const { data: queues } = useQuery({
    queryKey: ['business-queues', user?.business_id],
    queryFn: () => base44.entities.Queue.filter({ business_id: user.business_id }),
    initialData: [],
    enabled: !!user?.business_id,
    refetchInterval: 10000,
  });

  const { data: tickets } = useQuery({
    queryKey: ['business-tickets', user?.business_id],
    queryFn: () => base44.entities.Ticket.filter({ business_id: user.business_id }, '-created_date'),
    initialData: [],
    enabled: !!user?.business_id,
    refetchInterval: 5000,
  });

  if (!user || loadingBusiness || loadingSubscription) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 p-2">
        <div className="max-w-full mx-auto px-1.5">
          <Skeleton className="h-10 w-40 mb-3" />
          <div className="grid grid-cols-2 gap-2 mb-3">
            {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-20" />)}
          </div>
        </div>
      </div>
    );
  }

  // Verificar subscrição: user tem flag OU existe subscription ativa
  const hasSubscription = user.has_business_subscription || !!subscription;
  const isTrialing = subscription?.status === 'trialing';
  
  console.log('Subscription check:', {
    hasSubscription,
    user_flag: user.has_business_subscription,
    subscription_exists: !!subscription,
    subscription_status: subscription?.status
  });

  const activeQueues = queues.filter(q => q.is_active && q.status === "aberta");
  const todayTickets = tickets.filter(t => {
    const created = new Date(t.created_date);
    const today = new Date();
    return created.toDateString() === today.toDateString();
  });
  const activeTickets = tickets.filter(t => ['aguardando', 'chamado', 'atendendo'].includes(t.status));
  const todayCompleted = todayTickets.filter(t => t.status === "concluido");

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 w-full overflow-x-hidden animate-fade-in">
      {user?.business_id && <AppointmentReminders businessId={user.business_id} />}
      
      <div className="w-full max-w-full px-1.5 py-1.5">
        <div className="mb-2 animate-slide-in-down">
          <h1 className="text-base font-bold text-slate-900 mb-0.5">
            Painel Empresa
          </h1>
          <p className="text-xs text-slate-600 truncate">
            {business?.name || 'Sua Empresa'}
          </p>
        </div>

        {isTrialing && subscription?.trial_end_date && (
          <Card className="border-0 shadow-md bg-gradient-to-r from-amber-50 to-orange-50 border-l-4 border-amber-500 mb-2 animate-slide-in-left">
            <CardContent className="p-3">
              <div className="flex items-start gap-2">
                <Crown className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5 animate-pulse-slow" />
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-sm text-slate-900 mb-1">Período de Teste Ativo</h3>
                  <p className="text-xs text-slate-600">
                    Teste grátis até {new Date(subscription.trial_end_date).toLocaleDateString('pt-PT')}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
        
        <div className="flex gap-1.5 mb-2 -mx-1.5 px-1.5 overflow-x-auto pb-1 hide-scrollbar animate-slide-in-right">
          {hasSubscription ? (
            <Link to={createPageUrl("BusinessManageSubscription")}>
              <Button size="sm" variant="outline" className="gap-1 text-xs h-7 whitespace-nowrap px-2 smooth-transition hover-lift">
                <CreditCard className="w-3 h-3" />
                Subscrição
              </Button>
            </Link>
          ) : (
            <Link to={createPageUrl("BusinessSubscription")}>
              <Button size="sm" className="gap-1 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-xs h-7 whitespace-nowrap px-2 smooth-transition hover-lift">
                <Crown className="w-3 h-3" />
                Ativar Pro
              </Button>
            </Link>
          )}
          <Link to={createPageUrl("BusinessSettings")}>
            <Button size="sm" variant="outline" className="gap-1 text-xs h-7 whitespace-nowrap px-2 smooth-transition hover-lift">
              <Settings className="w-3 h-3" />
              Config
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-2 gap-1.5 mb-2 w-full max-w-full">
          {[
            { icon: LayoutDashboard, value: hasSubscription ? activeQueues.length : '—', label: 'Senhas', badge: 'Ativas', color: 'from-green-500 to-emerald-500', badgeColor: 'bg-green-100 text-green-700 border-green-200' },
            { icon: Users, value: hasSubscription ? activeTickets.length : '—', label: 'Pessoas', badge: 'Ativas', color: 'from-blue-500 to-cyan-500', badgeColor: 'bg-blue-100 text-blue-700 border-blue-200' },
            { icon: Clock, value: hasSubscription ? todayTickets.length : '—', label: 'Emitidas', badge: 'Hoje', color: 'from-purple-500 to-pink-500', badgeColor: 'bg-purple-100 text-purple-700 border-purple-200' },
            { icon: CheckCircle2, value: hasSubscription ? todayCompleted.length : '—', label: 'Concluídas', badge: 'Hoje', color: 'from-amber-500 to-orange-500', badgeColor: 'bg-amber-100 text-amber-700 border-amber-200' }
          ].map((stat, idx) => (
            <Card key={idx} className="border-0 shadow-sm hover-lift stagger-item" style={{ animationDelay: `${idx * 0.05}s` }}>
              <CardContent className="p-2">
                <div className="flex justify-between items-start mb-1">
                  <div className={`w-7 h-7 rounded-lg bg-gradient-to-br ${stat.color} flex items-center justify-center flex-shrink-0`}>
                    <stat.icon className="w-3.5 h-3.5 text-white" />
                  </div>
                  <Badge className={`${stat.badgeColor} text-xs px-1 py-0 h-4`}>
                    {stat.badge}
                  </Badge>
                </div>
                <div className="text-lg font-bold text-slate-900">
                  {stat.value}
                </div>
                <p className="text-slate-600 text-xs">{stat.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="space-y-1.5 w-full max-w-full">
          {[
            { id: 'senhas', icon: LayoutDashboard, title: 'Senhas', color: 'from-green-500 to-emerald-500' },
            { id: 'marcacoes', icon: Clock, title: 'Marcações', color: 'from-blue-500 to-cyan-500' },
            { id: 'feedback', icon: MessageSquare, title: 'Feedback', color: 'from-purple-500 to-pink-500' },
            { id: 'estatisticas', icon: BarChart3, title: 'Estatísticas', color: 'from-amber-500 to-orange-500' }
          ].map((tab, idx) => (
            <Card
              key={tab.id}
              className={`border-0 shadow-sm hover:shadow-md smooth-transition cursor-pointer group w-full max-w-full hover-lift stagger-item ${
                activeTab === tab.id ? 'ring-2 ring-sky-500' : ''
              }`}
              style={{ animationDelay: `${(idx + 4) * 0.05}s` }}
              onClick={() => setActiveTab(tab.id)}
            >
              <CardContent className="p-2 w-full max-w-full">
                <div className="flex items-center gap-2 w-full">
                  <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${tab.color} flex items-center justify-center flex-shrink-0 smooth-transition ${activeTab === tab.id ? 'scale-110' : 'group-hover:scale-105'}`}>
                    <tab.icon className="w-3.5 h-3.5 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-xs text-slate-900">
                      {tab.title}
                    </h3>
                  </div>
                  <ChevronRight className={`w-3.5 h-3.5 text-slate-400 group-hover:text-slate-600 smooth-transition flex-shrink-0 ${
                    activeTab === tab.id ? 'rotate-90' : ''
                  }`} />
                </div>
                
                {activeTab === tab.id && (
                  <div className="mt-2 pt-2 border-t w-full max-w-full overflow-hidden animate-slide-in-up">
                    {tab.id === 'senhas' && (
                      hasSubscription ? (
                        queues.length === 0 ? (
                          <p className="text-xs text-slate-600 text-center py-3">Nenhuma senha configurada</p>
                        ) : (
                          <div className="space-y-1.5 w-full">
                            {queues.map(queue => (
                              <QueueManager 
                                key={queue.id} 
                                queue={queue} 
                                tickets={tickets.filter(t => t.queue_id === queue.id)}
                              />
                            ))}
                          </div>
                        )
                      ) : (
                        <div className="text-center py-4">
                          <Crown className="w-8 h-8 text-amber-600 mx-auto mb-1.5 animate-pulse-slow" />
                          <p className="text-xs text-slate-600 mb-2">Subscrição necessária</p>
                          <Link to={createPageUrl("BusinessSubscription")}>
                            <Button size="sm" className="bg-gradient-to-r from-amber-500 to-orange-600 text-xs h-7 hover-lift">
                              Ver Planos
                            </Button>
                          </Link>
                        </div>
                      )
                    )}
                    
                    {tab.id === 'marcacoes' && (
                      hasSubscription ? (
                        <AppointmentManager businessId={user.business_id} />
                      ) : (
                        <div className="text-center py-4">
                          <Crown className="w-8 h-8 text-amber-600 mx-auto mb-1.5 animate-pulse-slow" />
                          <p className="text-xs text-slate-600 mb-2">Subscrição necessária</p>
                          <Link to={createPageUrl("BusinessSubscription")}>
                            <Button size="sm" className="bg-gradient-to-r from-amber-500 to-orange-600 text-xs h-7 hover-lift">
                              Ver Planos
                            </Button>
                          </Link>
                        </div>
                      )
                    )}
                    
                    {tab.id === 'feedback' && (
                      hasSubscription ? (
                        <FeedbackManager businessId={user.business_id} />
                      ) : (
                        <div className="text-center py-4">
                          <Crown className="w-8 h-8 text-amber-600 mx-auto mb-1.5 animate-pulse-slow" />
                          <p className="text-xs text-slate-600 mb-2">Subscrição necessária</p>
                          <Link to={createPageUrl("BusinessSubscription")}>
                            <Button size="sm" className="bg-gradient-to-r from-amber-500 to-orange-600 text-xs h-7 hover-lift">
                              Ver Planos
                            </Button>
                          </Link>
                        </div>
                      )
                    )}
                    
                    {tab.id === 'estatisticas' && (
                      hasSubscription ? (
                        <Statistics 
                          business={business}
                          queues={queues}
                          tickets={tickets}
                        />
                      ) : (
                        <div className="text-center py-4">
                          <Crown className="w-8 h-8 text-amber-600 mx-auto mb-1.5 animate-pulse-slow" />
                          <p className="text-xs text-slate-600 mb-2">Subscrição necessária</p>
                          <Link to={createPageUrl("BusinessSubscription")}>
                            <Button size="sm" className="bg-gradient-to-r from-amber-500 to-orange-600 text-xs h-7 hover-lift">
                              Ver Planos
                            </Button>
                          </Link>
                        </div>
                      )
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
      <style>{`
        .hide-scrollbar::-webkit-scrollbar {
          display: none;
        }
        .hide-scrollbar {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </div>
  );
}