import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle2, XCircle, Loader2, Building2 } from "lucide-react";

export default function StaffInviteAcceptPage() {
  const navigate = useNavigate();
  const urlParams = new URLSearchParams(window.location.search);
  const token = urlParams.get('token');
  const [user, setUser] = useState(null);
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {
      base44.auth.redirectToLogin(window.location.href);
    });
  }, []);

  const { data: invite, isLoading } = useQuery({
    queryKey: ['invite', token],
    queryFn: async () => {
      const invites = await base44.entities.StaffInvite.filter({ token: token });
      return invites[0];
    },
    enabled: !!token && !!user,
  });

  const { data: business } = useQuery({
    queryKey: ['business', invite?.business_id],
    queryFn: async () => {
      const businesses = await base44.entities.Business.filter({ id: invite.business_id });
      return businesses[0];
    },
    enabled: !!invite?.business_id,
  });

  const acceptInviteMutation = useMutation({
    mutationFn: async () => {
      setProcessing(true);

      await base44.auth.updateMe({
        is_staff_member: true,
        is_business_user: true,
        business_id: invite.business_id,
        staff_permissions: invite.permissions,
        account_type: user.account_type === 'empresa' ? 'ambos' : user.account_type
      });

      await base44.entities.StaffInvite.update(invite.id, {
        status: "aceite"
      });
    },
    onSuccess: () => {
      navigate(createPageUrl("BusinessDashboard"));
    },
  });

  const rejectInviteMutation = useMutation({
    mutationFn: async () => {
      await base44.entities.StaffInvite.update(invite.id, {
        status: "rejeitado"
      });
    },
    onSuccess: () => {
      navigate(createPageUrl("Home"));
    },
  });

  const permissionLabels = {
    manage_queues: "Gerir Senhas",
    manage_appointments: "Gerir Marcações",
    manage_services: "Gerir Serviços"
  };

  if (isLoading || !user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 flex items-center justify-center p-6">
        <Card className="border-0 shadow-2xl max-w-md w-full animate-scale-in">
          <CardContent className="p-12 text-center">
            <Loader2 className="w-12 h-12 animate-spin text-sky-600 mx-auto mb-4" />
            <p className="text-slate-600">A carregar convite...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!invite || invite.status !== 'pendente') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 flex items-center justify-center p-6">
        <Card className="border-0 shadow-2xl max-w-md w-full animate-scale-in">
          <CardContent className="p-12 text-center">
            <XCircle className="w-16 h-16 text-red-500 mx-auto mb-4 animate-pulse-slow" />
            <h2 className="text-2xl font-bold text-slate-900 mb-2">
              Convite Inválido
            </h2>
            <p className="text-slate-600 mb-6">
              Este convite não existe, já foi usado ou expirou.
            </p>
            <Button onClick={() => navigate(createPageUrl("Home"))} className="hover-lift">
              Voltar ao Início
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (invite.email !== user.email) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 flex items-center justify-center p-6">
        <Card className="border-0 shadow-2xl max-w-md w-full animate-scale-in">
          <CardContent className="p-12 text-center">
            <XCircle className="w-16 h-16 text-amber-500 mx-auto mb-4 animate-pulse-slow" />
            <h2 className="text-2xl font-bold text-slate-900 mb-2">
              Email Incorreto
            </h2>
            <p className="text-slate-600 mb-6">
              Este convite foi enviado para {invite.email}. 
              Por favor faça login com esse email.
            </p>
            <Button onClick={() => base44.auth.logout()} className="hover-lift">
              Trocar de Conta
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 flex items-center justify-center p-6">
      <Card className="border-0 shadow-2xl max-w-2xl w-full overflow-hidden animate-scale-in">
        <div className="h-2 bg-gradient-to-r from-sky-500 to-blue-600" />
        <CardContent className="p-8">
          <div className="text-center mb-8 animate-slide-in-down">
            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-sky-500 to-blue-600 flex items-center justify-center mx-auto mb-4 hover-lift">
              <Building2 className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2 gradient-text">
              Convite para Equipa
            </h1>
            <p className="text-lg text-slate-600">
              {business?.name || 'A carregar...'}
            </p>
          </div>

          <div className="bg-slate-50 rounded-xl p-6 mb-6 animate-slide-in-left">
            <h3 className="font-semibold text-slate-900 mb-4">
              Permissões Atribuídas:
            </h3>
            <div className="space-y-3">
              {Object.entries(invite.permissions || {}).map(([key, value], idx) => (
                <div 
                  key={key} 
                  className="flex items-center gap-3 stagger-item"
                  style={{ animationDelay: `${idx * 0.1}s` }}
                >
                  {value ? (
                    <>
                      <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
                      <span className="text-slate-700">{permissionLabels[key]}</span>
                    </>
                  ) : (
                    <>
                      <XCircle className="w-5 h-5 text-slate-300 flex-shrink-0" />
                      <span className="text-slate-400">{permissionLabels[key]}</span>
                    </>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="bg-blue-50 rounded-xl p-4 mb-6 border border-blue-200 animate-slide-in-right">
            <p className="text-sm text-slate-700">
              <strong>Nota:</strong> Ao aceitar, terá acesso ao painel empresarial de {business?.name} 
              com as permissões indicadas acima.
            </p>
          </div>

          <div className="flex gap-4 animate-slide-in-up">
            <Button
              variant="outline"
              className="flex-1 smooth-transition hover-lift"
              onClick={() => rejectInviteMutation.mutate()}
              disabled={processing || rejectInviteMutation.isPending}
            >
              Rejeitar
            </Button>
            <Button
              className="flex-1 bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 smooth-transition hover-lift"
              onClick={() => acceptInviteMutation.mutate()}
              disabled={processing || acceptInviteMutation.isPending}
            >
              {processing || acceptInviteMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  A aceitar...
                </>
              ) : (
                'Aceitar Convite'
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}