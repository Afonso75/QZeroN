import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Clock, 
  MapPin, 
  Users, 
  TrendingUp,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Phone,
  ArrowLeft,
  Star
} from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

const statusConfig = {
  aguardando: {
    icon: Clock,
    color: "bg-blue-100 text-blue-700 border-blue-200",
    label: "Aguardando",
    description: "Você está na fila"
  },
  chamado: {
    icon: Phone,
    color: "bg-amber-100 text-amber-700 border-amber-200",
    label: "Chamado",
    description: "É a sua vez! Dirija-se ao atendimento"
  },
  atendendo: {
    icon: Users,
    color: "bg-purple-100 text-purple-700 border-purple-200",
    label: "Em Atendimento",
    description: "Você está sendo atendido"
  },
  concluido: {
    icon: CheckCircle2,
    color: "bg-green-100 text-green-700 border-green-200",
    label: "Concluído",
    description: "Atendimento finalizado"
  },
  cancelado: {
    icon: XCircle,
    color: "bg-red-100 text-red-700 border-red-200",
    label: "Cancelado",
    description: "Senha cancelada"
  }
};

export default function TicketViewPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const ticketId = urlParams.get('id');
  const [showFeedback, setShowFeedback] = useState(false);
  const [rating, setRating] = useState(0);
  const [feedback, setFeedback] = useState('');

  const { data: ticket, isLoading: loadingTicket } = useQuery({
    queryKey: ['ticket', ticketId],
    queryFn: async () => {
      const tickets = await base44.entities.Ticket.filter({ id: ticketId });
      const t = tickets[0];
      
      if (t?.status === 'concluido' && !t.rating) {
        setShowFeedback(true);
      }
      
      return t;
    },
    enabled: !!ticketId,
    refetchInterval: 5000,
  });

  const { data: business } = useQuery({
    queryKey: ['business', ticket?.business_id],
    queryFn: async () => {
      const businesses = await base44.entities.Business.filter({ id: ticket.business_id });
      return businesses[0];
    },
    enabled: !!ticket?.business_id,
  });

  const { data: queue } = useQuery({
    queryKey: ['queue', ticket?.queue_id],
    queryFn: async () => {
      const queues = await base44.entities.Queue.filter({ id: ticket.queue_id });
      return queues[0];
    },
    enabled: !!ticket?.queue_id,
    refetchInterval: 5000,
  });

  const { data: allTickets } = useQuery({
    queryKey: ['queue-tickets', ticket?.queue_id],
    queryFn: () => base44.entities.Ticket.filter({ 
      queue_id: ticket.queue_id,
      status: { $in: ['aguardando', 'chamado', 'atendendo'] }
    }),
    enabled: !!ticket?.queue_id,
    refetchInterval: 5000,
    initialData: [],
  });

  const expireTicketMutation = useMutation({
    mutationFn: async () => {
      await base44.entities.Ticket.update(ticketId, {
        status: 'cancelado',
        completed_at: new Date().toISOString()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ticket'] });
    }
  });

  useEffect(() => {
    if (!ticket || !queue || !['aguardando', 'chamado'].includes(ticket.status)) return;

    const checkExpiration = () => {
      const now = new Date();

      if (ticket.status === 'chamado' && ticket.called_at) {
        const calledAt = new Date(ticket.called_at);
        const toleranceMs = (queue.tolerance_time || 15) * 60 * 1000;
        if (now - calledAt > toleranceMs) {
          expireTicketMutation.mutate();
        }
      }

      if (ticket.status === 'aguardando') {
        const currentNumber = queue.current_number;
        if (ticket.ticket_number < currentNumber) {
          expireTicketMutation.mutate();
        }
      }
    };

    checkExpiration();
    const interval = setInterval(checkExpiration, 5000);

    return () => clearInterval(interval);
  }, [ticket, queue, expireTicketMutation]);

  const cancelMutation = useMutation({
    mutationFn: async () => {
      await base44.entities.Ticket.update(ticketId, {
        status: 'cancelado'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ticket'] });
    },
  });

  const submitFeedbackMutation = useMutation({
    mutationFn: async () => {
      await base44.entities.Ticket.update(ticketId, {
        rating,
        feedback
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ticket'] });
      setShowFeedback(false);
    },
  });

  const handleCancel = () => {
    if (confirm('Tem certeza que deseja cancelar esta senha?')) {
      cancelMutation.mutate();
    }
  };

  if (loadingTicket) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 p-6">
        <div className="max-w-2xl mx-auto">
          <Skeleton className="h-96 w-full" />
        </div>
      </div>
    );
  }

  if (!ticket) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 p-6">
        <div className="max-w-2xl mx-auto">
          <Card>
            <CardContent className="py-16 text-center">
              <AlertCircle className="w-16 h-16 text-slate-400 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-slate-900 mb-2">Senha não encontrada</h3>
              <p className="text-slate-600 mb-6">Não foi possível encontrar esta senha</p>
              <Button onClick={() => navigate(createPageUrl('Dashboard'))}>
                Voltar ao Dashboard
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const status = statusConfig[ticket.status];
  const StatusIcon = status.icon;
  
  const position = allTickets.filter(t => 
    t.ticket_number < ticket.ticket_number && 
    ['aguardando', 'chamado'].includes(t.status)
  ).length;
  
  const estimatedTime = position * (queue?.average_service_time || 10);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50">
      <div className="max-w-2xl mx-auto px-6 py-8">
        <Button
          variant="outline"
          className="mb-6 gap-2"
          onClick={() => navigate(createPageUrl('MyTickets'))}
        >
          <ArrowLeft className="w-4 h-4" />
          Minhas Senhas
        </Button>

        <Card className="border-0 shadow-2xl mb-6 overflow-hidden">
          <div className={`h-2 bg-gradient-to-r ${
            ticket.status === 'aguardando' ? 'from-blue-500 to-cyan-500' :
            ticket.status === 'chamado' ? 'from-amber-500 to-orange-500' :
            ticket.status === 'atendendo' ? 'from-purple-500 to-pink-500' :
            ticket.status === 'concluido' ? 'from-green-500 to-emerald-500' :
            'from-red-500 to-rose-500'
          }`} />
          
          <CardContent className="p-8">
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-gradient-to-br from-sky-500 to-blue-600 mb-4">
                <span className="text-4xl font-bold text-white">#{ticket.ticket_number}</span>
              </div>
              
              <Badge className={`${status.color} text-base px-4 py-1.5 mb-2`}>
                <StatusIcon className="w-4 h-4 mr-2" />
                {status.label}
              </Badge>
              
              <p className="text-slate-600 text-lg">{status.description}</p>
            </div>

            <div className="bg-slate-50 rounded-xl p-6 mb-6">
              <div className="flex items-start gap-4">
                {business?.logo_url && (
                  <img 
                    src={business.logo_url} 
                    alt={business.name}
                    className="w-16 h-16 rounded-lg object-contain bg-white p-2"
                  />
                )}
                <div className="flex-1">
                  <h3 className="font-bold text-xl text-slate-900 mb-1">{business?.name}</h3>
                  <p className="text-slate-600 mb-2">{queue?.name}</p>
                  {business?.address && (
                    <div className="flex items-center gap-2 text-sm text-slate-500">
                      <MapPin className="w-4 h-4" />
                      <span>{business.address}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {['aguardando', 'chamado'].includes(ticket.status) && (
              <div className="grid grid-cols-3 gap-4 mb-6">
                <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl p-4 text-center">
                  <Users className="w-5 h-5 text-blue-600 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-blue-600">{position}</div>
                  <div className="text-xs text-slate-600">Na sua frente</div>
                </div>
                
                <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-4 text-center">
                  <Clock className="w-5 h-5 text-purple-600 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-purple-600">~{estimatedTime}</div>
                  <div className="text-xs text-slate-600">Minutos</div>
                </div>
                
                <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-4 text-center">
                  <TrendingUp className="w-5 h-5 text-green-600 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-green-600">#{queue?.current_number || 0}</div>
                  <div className="text-xs text-slate-600">Sendo atendido</div>
                </div>
              </div>
            )}

            {ticket.status === 'chamado' && (
              <div className="bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-xl p-6 mb-6 text-center animate-pulse">
                <Phone className="w-12 h-12 mx-auto mb-3" />
                <h4 className="text-2xl font-bold mb-2">É A SUA VEZ!</h4>
                <p className="text-lg">Dirija-se ao balcão de atendimento agora</p>
              </div>
            )}

            {['aguardando', 'chamado'].includes(ticket.status) && (
              <Button
                variant="outline"
                className="w-full border-red-200 text-red-600 hover:bg-red-50"
                onClick={handleCancel}
                disabled={cancelMutation.isPending}
              >
                <XCircle className="w-4 h-4 mr-2" />
                {cancelMutation.isPending ? 'Cancelando...' : 'Cancelar Senha'}
              </Button>
            )}

            {showFeedback && (
              <div className="mt-6 p-6 bg-gradient-to-br from-amber-50 to-orange-50 rounded-xl">
                <h4 className="font-bold text-lg text-slate-900 mb-4">Como foi o atendimento?</h4>
                
                <Label className="mb-2 block">Avaliação</Label>
                <div className="flex gap-2 mb-4">
                  {[1, 2, 3, 4, 5].map(star => (
                    <button
                      key={star}
                      onClick={() => setRating(star)}
                      className={`p-2 rounded-lg transition-all ${
                        rating >= star 
                          ? 'bg-amber-500 text-white' 
                          : 'bg-white text-slate-400 hover:bg-slate-100'
                      }`}
                    >
                      <Star className="w-6 h-6" fill={rating >= star ? 'currentColor' : 'none'} />
                    </button>
                  ))}
                </div>

                <Label htmlFor="feedback" className="mb-2 block">Comentário (opcional)</Label>
                <Textarea
                  id="feedback"
                  value={feedback}
                  onChange={(e) => setFeedback(e.target.value)}
                  placeholder="Conte-nos sobre sua experiência..."
                  rows={3}
                  className="mb-4"
                />

                <Button
                  className="w-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600"
                  onClick={() => submitFeedbackMutation.mutate()}
                  disabled={rating === 0 || submitFeedbackMutation.isPending}
                >
                  {submitFeedbackMutation.isPending ? 'Enviando...' : 'Enviar Avaliação'}
                </Button>
              </div>
            )}

            {ticket.rating && !showFeedback && (
              <div className="mt-6 p-4 bg-slate-50 rounded-xl">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-sm text-slate-600">Sua avaliação:</span>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map(star => (
                      <Star 
                        key={star} 
                        className={`w-4 h-4 ${ticket.rating >= star ? 'text-amber-500 fill-amber-500' : 'text-slate-300'}`}
                      />
                    ))}
                  </div>
                </div>
                {ticket.feedback && (
                  <p className="text-sm text-slate-700 italic">&quot;{ticket.feedback}&quot;</p>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {['aguardando', 'chamado'].includes(ticket.status) && (
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="text-lg">Dicas</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex gap-3">
                <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-slate-900">Esta página atualiza automaticamente</p>
                  <p className="text-sm text-slate-600">Não precisa recarregar, as informações são atualizadas em tempo real</p>
                </div>
              </div>
              
              <div className="flex gap-3">
                <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-slate-900">Fique atento às notificações</p>
                  <p className="text-sm text-slate-600">Você receberá um aviso quando estiver próximo da sua vez</p>
                </div>
              </div>
              
              <div className="flex gap-3">
                <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-slate-900">Pode sair e voltar</p>
                  <p className="text-sm text-slate-600">Aproveite o tempo de espera para fazer outras coisas</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}