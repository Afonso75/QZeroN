import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Loader2, ArrowRight, Crown } from "lucide-react";
import { createPageUrl } from "@/utils";

export default function PaymentSuccessPage() {
  const [status, setStatus] = useState('checking');
  const [paymentInfo, setPaymentInfo] = useState(null);
  const [retryCount, setRetryCount] = useState(0);

  const urlParams = new URLSearchParams(window.location.search);
  const sessionId = urlParams.get('session_id');

  useEffect(() => {
    if (!sessionId) {
      setStatus('error');
      return;
    }

    const checkPayment = async () => {
      try {
        const response = await base44.functions.invoke('checkPaymentStatus', {
          sessionId: sessionId
        });

        console.log('Payment check response:', response.data);
        setPaymentInfo(response.data);

        if (response.data.status === 'paid') {
          setStatus('success');
          
          // Aguardar 2 segundos e redirecionar
          setTimeout(() => {
            const plan = response.data.metadata?.plan || 'business';
            if (plan === 'business') {
              window.location.href = createPageUrl('BusinessDashboard');
            } else {
              window.location.href = createPageUrl('Dashboard');
            }
          }, 2000);
        } else if (retryCount < 5) {
          // Tentar novamente em 2 segundos
          setTimeout(() => {
            setRetryCount(prev => prev + 1);
            checkPayment();
          }, 2000);
        } else {
          setStatus('error');
        }
      } catch (error) {
        console.error('Payment check error:', error);
        if (retryCount < 5) {
          setTimeout(() => {
            setRetryCount(prev => prev + 1);
            checkPayment();
          }, 2000);
        } else {
          setStatus('error');
        }
      }
    };

    checkPayment();
  }, [sessionId, retryCount]);

  if (status === 'checking') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 flex items-center justify-center p-6">
        <Card className="border-0 shadow-2xl max-w-md w-full">
          <CardContent className="p-12 text-center">
            <Loader2 className="w-16 h-16 animate-spin text-purple-600 mx-auto mb-6" />
            <h2 className="text-2xl font-bold text-slate-900 mb-2">
              A processar pagamento...
            </h2>
            <p className="text-slate-600">
              Por favor aguarde enquanto confirmamos o seu pagamento
            </p>
            {retryCount > 0 && (
              <p className="text-sm text-slate-500 mt-2">
                Tentativa {retryCount}/5
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  if (status === 'error') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 flex items-center justify-center p-6">
        <Card className="border-0 shadow-2xl max-w-md w-full">
          <CardContent className="p-12 text-center">
            <div className="w-16 h-16 rounded-full bg-amber-100 flex items-center justify-center mx-auto mb-6">
              <div className="text-4xl">⚠️</div>
            </div>
            <h2 className="text-2xl font-bold text-slate-900 mb-2">
              Pagamento em Processamento
            </h2>
            <p className="text-slate-600 mb-6">
              O seu pagamento está a ser processado. Pode demorar alguns minutos. 
              Por favor, tente aceder ao painel empresarial dentro de momentos.
            </p>
            <Button 
              onClick={() => window.location.href = createPageUrl('BusinessDashboard')}
              className="w-full"
            >
              Ir para Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleContinue = () => {
    const plan = paymentInfo?.metadata?.plan || 'business';
    if (plan === 'business') {
      window.location.href = createPageUrl('BusinessDashboard');
    } else {
      window.location.href = createPageUrl('Dashboard');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 flex items-center justify-center p-6">
      <Card className="border-0 shadow-2xl max-w-md w-full overflow-hidden">
        <div className="h-2 bg-gradient-to-r from-green-500 to-emerald-500" />
        <CardContent className="p-12 text-center">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-green-500 to-emerald-500 flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-slate-900 mb-3">
            Pagamento Confirmado! 🎉
          </h1>
          <p className="text-lg text-slate-600 mb-6">
            A sua subscrição foi ativada com sucesso
          </p>

          {paymentInfo && (
            <div className="bg-slate-50 rounded-lg p-4 mb-6 text-left">
              <div className="flex justify-between mb-2">
                <span className="text-slate-600">Plano:</span>
                <span className="font-semibold text-slate-900 flex items-center gap-1">
                  <Crown className="w-4 h-4 text-purple-600" />
                  {paymentInfo.metadata?.plan === 'business' ? 'Empresarial' : 'Premium'}
                </span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="text-slate-600">Valor:</span>
                <span className="font-semibold text-slate-900">
                  €{(paymentInfo.amount_total / 100).toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Email:</span>
                <span className="font-semibold text-slate-900 text-sm">
                  {paymentInfo.customer_email}
                </span>
              </div>
            </div>
          )}

          <p className="text-sm text-slate-500 mb-6">
            A redirecionar para o seu painel...
          </p>

          <Button
            onClick={handleContinue}
            className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
          >
            Ir para Dashboard
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}