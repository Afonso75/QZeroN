import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Building2, ArrowRight, Loader2, MapPin, Mail, Phone } from "lucide-react";
import { toast } from "sonner";

export default function BusinessProfileSetupPage() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    category: '',
    custom_category: '',
    address: '',
    phone: '',
    email: '',
    description: ''
  });

  useEffect(() => {
    base44.auth.me().then(userData => {
      setUser(userData);
      if (!userData.has_business_subscription) {
        navigate(createPageUrl("BusinessSubscription"));
      }
      if (userData.business_profile_completed) {
        navigate(createPageUrl("BusinessDashboard"));
      }
    }).catch(() => {
      base44.auth.redirectToLogin();
    });
  }, [navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.name || !formData.category || !formData.phone || !formData.email) {
      toast.error('Preencha todos os campos obrigatórios');
      return;
    }
    
    if (formData.category === 'outros' && !formData.custom_category) {
      toast.error('Especifique o tipo de negócio');
      return;
    }
    
    setIsLoading(true);
    
    try {
      const business = await base44.entities.Business.create(formData);
      await base44.auth.updateMe({
        business_id: business.id,
        business_profile_completed: true
      });
      
      toast.success('Perfil configurado! Bem-vindo ao painel empresarial.');
      navigate(createPageUrl("BusinessDashboard"));
    } catch (error) {
      console.error('Error:', error);
      toast.error('Erro ao criar perfil');
    } finally {
      setIsLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50">
      <div className="max-w-3xl mx-auto px-6 py-12">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-indigo-600 to-purple-700 rounded-2xl mb-6">
            <Building2 className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4">
            Configure a Sua Empresa
          </h1>
          <p className="text-xl text-slate-600">
            Vamos começar com as informações básicas do seu negócio
          </p>
        </div>

        <Card className="border-0 shadow-2xl">
          <CardHeader>
            <CardTitle>Dados da Empresa</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <Label htmlFor="name">Nome da Empresa *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  placeholder="Empresa Exemplo Lda"
                  className="mt-2"
                  required
                />
              </div>

              <div>
                <Label htmlFor="category">Categoria *</Label>
                <Select 
                  value={formData.category} 
                  onValueChange={(value) => setFormData({...formData, category: value, custom_category: value === 'outros' ? formData.custom_category : ''})}
                  required
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Selecione a categoria" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="saude">🏥 Saúde</SelectItem>
                    <SelectItem value="financeiro">🏦 Financeiro</SelectItem>
                    <SelectItem value="governo">🏛️ Governo</SelectItem>
                    <SelectItem value="restauracao">🍽️ Restauração</SelectItem>
                    <SelectItem value="beleza">💇 Beleza</SelectItem>
                    <SelectItem value="retalho">🛍️ Retalho</SelectItem>
                    <SelectItem value="outros">📍 Outros</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {formData.category === 'outros' && (
                <div className="animate-slide-in-up">
                  <Label htmlFor="custom_category">Especifique o Tipo de Negócio *</Label>
                  <Input
                    id="custom_category"
                    value={formData.custom_category}
                    onChange={(e) => setFormData({...formData, custom_category: e.target.value})}
                    placeholder="Ex: Consultoria, Educação, Tecnologia..."
                    className="mt-2"
                    required
                  />
                </div>
              )}

              <div>
                <Label htmlFor="email">Email de Contacto *</Label>
                <div className="flex gap-2 mt-2">
                  <Mail className="w-5 h-5 text-slate-400 mt-2.5" />
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    placeholder="contacto@empresa.pt"
                    className="flex-1"
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="phone">Telefone *</Label>
                <div className="flex gap-2 mt-2">
                  <Phone className="w-5 h-5 text-slate-400 mt-2.5" />
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({...formData, phone: e.target.value})}
                    placeholder="+351 912 345 678"
                    className="flex-1"
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="address">Morada</Label>
                <div className="flex gap-2 mt-2">
                  <MapPin className="w-5 h-5 text-slate-400 mt-2.5" />
                  <Input
                    id="address"
                    value={formData.address}
                    onChange={(e) => setFormData({...formData, address: e.target.value})}
                    placeholder="Rua Exemplo, nº 123, Lisboa"
                    className="flex-1"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="description">Descrição do Negócio</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  placeholder="Descreva brevemente os serviços que oferece..."
                  className="mt-2 h-24"
                />
              </div>

              <Button
                type="submit"
                disabled={isLoading}
                className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 py-6 text-lg"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    A guardar...
                  </>
                ) : (
                  <>
                    Guardar e Começar
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </>
                )}
              </Button>

              <p className="text-sm text-slate-500 text-center">
                * Campos obrigatórios
              </p>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}