import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  ArrowLeft,
  Building2,
  Save,
  Users,
  MessageSquare,
  ChevronRight
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import FeedbackManager from "../components/business/FeedbackManager";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const categories = [
  { value: "saude", label: "Saúde" },
  { value: "financeiro", label: "Financeiro" },
  { value: "governo", label: "Governo" },
  { value: "restauracao", label: "Restauração" },
  { value: "beleza", label: "Beleza" },
  { value: "retalho", label: "Retalho" },
  { value: "outros", label: "Outros" }
];

const countries = [
  { code: 'PT', name: 'Portugal', flag: '🇵🇹' },
  { code: 'ES', name: 'Espanha', flag: '🇪🇸' },
  { code: 'FR', name: 'França', flag: '🇫🇷' },
  { code: 'UK', name: 'Reino Unido', flag: '🇬🇧' },
  { code: 'DE', name: 'Alemanha', flag: '🇩🇪' },
  { code: 'IT', name: 'Itália', flag: '🇮🇹' },
  { code: 'NL', name: 'Holanda', flag: '🇳🇱' },
  { code: 'BE', name: 'Bélgica', flag: '🇧🇪' },
  { code: 'BR', name: 'Brasil', flag: '🇧🇷' },
  { code: 'US', name: 'Estados Unidos', flag: '🇺🇸' },
  { code: 'CA', name: 'Canadá', flag: '🇨🇦' },
  { code: 'CH', name: 'Suíça', flag: '🇨🇭' },
  { code: 'AT', name: 'Áustria', flag: '🇦🇹' },
  { code: 'LU', name: 'Luxemburgo', flag: '🇱🇺' },
  { code: 'IE', name: 'Irlanda', flag: '🇮🇪' },
  { code: 'SE', name: 'Suécia', flag: '🇸🇪' },
  { code: 'NO', name: 'Noruega', flag: '🇳🇴' },
  { code: 'DK', name: 'Dinamarca', flag: '🇩🇰' },
  { code: 'FI', name: 'Finlândia', flag: '🇫🇮' },
  { code: 'PL', name: 'Polónia', flag: '🇵🇱' },
  { code: 'CZ', name: 'República Checa', flag: '🇨🇿' },
  { code: 'GR', name: 'Grécia', flag: '🇬🇷' },
  { code: 'RO', name: 'Roménia', flag: '🇷🇴' },
  { code: 'HU', name: 'Hungria', flag: '🇭🇺' },
  { code: 'BG', name: 'Bulgária', flag: '🇧🇬' },
  { code: 'HR', name: 'Croácia', flag: '🇭🇷' }
];

const portugueseDistricts = [
  "Aveiro", "Beja", "Braga", "Bragança", "Castelo Branco", "Coimbra",
  "Évora", "Faro", "Guarda", "Leiria", "Lisboa", "Portalegre",
  "Porto", "Santarém", "Setúbal", "Viana do Castelo", "Vila Real", "Viseu"
];

export default function BusinessSettingsPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [businessData, setBusinessData] = useState({});
  const [activeSection, setActiveSection] = useState(null);

  useEffect(() => {
    base44.auth.me().then(userData => {
      setUser(userData);
      if (!userData.is_business_user || !userData.business_id) {
        navigate(createPageUrl("Home"));
      }
    }).catch(() => {
      base44.auth.redirectToLogin();
    });
  }, [navigate]);

  const { data: business, isLoading } = useQuery({
    queryKey: ['business', user?.business_id],
    queryFn: async () => {
      const businesses = await base44.entities.Business.filter({ id: user.business_id });
      const biz = businesses[0];
      setBusinessData(biz);
      return biz;
    },
    enabled: !!user?.business_id,
  });

  const updateBusinessMutation = useMutation({
    mutationFn: async (updates) => {
      await base44.entities.Business.update(user.business_id, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['business'] });
    },
  });

  const handleBusinessUpdate = () => {
    updateBusinessMutation.mutate(businessData);
  };

  const handleChange = (field, value) => {
    setBusinessData(prev => ({ ...prev, [field]: value }));
  };

  if (!user || isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 p-3 md:p-6">
        <div className="max-w-4xl mx-auto">
          <Skeleton className="h-10 md:h-12 w-48 md:w-64 mb-4 md:mb-8" />
          <Skeleton className="h-64 md:h-96 w-full" />
        </div>
      </div>
    );
  }

  const sections = [
    {
      id: 'profile',
      icon: Building2,
      title: 'Perfil da Empresa',
      description: 'Nome, categoria e contactos',
      color: 'from-blue-500 to-cyan-500'
    },
    {
      id: 'team',
      icon: Users,
      title: 'Gestão de Equipa',
      description: 'Convites e permissões de funcionários',
      color: 'from-green-500 to-emerald-500'
    },
    {
      id: 'feedback',
      icon: MessageSquare,
      title: 'Feedback',
      description: 'Avaliações dos clientes',
      color: 'from-amber-500 to-orange-500'
    }
  ];

  if (activeSection) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 animate-fade-in">
        <div className="max-w-4xl mx-auto px-3 md:px-6 py-4 md:py-8">
          <Button
            variant="outline"
            size="sm"
            className="mb-4 gap-2 h-9 smooth-transition hover-lift animate-slide-in-left"
            onClick={() => setActiveSection(null)}
          >
            <ArrowLeft className="w-3 h-3 md:w-4 md:h-4" />
            Voltar
          </Button>

          {activeSection === 'profile' && (
            <Card className="border-0 shadow-xl animate-scale-in">
              <CardHeader className="p-4 md:p-6 border-b bg-gradient-to-r from-blue-50 to-cyan-50">
                <CardTitle className="flex items-center gap-2 text-base md:text-xl">
                  <Building2 className="w-5 h-5 md:w-6 md:h-6" />
                  Perfil da Empresa
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 md:space-y-6 p-4 md:p-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="animate-slide-in-left">
                    <Label htmlFor="name" className="text-xs md:text-sm">Nome *</Label>
                    <Input
                      id="name"
                      value={businessData.name || ''}
                      onChange={(e) => handleChange('name', e.target.value)}
                      placeholder="Ex: Clínica Dr. Silva"
                      className="mt-1 h-9 md:h-10 text-sm"
                    />
                  </div>

                  <div className="animate-slide-in-right">
                    <Label htmlFor="category" className="text-xs md:text-sm">Categoria *</Label>
                    <Select
                      value={businessData.category || ''}
                      onValueChange={(value) => handleChange('category', value)}
                    >
                      <SelectTrigger className="mt-1 h-9 md:h-10 text-sm">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map(cat => (
                          <SelectItem key={cat.value} value={cat.value} className="text-sm">
                            {cat.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="animate-slide-in-up">
                  <Label htmlFor="description" className="text-xs md:text-sm">Descrição</Label>
                  <Textarea
                    id="description"
                    value={businessData.description || ''}
                    onChange={(e) => handleChange('description', e.target.value)}
                    placeholder="Descreva seus serviços..."
                    rows={3}
                    className="mt-1 resize-none text-sm"
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="animate-slide-in-left">
                    <Label htmlFor="phone" className="text-xs md:text-sm">Telefone</Label>
                    <Input
                      id="phone"
                      value={businessData.phone || ''}
                      onChange={(e) => handleChange('phone', e.target.value)}
                      placeholder="+351 912 345 678"
                      className="mt-1 h-9 md:h-10 text-sm"
                    />
                  </div>

                  <div className="animate-slide-in-right">
                    <Label htmlFor="email" className="text-xs md:text-sm">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={businessData.email || ''}
                      onChange={(e) => handleChange('email', e.target.value)}
                      placeholder="contacto@empresa.pt"
                      className="mt-1 h-9 md:h-10 text-sm"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="animate-slide-in-left">
                    <Label htmlFor="country" className="text-xs md:text-sm">País</Label>
                    <Select
                      value={businessData.country || ''}
                      onValueChange={(value) => handleChange('country', value)}
                    >
                      <SelectTrigger className="mt-1 h-9 md:h-10 text-sm">
                        <SelectValue placeholder="Selecione o país" />
                      </SelectTrigger>
                      <SelectContent>
                        {countries.map(country => (
                          <SelectItem key={country.code} value={country.code} className="text-sm">
                            {country.flag} {country.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="animate-slide-in-right">
                    <Label htmlFor="district" className="text-xs md:text-sm">Distrito/Região</Label>
                    {businessData.country === 'PT' ? (
                      <Select
                        value={businessData.district || ''}
                        onValueChange={(value) => handleChange('district', value)}
                      >
                        <SelectTrigger className="mt-1 h-9 md:h-10 text-sm">
                          <SelectValue placeholder="Selecione o distrito" />
                        </SelectTrigger>
                        <SelectContent>
                          {portugueseDistricts.map(district => (
                            <SelectItem key={district} value={district} className="text-sm">
                              {district}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    ) : (
                      <Input
                        id="district"
                        value={businessData.district || ''}
                        onChange={(e) => handleChange('district', e.target.value)}
                        placeholder="Digite o distrito/região"
                        className="mt-1 h-9 md:h-10 text-sm"
                      />
                    )}
                  </div>
                </div>

                <div className="animate-slide-in-up">
                  <Label htmlFor="address" className="text-xs md:text-sm">Morada</Label>
                  <Input
                    id="address"
                    value={businessData.address || ''}
                    onChange={(e) => handleChange('address', e.target.value)}
                    placeholder="Rua, código postal, cidade"
                    className="mt-1 h-9 md:h-10 text-sm"
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="animate-slide-in-left">
                    <Label htmlFor="latitude" className="text-xs md:text-sm">Latitude</Label>
                    <Input
                      id="latitude"
                      type="number"
                      step="0.000001"
                      value={businessData.latitude || ''}
                      onChange={(e) => handleChange('latitude', parseFloat(e.target.value))}
                      placeholder="38.7223"
                      className="mt-1 h-9 md:h-10 text-sm"
                    />
                  </div>

                  <div className="animate-slide-in-right">
                    <Label htmlFor="longitude" className="text-xs md:text-sm">Longitude</Label>
                    <Input
                      id="longitude"
                      type="number"
                      step="0.000001"
                      value={businessData.longitude || ''}
                      onChange={(e) => handleChange('longitude', parseFloat(e.target.value))}
                      placeholder="-9.1393"
                      className="mt-1 h-9 md:h-10 text-sm"
                    />
                  </div>
                </div>

                <div className="animate-slide-in-up">
                  <Label htmlFor="logo_url" className="text-xs md:text-sm">URL do Logotipo</Label>
                  <Input
                    id="logo_url"
                    value={businessData.logo_url || ''}
                    onChange={(e) => handleChange('logo_url', e.target.value)}
                    placeholder="https://..."
                    className="mt-1 h-9 md:h-10 text-sm"
                  />
                  {businessData.logo_url && (
                    <div className="mt-2 md:mt-3">
                      <img 
                        src={businessData.logo_url} 
                        alt="Logo preview" 
                        className="h-16 w-16 md:h-20 md:w-20 rounded-lg object-cover border border-slate-200 hover-lift"
                        onError={(e) => e.target.style.display = 'none'}
                      />
                    </div>
                  )}
                </div>

                <Button
                  size="sm"
                  onClick={handleBusinessUpdate}
                  disabled={updateBusinessMutation.isPending}
                  className="w-full gap-2 bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 h-10 text-sm smooth-transition hover-lift"
                >
                  <Save className="w-4 h-4" />
                  {updateBusinessMutation.isPending ? 'Salvando...' : 'Salvar Alterações'}
                </Button>
              </CardContent>
            </Card>
          )}

          {activeSection === 'feedback' && (
            <div className="animate-scale-in">
              <FeedbackManager businessId={user.business_id} />
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 animate-fade-in">
      <div className="max-w-4xl mx-auto px-3 md:px-6 py-4 md:py-8">
        <Button
          variant="outline"
          size="sm"
          className="mb-4 md:mb-6 gap-2 h-9 smooth-transition hover-lift animate-slide-in-left"
          onClick={() => navigate(createPageUrl("BusinessDashboard"))}
        >
          <ArrowLeft className="w-3 h-3 md:w-4 md:h-4" />
          Voltar ao Painel
        </Button>

        <div className="mb-6 md:mb-8 animate-slide-in-down">
          <h1 className="text-2xl md:text-4xl font-bold text-slate-900 mb-1 md:mb-2 gradient-text">
            Configurações
          </h1>
          <p className="text-sm md:text-lg text-slate-600">
            Escolha o que deseja configurar
          </p>
        </div>

        <div className="grid gap-3 md:gap-4">
          {sections.map((section, idx) => (
            <Card
              key={section.id}
              className="border-0 shadow-lg hover:shadow-xl smooth-transition cursor-pointer group hover-lift stagger-item"
              style={{ animationDelay: `${idx * 0.1}s` }}
              onClick={() => {
                if (section.id === 'team') {
                  navigate(createPageUrl("BusinessStaff"));
                } else {
                  setActiveSection(section.id);
                }
              }}
            >
              <CardContent className="p-4 md:p-6">
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 md:w-14 md:h-14 rounded-xl bg-gradient-to-br ${section.color} flex items-center justify-center flex-shrink-0 smooth-transition group-hover:scale-110`}>
                    <section.icon className="w-6 h-6 md:w-7 md:h-7 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-sm md:text-lg text-slate-900 mb-0.5 md:mb-1">
                      {section.title}
                    </h3>
                    <p className="text-xs md:text-sm text-slate-600">
                      {section.description}
                    </p>
                  </div>
                  <ChevronRight className="w-5 h-5 md:w-6 md:h-6 text-slate-400 group-hover:text-slate-600 group-hover:translate-x-1 smooth-transition flex-shrink-0" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}