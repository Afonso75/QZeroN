import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  ArrowLeft,
  Clock,
  Users,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Info,
  Star,
  MessageSquare,
  Search,
  Calendar
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import AppointmentBooking from "../components/appointments/AppointmentBooking";
import BusinessInfo from "../components/business/BusinessInfo";
import Reviews from "../components/business/Reviews";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";

export default function BusinessDetailPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const businessId = urlParams.get('id');
  const [user, setUser] = useState(null);
  const [userPhone, setUserPhone] = useState("");
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: business, isLoading: loadingBusiness } = useQuery({
    queryKey: ['business', businessId],
    queryFn: async () => {
      const businesses = await base44.entities.Business.filter({ id: businessId });
      return businesses[0];
    },
    enabled: !!businessId,
  });

  const { data: queues, isLoading: loadingQueues } = useQuery({
    queryKey: ['queues', businessId],
    queryFn: () => base44.entities.Queue.filter({ business_id: businessId, is_active: true }),
    initialData: [],
    enabled: !!businessId,
  });

  const { data: services } = useQuery({
    queryKey: ['services', businessId],
    queryFn: () => base44.entities.Service.filter({ business_id: businessId, is_active: true }),
    initialData: [],
    enabled: !!businessId,
  });

  const { data: userTickets } = useQuery({
    queryKey: ['user-tickets', user?.email],
    queryFn: () => base44.entities.Ticket.filter({ 
      user_email: user.email,
      status: { $in: ['aguardando', 'chamado', 'atendendo'] }
    }),
    initialData: [],
    enabled: !!user?.email,
  });

  const createTicketMutation = useMutation({
    mutationFn: async (queueId) => {
      if (!user) {
        base44.auth.redirectToLogin(window.location.href);
        return;
      }

      const now = new Date();
      const twentyMinutesAgo = new Date(now.getTime() - 20 * 60 * 1000);
      
      const recentTickets = await base44.entities.Ticket.filter({
        user_email: user.email,
        queue_id: queueId
      });

      const hasRecentTicket = recentTickets.some(t => {
        const createdAt = new Date(t.created_date);
        return createdAt >= twentyMinutesAgo && ['aguardando', 'chamado', 'atendendo'].includes(t.status);
      });

      if (hasRecentTicket) {
        toast.error('Já tem uma senha ativa para este serviço');
        throw new Error('Já tem uma senha ativa');
      }

      const queue = queues.find(q => q.id === queueId);
      const ticketNumber = queue.last_issued_number + 1;
      const position = ticketNumber - queue.current_number;
      const estimatedTime = position * queue.average_service_time;

      const ticket = await base44.entities.Ticket.create({
        queue_id: queueId,
        business_id: businessId,
        user_email: user.email,
        user_phone: userPhone || user.phone || null,
        ticket_number: ticketNumber,
        status: "aguardando",
        estimated_time: estimatedTime,
        position: position,
        is_premium: false
      });

      await base44.entities.Queue.update(queueId, {
        last_issued_number: ticketNumber
      });

      await base44.entities.Notification.create({
        user_email: user.email,
        ticket_id: ticket.id,
        type: "sua_vez",
        message: `Senha #${ticketNumber} emitida com sucesso! Posição: ${position}`
      });

      return ticket;
    },
    onSuccess: (ticket) => {
      if (ticket) {
        queryClient.invalidateQueries({ queryKey: ['queues', businessId] });
        navigate(createPageUrl(`TicketView?id=${ticket.id}`));
      }
    },
    onError: () => {}
  });

  if (loadingBusiness) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 p-2 md:p-6">
        <div className="max-w-4xl mx-auto">
          <Skeleton className="h-8 w-24 mb-3" />
          <Skeleton className="h-40 w-full mb-3 rounded-xl" />
        </div>
      </div>
    );
  }

  if (!business) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50 p-2 md:p-6">
        <div className="max-w-4xl mx-auto text-center py-12">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-3" />
          <h2 className="text-lg font-bold text-slate-900 mb-2">Empresa não encontrada</h2>
          <Button size="sm" onClick={() => navigate(createPageUrl("Businesses"))}>
            Voltar
          </Button>
        </div>
      </div>
    );
  }

  const filteredQueues = queues.filter(queue => 
    queue.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    queue.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50">
      <div className="max-w-4xl mx-auto px-2 md:px-6 py-2 md:py-6">
        <Button
          variant="outline"
          size="sm"
          className="mb-2 gap-1 h-8 text-xs"
          onClick={() => navigate(createPageUrl("Businesses"))}
        >
          <ArrowLeft className="w-3 h-3" />
          Voltar
        </Button>

        <Card className="mb-3 border-0 shadow-lg overflow-hidden">
          <div className="h-24 bg-gradient-to-br from-sky-500 via-blue-600 to-indigo-700 relative">
            <div className="absolute inset-0 bg-black/20" />
            {business.logo_url && (
              <img
                src={business.logo_url}
                alt={business.name}
                className="absolute bottom-2 left-2 w-12 h-12 rounded-lg bg-white p-1.5 object-contain shadow-lg"
              />
            )}
          </div>

          <CardContent className="pt-3 pb-3">
            <div className="mb-3">
              <h1 className="text-lg font-bold text-slate-900 mb-1">{business.name}</h1>
              <div className="flex items-center gap-2 mb-1.5">
                <div className="flex items-center gap-0.5">
                  <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                  <span className="font-semibold text-sm">{business.rating || '4.8'}</span>
                </div>
                <Badge className="bg-blue-100 text-blue-700 border-blue-200 text-xs h-5">
                  {business.category}
                </Badge>
              </div>
            </div>

            <p className="text-xs text-slate-700 mb-3 leading-relaxed">
              {business.description || 'Serviço de qualidade com atendimento personalizado.'}
            </p>
          </CardContent>
        </Card>

        <Tabs defaultValue="filas" className="space-y-3">
          <TabsList className="bg-white border border-slate-200 w-full grid grid-cols-4 p-0.5">
            <TabsTrigger value="filas" className="text-xs">Senhas</TabsTrigger>
            <TabsTrigger value="agendamento" className="text-xs">Marcar</TabsTrigger>
            <TabsTrigger value="info" className="text-xs">
              <Info className="w-3 h-3 mr-0.5" />
              Info
            </TabsTrigger>
            <TabsTrigger value="avaliacoes" className="text-xs">
              <MessageSquare className="w-3 h-3 mr-0.5" />
              Aval.
            </TabsTrigger>
          </TabsList>

          <TabsContent value="filas">
            <div className="mb-3">
              <h2 className="text-base font-bold text-slate-900 mb-0.5">Filas Disponíveis</h2>
              <p className="text-xs text-slate-600">Selecione e retire sua senha</p>
            </div>

            {queues.length > 0 && (
              <div className="relative mb-3">
                <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                <Input
                  placeholder="Pesquisar fila..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-8 h-9 text-xs"
                />
              </div>
            )}

            {loadingQueues ? (
              <div className="space-y-2">
                {[1, 2].map(i => <Skeleton key={i} className="h-32 w-full rounded-xl" />)}
              </div>
            ) : filteredQueues.length === 0 ? (
              <Card className="border-0 shadow-md">
                <CardContent className="py-8 text-center">
                  <AlertCircle className="w-10 h-10 text-slate-400 mx-auto mb-2" />
                  <h3 className="text-sm font-bold text-slate-900 mb-1">
                    {searchTerm ? 'Nenhuma fila encontrada' : 'Nenhuma fila disponível'}
                  </h3>
                  <p className="text-xs text-slate-600">
                    {searchTerm ? 'Tente outro termo de pesquisa' : 'Esta empresa ainda não configurou filas'}
                  </p>
                  {searchTerm && (
                    <Button size="sm" variant="outline" className="mt-3 h-7 text-xs" onClick={() => setSearchTerm('')}>
                      Limpar pesquisa
                    </Button>
                  )}
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-2">
                {filteredQueues.map(queue => {
                  const peopleWaiting = queue.last_issued_number - queue.current_number;
                  const estimatedTime = peopleWaiting * queue.average_service_time;
                  const isAvailable = queue.status === "aberta" && peopleWaiting < queue.max_capacity;

                  return (
                    <Card key={queue.id} className={`border-0 shadow-md hover:shadow-lg transition-all ${!isAvailable && 'opacity-60'}`}>
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start gap-2">
                          <div className="flex-1 min-w-0">
                            <CardTitle className="text-sm mb-0.5 truncate">{queue.name}</CardTitle>
                            {queue.description && (
                              <p className="text-slate-600 text-xs line-clamp-1">{queue.description}</p>
                            )}
                          </div>
                          {queue.status === "aberta" ? (
                            <Badge className="bg-green-100 text-green-700 border-green-200 text-xs flex-shrink-0 h-5">
                              <CheckCircle2 className="w-2.5 h-2.5 mr-0.5" />
                              Aberta
                            </Badge>
                          ) : (
                            <Badge className="bg-red-100 text-red-700 border-red-200 text-xs flex-shrink-0 h-5">
                              {queue.status}
                            </Badge>
                          )}
                        </div>
                      </CardHeader>

                      <CardContent className="pt-0">
                        <div className="grid grid-cols-3 gap-2 mb-2">
                          <div className="p-2 bg-gradient-to-br from-blue-50 to-sky-50 rounded-lg text-center">
                            <Clock className="w-3 h-3 text-sky-600 mx-auto mb-0.5" />
                            <div className="text-lg font-bold text-sky-600">~{estimatedTime}</div>
                            <div className="text-xs text-slate-600">min</div>
                          </div>

                          <div className="p-2 bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg text-center">
                            <Users className="w-3 h-3 text-purple-600 mx-auto mb-0.5" />
                            <div className="text-lg font-bold text-purple-600">{peopleWaiting}</div>
                            <div className="text-xs text-slate-600">fila</div>
                          </div>

                          <div className="p-2 bg-slate-50 rounded-lg text-center">
                            <div className="text-xs text-slate-600 mb-0.5">Atual</div>
                            <div className="text-sm font-bold text-slate-900">#{queue.current_number}</div>
                          </div>
                        </div>

                        {user && business?.sms_gateway && business.sms_gateway !== 'none' && (
                          <Input
                            type="tel"
                            placeholder="Telefone (opcional, para SMS)"
                            value={userPhone}
                            onChange={(e) => setUserPhone(e.target.value)}
                            className="mb-2 h-8 text-xs"
                          />
                        )}

                        <Button
                          size="sm"
                          className="w-full bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 h-9 text-xs"
                          disabled={!isAvailable || createTicketMutation.isPending}
                          onClick={() => createTicketMutation.mutate(queue.id)}
                        >
                          {createTicketMutation.isPending ? (
                            "Emitindo..."
                          ) : !isAvailable ? (
                            "Indisponível"
                          ) : (
                            <>
                              <Sparkles className="w-3 h-3 mr-1" />
                              Retirar Senha
                            </>
                          )}
                        </Button>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>

          <TabsContent value="agendamento">
            {services.length === 0 ? (
              <Card className="border-0 shadow-md">
                <CardContent className="py-8 text-center">
                  <Calendar className="w-10 h-10 text-slate-400 mx-auto mb-2" />
                  <h3 className="text-sm font-bold text-slate-900 mb-1">Nenhum serviço disponível</h3>
                  <p className="text-xs text-slate-600">Esta empresa ainda não configurou serviços para marcação</p>
                </CardContent>
              </Card>
            ) : !user ? (
              <Card className="border-0 shadow-md">
                <CardContent className="py-8 text-center">
                  <AlertCircle className="w-10 h-10 text-amber-500 mx-auto mb-2" />
                  <h3 className="text-sm font-bold text-slate-900 mb-1">Login Necessário</h3>
                  <p className="text-xs text-slate-600 mb-3">
                    Faça login para marcar
                  </p>
                  <Button size="sm" onClick={() => base44.auth.redirectToLogin(window.location.href)} className="h-8 text-xs">
                    Fazer Login
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <>
                <div className="mb-3">
                  <h2 className="text-base font-bold text-slate-900 mb-0.5">Marcar Serviço</h2>
                  <p className="text-xs text-slate-600">Agende com hora marcada</p>
                </div>
                <AppointmentBooking
                  business={business}
                  user={user}
                  onComplete={() => {
                    navigate(createPageUrl("MyAppointments"));
                  }}
                />
              </>
            )}
          </TabsContent>

          <TabsContent value="info">
            <BusinessInfo business={business} />
          </TabsContent>

          <TabsContent value="avaliacoes">
            <Reviews business={business} user={user} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}