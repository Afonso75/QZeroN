import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  Clock, 
  Calendar, 
  TrendingUp, 
  Shield,
  Search,
  ArrowRight,
  MapPin,
  Star,
  Sparkles
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function HomePage() {
  const navigate = useNavigate();
  const [user, setUser] = React.useState(null);
  const [searchTerm, setSearchTerm] = React.useState("");

  React.useEffect(() => {
    base44.auth.me().then(userData => {
      setUser(userData);
      
      // Redirecionar se for conta empresarial pura
      if (userData.account_type === 'empresa') {
        navigate(createPageUrl("BusinessDashboard"));
      }
    }).catch(() => {});
  }, [navigate]);

  const { data: businesses, isLoading } = useQuery({
    queryKey: ['active-businesses'],
    queryFn: () => base44.entities.Business.filter({ is_active: true }),
    initialData: [],
  });

  const filteredBusinesses = businesses.filter(b => 
    b.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    b.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const features = [
    {
      icon: Clock,
      title: "Sem Filas",
      description: "Retire senha digital",
      color: "from-blue-500 to-cyan-500"
    },
    {
      icon: Calendar,
      title: "Marcações",
      description: "Agende serviços",
      color: "from-purple-500 to-pink-500"
    },
    {
      icon: TrendingUp,
      title: "Tempo Real",
      description: "Veja sua posição",
      color: "from-amber-500 to-orange-500"
    },
    {
      icon: Shield,
      title: "Seguro",
      description: "Dados protegidos",
      color: "from-green-500 to-emerald-500"
    }
  ];

  const handleStartButton = () => {
    if (user) {
      navigate(createPageUrl("Businesses"));
    } else {
      base44.auth.redirectToLogin();
    }
  };

  // Não mostrar para contas empresariais puras
  if (user?.account_type === 'empresa') {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-sky-50">
      <div className="px-4 py-8 md:px-6 md:py-16">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-8 md:mb-12">
            <div className="inline-flex items-center gap-2 bg-white/80 backdrop-blur-sm px-3 py-1.5 rounded-full mb-4 shadow-sm">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              <span className="text-xs md:text-sm font-medium text-slate-700">Sistema Ativo</span>
            </div>
            <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold text-slate-900 mb-3 md:mb-4">
              Acabe com as Filas
            </h1>
            <p className="text-base md:text-xl text-slate-600 max-w-2xl mx-auto mb-6 md:mb-8 px-4">
              Retire senhas digitais e agende serviços sem esperar
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center px-4">
              <Button 
                size="lg"
                onClick={handleStartButton}
                className="w-full sm:w-auto bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 h-11 text-sm md:text-base"
              >
                Ver Empresas
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4 mb-8 md:mb-12">
            {features.map((feature, idx) => (
              <Card key={idx} className="border-0 shadow-md">
                <CardContent className="p-3 md:p-4 text-center">
                  <div className={`w-10 h-10 md:w-12 md:h-12 rounded-lg bg-gradient-to-br ${feature.color} flex items-center justify-center mx-auto mb-2`}>
                    <feature.icon className="w-5 h-5 md:w-6 md:h-6 text-white" />
                  </div>
                  <h3 className="font-semibold text-xs md:text-sm text-slate-900 mb-1">{feature.title}</h3>
                  <p className="text-xs text-slate-600">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mb-6">
            <div className="relative max-w-2xl mx-auto">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Procurar empresas..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 h-11 md:h-12 text-sm md:text-base"
              />
            </div>
          </div>

          <div className="mb-4">
            <h2 className="text-lg md:text-2xl font-bold text-slate-900 mb-1">
              Empresas Disponíveis
            </h2>
            <p className="text-sm md:text-base text-slate-600">
              {filteredBusinesses.length} {filteredBusinesses.length === 1 ? 'empresa encontrada' : 'empresas encontradas'}
            </p>
          </div>

          {isLoading ? (
            <div className="grid md:grid-cols-2 gap-3 md:gap-4">
              {[1, 2, 3, 4].map(i => (
                <Skeleton key={i} className="h-32 md:h-40" />
              ))}
            </div>
          ) : filteredBusinesses.length === 0 ? (
            <Card className="border-0 shadow-lg">
              <CardContent className="py-12 md:py-16 text-center">
                <div className="w-12 h-12 md:w-16 md:h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-3 md:mb-4">
                  <Search className="w-6 h-6 md:w-8 md:h-8 text-slate-400" />
                </div>
                <h3 className="text-lg md:text-xl font-bold text-slate-900 mb-2">
                  Nenhuma empresa encontrada
                </h3>
                <p className="text-sm md:text-base text-slate-600">
                  Tente ajustar os filtros de pesquisa
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 gap-3 md:gap-4">
              {filteredBusinesses.map(business => (
                <Card key={business.id} className="border-0 shadow-md hover:shadow-xl transition-all">
                  <CardContent className="p-4">
                    <div className="flex gap-3 mb-3">
                      {business.logo_url && (
                        <img 
                          src={business.logo_url} 
                          alt={business.name}
                          className="w-12 h-12 md:w-16 md:h-16 rounded-lg object-cover flex-shrink-0"
                        />
                      )}
                      <div className="flex-1 min-w-0">
                        <h3 className="font-bold text-sm md:text-base text-slate-900 mb-1 truncate">
                          {business.name}
                        </h3>
                        {business.description && (
                          <p className="text-xs md:text-sm text-slate-600 mb-2 line-clamp-2">
                            {business.description}
                          </p>
                        )}
                        <div className="flex flex-wrap items-center gap-2 text-xs">
                          {business.address && (
                            <Badge variant="outline" className="gap-1">
                              <MapPin className="w-3 h-3" />
                              {business.address.split(',')[0]}
                            </Badge>
                          )}
                          {business.rating && (
                            <Badge variant="outline" className="gap-1">
                              <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                              {business.rating.toFixed(1)}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>

                    <Button
                      onClick={() => navigate(createPageUrl(`BusinessDetail?id=${business.id}`))}
                      className="w-full bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 h-9 text-xs gap-1"
                    >
                      <Sparkles className="w-3 h-3" />
                      Ver Detalhes
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="bg-gradient-to-r from-sky-600 to-blue-700 px-4 py-12 md:py-16">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-2xl md:text-4xl font-bold text-white mb-3 md:mb-4">
            Pronto para começar?
          </h2>
          <p className="text-base md:text-xl text-blue-100 mb-6 md:mb-8">
            Junte-se a milhares de utilizadores que já eliminaram as filas
          </p>
          <Button 
            size="lg"
            onClick={handleStartButton}
            className="bg-white text-sky-600 hover:bg-blue-50 h-11 md:h-12 text-sm md:text-base"
          >
            Ver Empresas
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}